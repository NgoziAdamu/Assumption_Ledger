WITH source_rows AS (
    SELECT * FROM raw.facebook_ads_basic_ad_data
),
cleaned AS (
    SELECT
        'FACEBOOK_ADS' AS platform,
        CAST(CAST("ad_id" AS VARCHAR) AS VARCHAR) AS ad_id,
        CAST(TRY_CAST(date AS DATE) AS DATE) AS date_day,
        CAST("account_id" AS VARCHAR) AS account_id,
        CAST(TRY_CAST("impressions" AS BIGINT) AS INTEGER) AS impressions,
        CAST("inline_link_clicks" AS INTEGER) AS inline_link_clicks,
        CAST(NULL::DECIMAL(18,2) AS DECIMAL(18,2)) AS spend,
        CAST(NULL::INTEGER AS INTEGER) AS click_through_rate,
        CAST(NULL::INTEGER AS INTEGER) AS cost_per_click,
        CAST(NULL::DOUBLE AS DOUBLE) AS cost_per_thousand_impressions,
        CURRENT_TIMESTAMP AS _dbt_loaded_at
    FROM source_rows
)
SELECT * FROM cleaned