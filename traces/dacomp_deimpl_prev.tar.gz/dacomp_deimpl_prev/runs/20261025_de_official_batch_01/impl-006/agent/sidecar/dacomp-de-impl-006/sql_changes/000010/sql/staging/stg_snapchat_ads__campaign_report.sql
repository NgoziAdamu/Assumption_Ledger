WITH source_rows AS (
    SELECT * FROM raw.snapchat_campaign_hourly_report_data
),
cleaned AS (
    SELECT
        'SNAPCHAT_ADS' AS platform,
        CAST(CAST("campaign_id" AS VARCHAR) AS VARCHAR) AS campaign_id,
        CAST(TRY_CAST(date AS DATE) AS DATE) AS date_day,
        CAST(NULL::VARCHAR AS VARCHAR) AS ad_account_id,
        CAST(TRY_CAST("impressions" AS BIGINT) AS INTEGER) AS impressions,
        CAST("swipes" AS INTEGER) AS swipes,
        CAST(NULL::DECIMAL(18,2) AS DECIMAL(18,2)) AS spend,
        CAST(TRY_CAST("video_views" AS BIGINT) AS INTEGER) AS video_views,
        CAST("screen_time_millis" AS BIGINT) AS screen_time_millis,
        CAST("quartile_1" AS INTEGER) AS quartile_1,
        CAST("quartile_2" AS INTEGER) AS quartile_2,
        CAST("quartile_3" AS INTEGER) AS quartile_3,
        CAST("view_completion" AS INTEGER) AS view_completion,
        CAST("story_opens" AS INTEGER) AS story_opens,
        CAST("story_completes" AS INTEGER) AS story_completes,
        CAST("shares" AS INTEGER) AS shares,
        CAST("saves" AS INTEGER) AS saves,
        CAST("conversion_purchases" AS INTEGER) AS conversion_purchases,
        CAST("conversion_purchases_value" AS DECIMAL(18,2)) AS conversion_purchases_value,
        CAST("total_installs" AS INTEGER) AS app_installs,
        CAST(NULL::DOUBLE AS DOUBLE) AS swipe_up_rate,
        CAST(NULL::DOUBLE AS DOUBLE) AS cost_per_swipe,
        CAST(NULL::DOUBLE AS DOUBLE) AS cost_per_thousand_impressions,
        CAST(NULL::DOUBLE AS DOUBLE) AS cost_per_video_view,
        CAST(NULL::DOUBLE AS DOUBLE) AS cost_per_install,
        CURRENT_TIMESTAMP AS _dbt_loaded_at
    FROM source_rows
)
SELECT * FROM cleaned