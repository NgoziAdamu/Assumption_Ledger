WITH source_rows AS (
    SELECT * FROM raw.apple_search_ad_report_data
),
cleaned AS (
    SELECT
        'APPLE_SEARCH_ADS' AS platform,
        CAST(CAST("ad_id" AS VARCHAR) AS VARCHAR) AS ad_id,
        CAST(TRY_CAST(date AS DATE) AS DATE) AS date_day,
        CAST(CAST("campaign_id" AS VARCHAR) AS VARCHAR) AS campaign_id,
        CAST(CAST("ad_group_id" AS VARCHAR) AS VARCHAR) AS ad_group_id,
        CAST(TRY_CAST("impressions" AS BIGINT) AS INTEGER) AS impressions,
        CAST("taps" AS INTEGER) AS taps,
        CAST("tap_installs" AS INTEGER) AS tap_installs,
        CAST(TRY_CAST("conversions" AS BIGINT) AS INTEGER) AS conversions,
        CAST("new_downloads" AS INTEGER) AS new_downloads,
        CAST("redownloads" AS INTEGER) AS redownloads,
        CAST("tap_new_downloads" AS INTEGER) AS tap_new_downloads,
        CAST("tap_redownloads" AS INTEGER) AS tap_redownloads,
        CAST(ROUND(TRY_CAST("local_spend_amount" AS DOUBLE), 2) AS DECIMAL(18,2)) AS spend,
        CAST("local_spend_currency" AS VARCHAR) AS spend_currency,
        CAST(NULL::DOUBLE AS DOUBLE) AS tap_through_rate,
        CAST(NULL::DOUBLE AS DOUBLE) AS cost_per_tap,
        CAST(NULL::DOUBLE AS DOUBLE) AS cost_per_conversion,
        CAST(NULL::DOUBLE AS DOUBLE) AS cost_per_download,
        CURRENT_TIMESTAMP AS _dbt_loaded_at
    FROM source_rows
)
SELECT * FROM cleaned