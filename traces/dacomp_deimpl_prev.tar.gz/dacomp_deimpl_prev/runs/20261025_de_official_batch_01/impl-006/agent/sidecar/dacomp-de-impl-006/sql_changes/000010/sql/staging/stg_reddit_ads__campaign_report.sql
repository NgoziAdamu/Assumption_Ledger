WITH source_rows AS (
    SELECT * FROM raw.reddit_ads_campaign_report_data
),
cleaned AS (
    SELECT
        'REDDIT_ADS' AS platform,
        CAST(CAST("campaign_id" AS VARCHAR) AS VARCHAR) AS campaign_id,
        CAST(TRY_CAST(date AS DATE) AS DATE) AS date_day,
        CAST("account_id" AS VARCHAR) AS account_id,
        CAST(TRY_CAST("impressions" AS BIGINT) AS INTEGER) AS impressions,
        CAST(TRY_CAST("clicks" AS BIGINT) AS INTEGER) AS clicks,
        CAST(NULL::DECIMAL(18,2) AS DECIMAL(18,2)) AS spend,
        CAST(NULL::INTEGER AS INTEGER) AS video_views,
        CAST(NULL::DECIMAL(8,4) AS DECIMAL(8,4)) AS video_view_rate,
        CAST(NULL::INTEGER AS INTEGER) AS upvotes,
        CAST(NULL::INTEGER AS INTEGER) AS downvotes,
        CAST(NULL::INTEGER AS INTEGER) AS comments,
        CAST(NULL::INTEGER AS INTEGER) AS shares,
        CAST(NULL::INTEGER AS INTEGER) AS saves,
        CAST(NULL::INTEGER AS INTEGER) AS post_visits,
        CAST(NULL::INTEGER AS INTEGER) AS profile_visits,
        CAST(NULL::INTEGER AS INTEGER) AS community_joins,
        CAST(NULL::INTEGER AS INTEGER) AS conversions,
        CAST(NULL::DECIMAL(18,2) AS DECIMAL(18,2)) AS conversion_value,
        CAST("ctr" AS DOUBLE) AS click_through_rate,
        CAST("cpc" AS DOUBLE) AS cost_per_click,
        CAST("ecpm" AS DOUBLE) AS cost_per_thousand_impressions,
        CAST(NULL::DOUBLE AS DOUBLE) AS cost_per_video_view,
        CAST(NULL::DOUBLE AS DOUBLE) AS cost_per_conversion,
        CAST(NULL::INTEGER AS INTEGER) AS total_engagements,
        CAST(NULL::DOUBLE AS DOUBLE) AS engagement_rate,
        CURRENT_TIMESTAMP AS _dbt_loaded_at
    FROM source_rows
)
SELECT * FROM cleaned