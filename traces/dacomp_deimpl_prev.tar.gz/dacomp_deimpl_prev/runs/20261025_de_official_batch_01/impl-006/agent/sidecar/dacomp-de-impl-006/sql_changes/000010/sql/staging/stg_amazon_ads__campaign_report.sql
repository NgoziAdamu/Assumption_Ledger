WITH source_rows AS (
    SELECT * FROM raw.amazon_ads_campaign_level_report_data
),
cleaned AS (
    SELECT
        'AMAZON_ADS' AS platform,
        CAST(CAST("campaign_id" AS VARCHAR) AS VARCHAR) AS campaign_id,
        CAST(TRY_CAST(date AS DATE) AS DATE) AS date_day,
        CAST("campaign_applicable_budget_rule_id" AS VARCHAR) AS campaign_applicable_budget_rule_id,
        CAST("campaign_applicable_budget_rule_name" AS VARCHAR) AS campaign_applicable_budget_rule_name,
        CAST("campaign_bidding_strategy" AS VARCHAR) AS campaign_bidding_strategy,
        CAST(ROUND(TRY_CAST("campaign_budget_amount" AS DOUBLE), 2) AS DECIMAL(18,2)) AS campaign_budget_amount,
        CAST("campaign_budget_currency_code" AS VARCHAR) AS campaign_budget_currency_code,
        CAST("campaign_budget_type" AS VARCHAR) AS campaign_budget_type,
        CAST(ROUND(TRY_CAST("campaign_rule_based_budget_amount" AS DOUBLE), 2) AS DECIMAL(18,2)) AS campaign_rule_based_budget_amount,
        CAST(TRY_CAST("clicks" AS BIGINT) AS INTEGER) AS clicks,
        CAST(ROUND(TRY_CAST("cost" AS DOUBLE), 2) AS DECIMAL(18,2)) AS cost,
        CAST(TRY_CAST("impressions" AS BIGINT) AS INTEGER) AS impressions,
        CAST(ROUND(TRY_CAST("sales_7_d" AS DOUBLE), 2) AS DECIMAL(18,2)) AS sales_7_d,
        CAST(TRY_CAST("purchases_30_d" AS BIGINT) AS INTEGER) AS purchases_30_d,
        CAST(ROUND(TRY_CAST("sales_30_d" AS DOUBLE), 2) AS DECIMAL(18,2)) AS sales_30_d,
        CAST(NULL::DOUBLE AS DOUBLE) AS click_through_rate,
        CAST(NULL::DOUBLE AS DOUBLE) AS cost_per_click,
        CAST(NULL::DOUBLE AS DOUBLE) AS return_on_ad_spend,
        CURRENT_TIMESTAMP AS _dbt_loaded_at
    FROM source_rows
)
SELECT * FROM cleaned