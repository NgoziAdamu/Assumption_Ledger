WITH source_rows AS (
    SELECT * FROM raw.facebook_ads_basic_ad_actions_data
),
cleaned AS (
    SELECT
        'FACEBOOK_ADS' AS platform,
        CAST(CAST("ad_id" AS VARCHAR) AS VARCHAR) AS ad_id,
        CAST(TRY_CAST(date AS DATE) AS DATE) AS date_day,
        CAST("action_type" AS VARCHAR) AS action_type,
        CAST(NULL::DECIMAL(18,2) AS DECIMAL(18,2)) AS action_1_d_view,
        CAST(NULL::DECIMAL(18,2) AS DECIMAL(18,2)) AS action_7_d_click,
        CAST(NULL::DECIMAL(18,2) AS DECIMAL(18,2)) AS action_value,
        CAST(NULL::DECIMAL(18,2) AS DECIMAL(18,2)) AS inline_value,
        CAST(NULL::BOOLEAN AS BOOLEAN) AS is_index_action,
        CURRENT_TIMESTAMP AS _dbt_loaded_at
    FROM source_rows
)
SELECT * FROM cleaned