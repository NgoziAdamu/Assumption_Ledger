WITH source_rows AS (
    SELECT * FROM raw.tiktok_campaign_report_hourly_data
),
cleaned AS (
    SELECT
        'TIKTOK_ADS' AS platform,
        CAST(CAST("CAMPAIGN_ID" AS VARCHAR) AS VARCHAR) AS campaign_id,
        CAST(TRY_CAST(STAT_TIME_HOUR AS DATE) AS DATE) AS date_day,
        CAST(NULL::VARCHAR AS VARCHAR) AS advertiser_id,
        CAST(TRY_CAST("IMPRESSIONS" AS BIGINT) AS INTEGER) AS impressions,
        CAST(TRY_CAST("CLICKS" AS BIGINT) AS INTEGER) AS clicks,
        CAST(NULL::DECIMAL(18,2) AS DECIMAL(18,2)) AS spend,
        CAST("REACH" AS INTEGER) AS reach,
        CAST("VIDEO_PLAY_ACTIONS" AS INTEGER) AS video_play_actions,
        CAST("VIDEO_WATCHED_2_S" AS INTEGER) AS video_watched_2_s,
        CAST("VIDEO_WATCHED_6_S" AS INTEGER) AS video_watched_6_s,
        CAST("VIDEO_VIEWS_P_25" AS INTEGER) AS video_views_p_25,
        CAST("VIDEO_VIEWS_P_50" AS INTEGER) AS video_views_p_50,
        CAST("VIDEO_VIEWS_P_75" AS INTEGER) AS video_views_p_75,
        CAST("VIDEO_VIEWS_P_100" AS INTEGER) AS video_views_p_100,
        CAST("PROFILE_VISITS" AS INTEGER) AS profile_visits,
        CAST("FOLLOWS" AS INTEGER) AS follows,
        CAST("LIKES" AS INTEGER) AS likes,
        CAST("COMMENTS" AS INTEGER) AS comments,
        CAST("SHARES" AS INTEGER) AS shares,
        CAST(NULL::INTEGER AS INTEGER) AS conversions,
        CAST("CONVERSION_RATE" AS DECIMAL(8,4)) AS conversion_rate,
        CAST("COST_PER_CONVERSION" AS DECIMAL(18,2)) AS cost_per_conversion,
        CAST("CTR" AS DOUBLE) AS click_through_rate,
        CAST(NULL::DOUBLE AS DOUBLE) AS calculated_cost_per_click,
        CAST(NULL::DOUBLE AS DOUBLE) AS cost_per_thousand_impressions,
        CAST(NULL::DOUBLE AS DOUBLE) AS cost_per_thousand_reached,
        CURRENT_TIMESTAMP AS _dbt_loaded_at
    FROM source_rows
)
SELECT * FROM cleaned