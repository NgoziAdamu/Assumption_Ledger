WITH source_rows AS (
    SELECT * FROM raw.google_ads_keyword_stats_data
),
cleaned AS (
    SELECT
        'google_ads' AS source_relation,
        CAST("customer_id" AS VARCHAR(20)) AS account_id,
        CAST(TRY_CAST(date AS DATE) AS DATE) AS date_day,
        CAST(CAST("campaign_id" AS VARCHAR) AS VARCHAR(20)) AS campaign_id,
        CAST(CAST("ad_group_id" AS VARCHAR) AS VARCHAR(20)) AS ad_group_id,
        CAST(NULL::VARCHAR(20) AS VARCHAR(20)) AS keyword_id,
        CAST(TRY_CAST("clicks" AS BIGINT) AS BIGINT) AS clicks,
        CAST(NULL::DECIMAL(15,2) AS DECIMAL(15,2)) AS spend,
        CAST(TRY_CAST("impressions" AS BIGINT) AS BIGINT) AS impressions,
        CAST(TRY_CAST("conversions" AS BIGINT) AS DECIMAL(10,2)) AS conversions,
        CAST("conversions_value" AS DECIMAL(15,2)) AS conversions_value,
        CURRENT_TIMESTAMP AS _dbt_loaded_at
    FROM source_rows
)
SELECT * FROM cleaned