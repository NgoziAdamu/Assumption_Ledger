WITH source_rows AS (
    SELECT * FROM raw.amazon_ads_targeting_keyword_report_data
),
cleaned AS (
    SELECT
        'AMAZON_ADS' AS platform,
        CAST(CAST("keyword_id" AS VARCHAR) AS VARCHAR) AS keyword_id,
        CAST(TRY_CAST(date AS DATE) AS DATE) AS date_day,
        CAST(CAST("campaign_id" AS VARCHAR) AS VARCHAR) AS campaign_id,
        CAST(CAST("ad_group_id" AS VARCHAR) AS VARCHAR) AS ad_group_id,
        CAST("keyword_type" AS VARCHAR) AS keyword_type,
        CAST("match_type" AS VARCHAR) AS match_type,
        CAST("targeting" AS VARCHAR) AS targeting,
        CAST(TRY_CAST("clicks" AS BIGINT) AS INTEGER) AS clicks,
        CAST(ROUND(TRY_CAST("cost" AS DOUBLE), 2) AS DECIMAL(18,2)) AS cost,
        CAST(TRY_CAST("impressions" AS BIGINT) AS INTEGER) AS impressions,
        CAST("ad_keyword_status" AS VARCHAR) AS keyword_status,
        CAST("keyword_bid" AS DECIMAL(10,2)) AS keyword_bid,
        CAST("campaign_budget_currency_code" AS VARCHAR) AS currency_code,
        CAST("campaign_budget_type" AS VARCHAR) AS budget_type,
        CAST(ROUND(TRY_CAST("campaign_budget_amount" AS DOUBLE), 2) AS DECIMAL(10,2)) AS campaign_budget_amount,
        CAST(NULL::DECIMAL(18,2) AS DECIMAL(18,2)) AS attributed_sales_14_d,
        CAST(NULL::DECIMAL(18,2) AS DECIMAL(18,2)) AS attributed_sales_30_d,
        CAST(NULL::INTEGER AS INTEGER) AS attributed_conversions_14_d,
        CAST(NULL::INTEGER AS INTEGER) AS attributed_conversions_30_d,
        CAST(NULL::DOUBLE AS DOUBLE) AS click_through_rate,
        CAST(NULL::DOUBLE AS DOUBLE) AS cost_per_click,
        CAST(NULL::DOUBLE AS DOUBLE) AS return_on_ad_spend,
        CURRENT_TIMESTAMP AS _dbt_loaded_at
    FROM source_rows
)
SELECT * FROM cleaned