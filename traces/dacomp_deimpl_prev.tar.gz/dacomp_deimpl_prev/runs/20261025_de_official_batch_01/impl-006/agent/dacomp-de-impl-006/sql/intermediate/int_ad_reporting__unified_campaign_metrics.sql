WITH execution_clock AS (
    SELECT CURRENT_TIMESTAMP AS processed_at
),
amazon_rows AS (
    SELECT
        'amazon_ads'::VARCHAR AS platform,
        CAST(campaign_id AS VARCHAR) AS campaign_id,
        date_day,
        CAST(campaign_bidding_strategy AS VARCHAR) AS campaign_type,
        CAST(campaign_budget_amount AS DECIMAL(18,2)) AS daily_budget,
        campaign_budget_currency_code AS currency,
        'PRODUCT_SALES'::VARCHAR AS conversion_type,
        CAST(impressions AS BIGINT) AS impressions,
        CAST(clicks AS BIGINT) AS clicks,
        CAST(cost AS DOUBLE) AS cost,
        CAST(sales_7_d AS DECIMAL(18,2)) AS revenue_7d,
        CAST(sales_30_d AS DECIMAL(18,2)) AS revenue_30d,
        CAST(purchases_30_d AS DECIMAL(12,2)) AS conversions,
        CAST(click_through_rate AS DOUBLE) AS click_through_rate,
        CAST(cost_per_click AS DOUBLE) AS cost_per_click,
        CAST(return_on_ad_spend AS DOUBLE) AS return_on_ad_spend,
        _dbt_loaded_at AS source_updated_at
    FROM staging.stg_amazon_ads__campaign_report
    WHERE COALESCE(clicks, 0) >= 0 AND COALESCE(impressions, 0) >= 0 AND COALESCE(cost, 0) >= 0
),
google_rows AS (
    SELECT
        'google_ads'::VARCHAR AS platform,
        CAST(campaign_id AS VARCHAR) AS campaign_id,
        date_day,
        COALESCE(CAST(ad_network_type AS VARCHAR), 'SEARCH') AS campaign_type,
        NULL::DECIMAL(18,2) AS daily_budget,
        'USD'::VARCHAR AS currency,
        'ONLINE_CONVERSION'::VARCHAR AS conversion_type,
        CAST(COALESCE(impressions, 0) AS BIGINT) AS impressions,
        CAST(COALESCE(clicks, 0) AS BIGINT) AS clicks,
        CAST(COALESCE(spend, 0) AS DOUBLE) AS cost,
        CAST(conversions_value AS DECIMAL(18,2)) AS revenue_7d,
        CAST(conversions_value AS DECIMAL(18,2)) AS revenue_30d,
        CAST(conversions AS DECIMAL(12,2)) AS conversions,
        CASE WHEN COALESCE(impressions, 0) > 0 THEN ROUND(COALESCE(clicks, 0)::DOUBLE / impressions * 100, 4) ELSE 0 END AS click_through_rate,
        CASE WHEN COALESCE(clicks, 0) > 0 THEN ROUND(COALESCE(spend, 0) / clicks, 2) ELSE 0 END AS cost_per_click,
        CASE WHEN COALESCE(spend, 0) > 0 AND COALESCE(conversions_value, 0) > 0 THEN ROUND(conversions_value / spend, 4) ELSE 0 END AS return_on_ad_spend,
        CURRENT_TIMESTAMP AS source_updated_at
    FROM staging.stg_google_ads__campaign_report
    WHERE COALESCE(clicks, 0) >= 0 AND COALESCE(impressions, 0) >= 0 AND COALESCE(spend, 0) >= 0
),
facebook_rows AS (
    SELECT
        'facebook_ads'::VARCHAR AS platform,
        CAST(ad_id AS VARCHAR) AS campaign_id,
        date_day,
        'FACEBOOK_FEED'::VARCHAR AS campaign_type,
        NULL::DECIMAL(18,2) AS daily_budget,
        'USD'::VARCHAR AS currency,
        'ENGAGEMENT'::VARCHAR AS conversion_type,
        CAST(COALESCE(impressions, 0) AS BIGINT) AS impressions,
        CAST(COALESCE(inline_link_clicks, 0) AS BIGINT) AS clicks,
        CAST(COALESCE(spend, 0) AS DOUBLE) AS cost,
        0::DECIMAL(18,2) AS revenue_7d,
        0::DECIMAL(18,2) AS revenue_30d,
        0::DECIMAL(12,2) AS conversions,
        CASE WHEN COALESCE(impressions, 0) > 0 THEN ROUND(COALESCE(inline_link_clicks, 0)::DOUBLE / impressions * 100, 4) ELSE 0 END AS click_through_rate,
        CASE WHEN COALESCE(inline_link_clicks, 0) > 0 THEN ROUND(COALESCE(spend, 0) / inline_link_clicks, 2) ELSE 0 END AS cost_per_click,
        0::DOUBLE AS return_on_ad_spend,
        CURRENT_TIMESTAMP AS source_updated_at
    FROM staging.stg_facebook_ads__ad_report
    WHERE COALESCE(spend, 0) >= 0 AND COALESCE(impressions, 0) >= 0
),
linkedin_rows AS (
    SELECT
        'linkedin_ads'::VARCHAR AS platform,
        CAST(campaign_id AS VARCHAR) AS campaign_id,
        TRY_CAST(day AS DATE) AS date_day,
        'LINKEDIN_SPONSORED'::VARCHAR AS campaign_type,
        NULL::DECIMAL(18,2) AS daily_budget,
        'USD'::VARCHAR AS currency,
        'LEAD_GENERATION'::VARCHAR AS conversion_type,
        CAST(COALESCE(TRY_CAST(impressions AS BIGINT), 0) AS BIGINT) AS impressions,
        CAST(COALESCE(TRY_CAST(clicks AS BIGINT), 0) AS BIGINT) AS clicks,
        CAST(COALESCE(TRY_CAST(cost_in_usd AS DOUBLE), 0) AS DOUBLE) AS cost,
        0::DECIMAL(18,2) AS revenue_7d,
        0::DECIMAL(18,2) AS revenue_30d,
        CAST(COALESCE(TRY_CAST(conversion_value_in_local_currency AS INTEGER), 0) AS DECIMAL(12,2)) AS conversions,
        CASE WHEN COALESCE(TRY_CAST(impressions AS BIGINT), 0) > 0 THEN ROUND(COALESCE(TRY_CAST(clicks AS BIGINT), 0)::DOUBLE / TRY_CAST(impressions AS BIGINT) * 100, 4) ELSE 0 END AS click_through_rate,
        CASE WHEN COALESCE(TRY_CAST(clicks AS BIGINT), 0) > 0 AND COALESCE(TRY_CAST(cost_in_usd AS DOUBLE), 0) > 0 THEN ROUND(TRY_CAST(cost_in_usd AS DOUBLE) / TRY_CAST(clicks AS BIGINT), 2) ELSE 0 END AS cost_per_click,
        0::DOUBLE AS return_on_ad_spend,
        CURRENT_TIMESTAMP AS source_updated_at
    FROM raw.linkedin_ad_analytics_by_campaign_data
    WHERE COALESCE(TRY_CAST(cost_in_usd AS DOUBLE), 0) >= 0
),
base AS (
    SELECT * FROM amazon_rows
    UNION ALL SELECT * FROM google_rows
    UNION ALL SELECT * FROM facebook_rows
    UNION ALL SELECT * FROM linkedin_rows
),
metrics AS (
    SELECT
        base.*,
        CASE
            WHEN base.platform = 'amazon_ads' AND base.click_through_rate >= 0.5 THEN 'HIGH'
            WHEN base.platform = 'amazon_ads' AND base.click_through_rate >= 0.2 THEN 'MEDIUM'
            WHEN base.platform = 'google_ads' AND base.click_through_rate >= 2.0 THEN 'HIGH'
            WHEN base.platform = 'google_ads' AND base.click_through_rate >= 0.8 THEN 'MEDIUM'
            WHEN base.platform = 'facebook_ads' AND base.click_through_rate >= 1.5 THEN 'HIGH'
            WHEN base.platform = 'facebook_ads' AND base.click_through_rate >= 0.9 THEN 'MEDIUM'
            WHEN base.click_through_rate >= 1.0 THEN 'HIGH'
            WHEN base.click_through_rate >= 0.5 THEN 'MEDIUM'
            ELSE 'LOW'
        END AS ctr_performance_tier,
        CASE WHEN base.cost_per_click <= 0.5 THEN 'VERY_EFFICIENT' WHEN cost_per_click <= 1.5 THEN 'EFFICIENT' WHEN cost_per_click <= 3.0 THEN 'MODERATE' WHEN cost_per_click <= 5.0 THEN 'EXPENSIVE' ELSE 'VERY_EXPENSIVE' END AS cost_efficiency_tier,
        CASE WHEN base.platform NOT IN ('amazon_ads','google_ads') THEN 'NOT_APPLICABLE' WHEN base.return_on_ad_spend >= 4 THEN 'EXCELLENT' WHEN base.return_on_ad_spend >= 2 THEN 'GOOD' WHEN base.return_on_ad_spend >= 1 THEN 'BREAK_EVEN' WHEN base.return_on_ad_spend > 0 THEN 'LOSS_MAKING' ELSE 'NO_REVENUE' END AS roas_performance_tier,
        CASE WHEN base.impressions >= 10000 THEN 'HIGH_VOLUME' WHEN impressions >= 1000 THEN 'MEDIUM_VOLUME' WHEN impressions >= 100 THEN 'LOW_VOLUME' ELSE 'MINIMAL_VOLUME' END AS volume_tier,
        MIN(date_day) OVER (PARTITION BY base.platform, base.campaign_id) AS first_campaign_date
    FROM base
),
classified AS (
    SELECT
        metrics.*,
        DATE_DIFF('day', first_campaign_date, date_day)::BIGINT AS campaign_age_days,
        CASE WHEN metrics.impressions > 0 THEN ROUND(metrics.cost / metrics.impressions * 1000, 2) ELSE 0 END AS cost_per_mille,
        CASE WHEN metrics.conversions > 0 THEN ROUND(metrics.cost / metrics.conversions, 2) ELSE 0 END AS cost_per_conversion,
        clicks > impressions OR cost < 0 OR click_through_rate > 100 OR cost_per_click > 50 AS has_data_quality_issues
    FROM metrics
)
SELECT
    platform, campaign_id, date_day, campaign_type, daily_budget, currency, conversion_type,
    impressions, clicks, cost, revenue_7d, revenue_30d, conversions,
    click_through_rate, cost_per_click, return_on_ad_spend, cost_per_mille, cost_per_conversion,
    ctr_performance_tier, cost_efficiency_tier, roas_performance_tier, volume_tier, campaign_age_days,
    CASE WHEN campaign_age_days <= 7 THEN 'LAUNCH' WHEN campaign_age_days <= 30 THEN 'OPTIMIZATION' WHEN campaign_age_days <= 90 THEN 'MATURE' ELSE 'ESTABLISHED' END AS lifecycle_stage,
    has_data_quality_issues, source_updated_at, processed_at
FROM classified CROSS JOIN execution_clock
WHERE date_day >= CURRENT_DATE - INTERVAL '365 days'
  AND impressions > 0
  AND NOT has_data_quality_issues
