WITH source_rows AS (
    SELECT * FROM raw.twitter_campaign_report_data
),
cleaned AS (
    SELECT
        'TWITTER_ADS' AS platform,
        CAST(TRY_CAST("campaign_id" AS VARCHAR) AS VARCHAR) AS campaign_id,
        CAST(TRY_CAST(date AS DATE) AS DATE) AS date_day,
        TRY_CAST("account_id" AS VARCHAR) AS account_id,
        TRY_CAST("placement" AS VARCHAR) AS placement,
        CAST(TRY_CAST("impressions" AS BIGINT) AS INTEGER) AS impressions,
        CAST(TRY_CAST("clicks" AS BIGINT) AS INTEGER) AS clicks,
        TRY_CAST("billed_charge_local_micro" AS BIGINT) AS billed_charge_local_micro,
        CAST(NULL::DECIMAL(18,2) AS DECIMAL(18,2)) AS spend,
        TRY_CAST("engagements" AS INTEGER) AS engagements,
        TRY_CAST("retweets" AS INTEGER) AS retweets,
        TRY_CAST("replies" AS INTEGER) AS replies,
        TRY_CAST("likes" AS INTEGER) AS likes,
        TRY_CAST("follows" AS INTEGER) AS follows,
        TRY_CAST("card_engagements" AS INTEGER) AS card_engagements,
        TRY_CAST("carousel_swipes" AS INTEGER) AS carousel_swipes,
        TRY_CAST("poll_card_vote" AS INTEGER) AS poll_card_vote,
        TRY_CAST("media_views" AS INTEGER) AS media_views,
        TRY_CAST("media_engagements" AS INTEGER) AS media_engagements,
        TRY_CAST("video_total_views" AS INTEGER) AS video_total_views,
        TRY_CAST("video_views_25" AS INTEGER) AS video_views_25,
        TRY_CAST("video_views_50" AS INTEGER) AS video_views_50,
        TRY_CAST("video_views_75" AS INTEGER) AS video_views_75,
        TRY_CAST("video_views_100" AS INTEGER) AS video_views_100,
        TRY_CAST("app_clicks" AS INTEGER) AS app_clicks,
        CAST(NULL::INTEGER AS INTEGER) AS app_installs,
        CAST(NULL::INTEGER AS INTEGER) AS app_opens,
        CAST(NULL::DECIMAL(10,4) AS DECIMAL(10,4)) AS click_through_rate,
        CAST(NULL::DECIMAL(10,4) AS DECIMAL(10,4)) AS engagement_rate,
        CAST(NULL::DECIMAL(18,2) AS DECIMAL(18,2)) AS cost_per_click,
        CAST(NULL::DECIMAL(18,2) AS DECIMAL(18,2)) AS cost_per_engagement,
        CAST(NULL::DECIMAL(18,2) AS DECIMAL(18,2)) AS cost_per_thousand_impressions,
        CURRENT_TIMESTAMP AS _dbt_loaded_at
    FROM source_rows
)
SELECT * FROM cleaned