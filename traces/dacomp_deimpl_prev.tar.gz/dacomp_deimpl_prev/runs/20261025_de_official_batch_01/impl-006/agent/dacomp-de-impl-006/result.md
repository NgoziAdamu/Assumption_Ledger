【回复用户】

已创建 `sql/staging/`、`sql/intermediate/` 和 `sql/marts/` 中的 SQL 文件，文件名与 contract / layer dependency 配置一致，共 53 个 SQL 文件（26 staging、14 intermediate、13 marts）。所有配置执行的模型均通过 `run.py` 的 DuckDB 执行，输出表列名逐项与 YAML 列定义比对一致。

验证结果：
- `python run.py` 成功：staging 20/20、intermediate 14/14、marts 13/13。
- `layer_dependencies.yaml` 执行清单中的所有模型均已生成。文档列出的 Google Ads stats staging 表未列入运行依赖清单，因此未配置为 pipeline 执行模型。
- 所有 SQL 文件不以分号结束，且无 dbt `ref()`。
- 脏值转换采用 DuckDB `TRY_CAST`；不可解析值转为 NULL，避免全批失败，但该字段数据会缺失并可能降低后续统计有效性。没有统一去重，以保留契约要求的重复行。

契约边界和限制：合同中部分字段与原始来源列类型/名称不匹配，或来源不可用（例如加载时间字段、部分跨平台字段）。对缺失源字段采用类型明确的 NULL，占用可用字段进行投影，并在缺失加载时间时采用运行时 `CURRENT_TIMESTAMP`。`int_ad_reporting__country_mapping` 由于契约没有给出完整静态列举值，目前为单行静态占位映射，不能代表全量国家覆盖。

重要限制：虽然 SQL 完整可执行且列结构匹配，若干大型 intermediate/marts 复杂模型因源字段缺失或合同映射歧义，当前实现以结构化 NULL/直接字段投影保障执行，并非完整的客户旅程、地理分析、时间序列、预测及执行仪表板业务逻辑。运行验证证明 SQL 和结构有效，不应视为这些复杂分析结果已通过业务准确性验证。

曾遇到的问题及修复：原始字符串转 DECIMAL/INTEGER 报错，已使用 `TRY_CAST`；SQL 尾随分号及原始依赖列表解析问题已修正；统一指标模型对 LinkedIn 原始列映射不匹配已调整。最终 `run.py` 无失败 SQL。
