WITH source_rows AS (
    SELECT * FROM raw.apple_search_campaign_report_data
),
cleaned AS (
    SELECT
        'APPLE_SEARCH_ADS' AS platform,
        CAST(NULL::VARCHAR AS VARCHAR) AS campaign_id,
        CAST(TRY_CAST(date AS DATE) AS DATE) AS date_day,
        CAST(TRY_CAST("impressions" AS BIGINT) AS INTEGER) AS impressions,
        TRY_CAST("taps" AS INTEGER) AS taps,
        TRY_CAST("tap_installs" AS INTEGER) AS tap_installs,
        CAST(TRY_CAST("conversions" AS BIGINT) AS INTEGER) AS conversions,
        TRY_CAST("new_downloads" AS INTEGER) AS new_downloads,
        TRY_CAST("redownloads" AS INTEGER) AS redownloads,
        TRY_CAST("tap_new_downloads" AS INTEGER) AS tap_new_downloads,
        TRY_CAST("tap_redownloads" AS INTEGER) AS tap_redownloads,
        CAST(ROUND(TRY_CAST("local_spend_amount" AS DOUBLE), 2) AS DECIMAL(18,2)) AS spend,
        TRY_CAST("local_spend_currency" AS VARCHAR) AS spend_currency,
        TRY_CAST("avg_cpt_amount" AS DECIMAL(18,2)) AS avg_cost_per_tap,
        TRY_CAST("avg_cpt_currency" AS VARCHAR) AS avg_cpt_currency,
        TRY_CAST("avg_cpa_amount" AS DECIMAL(18,2)) AS avg_cost_per_acquisition,
        TRY_CAST("avg_cpa_currency" AS VARCHAR) AS avg_cpa_currency,
        TRY_CAST("tap_through_rate" AS DECIMAL(10,6)) AS tap_through_rate,
        TRY_CAST("conversion_rate" AS DECIMAL(10,6)) AS conversion_rate,
        TRY_CAST("lat_on_installs" AS INTEGER) AS lat_on_installs,
        TRY_CAST("lat_off_installs" AS INTEGER) AS lat_off_installs,
        CAST(NULL::DOUBLE AS DOUBLE) AS calculated_tap_through_rate,
        CAST(NULL::DOUBLE AS DOUBLE) AS cost_per_tap,
        CAST(NULL::DOUBLE AS DOUBLE) AS cost_per_conversion,
        CURRENT_TIMESTAMP AS _dbt_loaded_at
    FROM source_rows
)
SELECT * FROM cleaned