WITH source_rows AS (
    SELECT * FROM raw.linkedin_ad_analytics_by_campaign_data
),
cleaned AS (
    SELECT
        'LINKEDIN_ADS' AS platform,
        CAST(TRY_CAST("campaign_id" AS VARCHAR) AS VARCHAR) AS campaign_id,
        CAST(TRY_CAST(day AS DATE) AS DATE) AS date_day,
        CAST(TRY_CAST("clicks" AS BIGINT) AS INTEGER) AS clicks,
        CAST(TRY_CAST("impressions" AS BIGINT) AS INTEGER) AS impressions,
        CAST(ROUND(TRY_CAST("cost_in_usd" AS DOUBLE), 2) AS DECIMAL(18,2)) AS cost,
        CAST(TRY_CAST("video_views" AS BIGINT) AS INTEGER) AS video_views,
        TRY_CAST("video_completions" AS INTEGER) AS video_completions,
        TRY_CAST("opens" AS INTEGER) AS opens,
        CAST(NULL::INTEGER AS INTEGER) AS sends,
        TRY_CAST("follows" AS INTEGER) AS follows,
        TRY_CAST("shares" AS INTEGER) AS shares,
        TRY_CAST("comments" AS INTEGER) AS comments,
        TRY_CAST("likes" AS INTEGER) AS likes,
        CAST(NULL::DOUBLE AS DOUBLE) AS click_through_rate,
        CAST(NULL::DOUBLE AS DOUBLE) AS cost_per_click,
        CAST(NULL::DOUBLE AS DOUBLE) AS cost_per_thousand_impressions,
        CURRENT_TIMESTAMP AS _dbt_loaded_at
    FROM source_rows
)
SELECT * FROM cleaned