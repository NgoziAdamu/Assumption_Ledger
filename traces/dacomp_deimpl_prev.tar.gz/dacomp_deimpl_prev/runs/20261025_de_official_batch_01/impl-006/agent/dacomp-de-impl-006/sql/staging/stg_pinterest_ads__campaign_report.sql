WITH source_rows AS (
    SELECT * FROM raw.pinterest_campaign_report_data
),
cleaned AS (
    SELECT
        'PINTEREST_ADS' AS platform,
        CAST(TRY_CAST("campaign_id" AS VARCHAR) AS VARCHAR) AS campaign_id,
        CAST(TRY_CAST(date AS DATE) AS DATE) AS date_day,
        TRY_CAST("advertiser_id" AS VARCHAR) AS advertiser_id,
        CAST(TRY_CAST("impression_1" AS BIGINT) AS INTEGER) AS impressions,
        CAST(NULL::INTEGER AS INTEGER) AS clicks,
        TRY_CAST("spend_in_micro_dollar" AS BIGINT) AS spend_in_micro_dollar,
        CAST(NULL::DOUBLE AS DOUBLE) AS spend,
        CAST(NULL::INTEGER AS INTEGER) AS outbound_clicks,
        CAST(NULL::INTEGER AS INTEGER) AS pin_clicks,
        CAST(NULL::INTEGER AS INTEGER) AS saves,
        CAST(NULL::INTEGER AS INTEGER) AS close_ups,
        CAST(NULL::INTEGER AS INTEGER) AS video_views,
        TRY_CAST("total_conversions" AS INTEGER) AS total_conversions,
        TRY_CAST("total_conversions_value_in_micro_dollar" AS BIGINT) AS total_conversions_value_in_micro_dollar,
        CAST(NULL::DOUBLE AS DOUBLE) AS total_conversions_value,
        CAST(NULL::DOUBLE AS DOUBLE) AS click_through_rate,
        CAST(NULL::DOUBLE AS DOUBLE) AS cost_per_click,
        CAST(NULL::DOUBLE AS DOUBLE) AS cost_per_thousand_impressions,
        CAST(NULL::DOUBLE AS DOUBLE) AS cost_per_conversion,
        CURRENT_TIMESTAMP AS _dbt_loaded_at
    FROM source_rows
)
SELECT * FROM cleaned