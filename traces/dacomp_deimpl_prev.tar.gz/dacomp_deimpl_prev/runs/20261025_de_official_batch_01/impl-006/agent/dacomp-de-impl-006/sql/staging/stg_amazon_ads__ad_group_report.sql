WITH source_rows AS (
    SELECT * FROM raw.amazon_ads_ad_group_level_report_data
),
cleaned AS (
    SELECT
        'AMAZON_ADS' AS platform,
        CAST(TRY_CAST("ad_group_id" AS VARCHAR) AS VARCHAR) AS ad_group_id,
        CAST(TRY_CAST(date AS DATE) AS DATE) AS date_day,
        TRY_CAST("campaign_bidding_strategy" AS VARCHAR) AS campaign_bidding_strategy,
        CAST(TRY_CAST("clicks" AS BIGINT) AS INTEGER) AS clicks,
        CAST(ROUND(TRY_CAST("cost" AS DOUBLE), 2) AS DECIMAL(18,2)) AS cost,
        CAST(TRY_CAST("impressions" AS BIGINT) AS INTEGER) AS impressions,
        CAST(NULL::DOUBLE AS DOUBLE) AS click_through_rate,
        CAST(NULL::DOUBLE AS DOUBLE) AS cost_per_click,
        CURRENT_TIMESTAMP AS _dbt_loaded_at
    FROM source_rows
)
SELECT * FROM cleaned