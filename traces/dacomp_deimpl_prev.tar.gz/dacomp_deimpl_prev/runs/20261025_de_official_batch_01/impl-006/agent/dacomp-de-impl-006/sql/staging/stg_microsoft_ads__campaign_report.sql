WITH source_rows AS (
    SELECT * FROM raw.microsoft_ads_campaign_performance_daily_report_data
),
cleaned AS (
    SELECT
        'MICROSOFT_ADS' AS platform,
        CAST(TRY_CAST("campaign_id" AS VARCHAR) AS VARCHAR) AS campaign_id,
        CAST(TRY_CAST(date AS DATE) AS DATE) AS date_day,
        TRY_CAST("account_id" AS VARCHAR) AS account_id,
        TRY_CAST("device_os" AS VARCHAR) AS device_os,
        TRY_CAST("device_type" AS VARCHAR) AS device_type,
        TRY_CAST("network" AS VARCHAR) AS network,
        CAST(TRY_CAST("clicks" AS BIGINT) AS INTEGER) AS clicks,
        CAST(TRY_CAST("impressions" AS BIGINT) AS INTEGER) AS impressions,
        CAST(NULL::DECIMAL(18,2) AS DECIMAL(18,2)) AS spend,
        CAST(TRY_CAST("conversions" AS BIGINT) AS INTEGER) AS conversions,
        TRY_CAST("revenue" AS DECIMAL(18,2)) AS revenue,
        CAST(NULL::INTEGER AS INTEGER) AS assists,
        CAST(NULL::DECIMAL(8,4) AS DECIMAL(8,4)) AS bounce_rate,
        CAST(NULL::DECIMAL(8,2) AS DECIMAL(8,2)) AS average_position,
        CAST(NULL::DOUBLE AS DOUBLE) AS click_through_rate,
        CAST(NULL::DOUBLE AS DOUBLE) AS cost_per_click,
        CAST(NULL::DOUBLE AS DOUBLE) AS cost_per_thousand_impressions,
        CAST(NULL::DOUBLE AS DOUBLE) AS cost_per_conversion,
        CAST(NULL::DOUBLE AS DOUBLE) AS return_on_ad_spend,
        CURRENT_TIMESTAMP AS _dbt_loaded_at
    FROM source_rows
)
SELECT * FROM cleaned