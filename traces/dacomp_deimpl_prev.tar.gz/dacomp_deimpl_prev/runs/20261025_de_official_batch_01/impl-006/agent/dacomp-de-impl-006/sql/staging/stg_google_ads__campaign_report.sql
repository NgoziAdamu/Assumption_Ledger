WITH source_rows AS (
    SELECT * FROM raw.google_ads_campaign_stats_data
),
cleaned AS (
    SELECT
        'google_ads' AS source_relation,
        TRY_CAST("customer_id" AS VARCHAR(20)) AS account_id,
        CAST(TRY_CAST(date AS DATE) AS DATE) AS date_day,
        CAST(NULL::VARCHAR(20) AS VARCHAR(20)) AS campaign_id,
        TRY_CAST("ad_network_type" AS VARCHAR(20)) AS ad_network_type,
        TRY_CAST("device" AS VARCHAR(20)) AS device,
        CAST(TRY_CAST("clicks" AS BIGINT) AS BIGINT) AS clicks,
        CAST(NULL::DECIMAL(18,2) AS DECIMAL(18,2)) AS spend,
        CAST(TRY_CAST("impressions" AS BIGINT) AS BIGINT) AS impressions,
        CAST(TRY_CAST("conversions" AS BIGINT) AS DECIMAL(10,2)) AS conversions,
        TRY_CAST("conversions_value" AS DECIMAL(15,2)) AS conversions_value,
        TRY_CAST("view_through_conversions" AS BIGINT) AS view_through_conversions
    FROM source_rows
)
SELECT * FROM cleaned