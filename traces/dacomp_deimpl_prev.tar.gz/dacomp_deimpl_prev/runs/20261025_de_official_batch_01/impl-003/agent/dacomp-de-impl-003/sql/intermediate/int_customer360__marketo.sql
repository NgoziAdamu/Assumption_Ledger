select
    m.lead_id, m.email, m.email_address_stripped, m.email_domain, m.full_name_clean, m.first_name_clean, m.last_name_clean, m.name_title, m.name_suffix, m.full_name, m.first_name, m.last_name, m.organization_name, m.organization_name_no_suffix, m.organization_name_suffix, m.inferred_organization_name, m.inferred_organization_name_no_suffix, m.inferred_organization_name_suffix, m.phone, m.phone_extension, m.company_phone, m.company_phone_extension, m.mobile_phone, m.mobile_phone_extension, m.address_line_1, m.address_line_1_long, m.address_line_2, m.city, m.state_code, m.state_long, m.country_code, m.country_long, m.country_long_alt, m.postal_code, m.billing_address_line_1, m.billing_address_line_1_long, m.billing_address_line_2, m.billing_city, m.billing_state_code, m.billing_state_long, m.billing_country_code, m.billing_country_long, m.billing_country_long_alt, m.billing_postal_code, m.inferred_city, m.inferred_state_code, m.inferred_state_long, m.inferred_country_code, m.inferred_country_long, m.inferred_country_long_alt, m.inferred_postal_code, m.ip_address, m.is_unsubscribed, m.is_email_invalid, m.do_not_call,
    cast(m.updated_at as timestamp) as updated_at,
    cast(m.created_at as timestamp) as created_at,
    m.possible_alt_first_names
from raw.marketo_leads m
where m.email is not null and m.email <> ''
