with cleaned as (
    select
        nullif(trim(country_name), '') as country_name,
        nullif(trim(alternative_country_name), '') as alternative_country_name,
        case when country_code_numeric between 1 and 999 then country_code_numeric::integer end as country_code_numeric,
        upper(trim(country_code_alpha_2)) as country_code_alpha_2,
        upper(trim(country_code_alpha_3)) as country_code_alpha_3
    from raw.country_codes
    where country_name is not null and length(trim(country_name)) > 0
      and length(trim(country_code_alpha_2)) = 2
      and regexp_matches(upper(trim(country_code_alpha_2)), '^[A-Z]{2}$')
      and length(trim(country_code_alpha_3)) = 3
      and regexp_matches(upper(trim(country_code_alpha_3)), '^[A-Z]{3}$')
), deduplicated as (
    select *, row_number() over (partition by country_code_alpha_2 order by country_name, country_code_alpha_3) as _row_num
    from cleaned
)
select country_name, alternative_country_name, country_code_numeric, country_code_alpha_2, country_code_alpha_3
from deduplicated
where _row_num = 1
