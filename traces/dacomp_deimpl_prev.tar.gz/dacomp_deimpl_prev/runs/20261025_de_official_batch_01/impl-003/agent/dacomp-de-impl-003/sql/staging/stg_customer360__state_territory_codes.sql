with cleaned as (
    select
        nullif(trim(state_territory), '') as state_territory,
        upper(trim(state_code)) as state_code,
        upper(trim(alpha2_country_code)) as alpha2_country_code
    from raw.state_territory_codes
    where state_territory is not null and trim(state_territory) <> ''
      and state_code is not null and length(trim(state_code)) between 2 and 5
      and alpha2_country_code is not null and length(trim(alpha2_country_code)) = 2
      and regexp_matches(upper(trim(alpha2_country_code)), '^[A-Z]{2}$')
)
select c.state_territory, c.state_code, c.alpha2_country_code
from cleaned c
inner join staging.stg_customer360__country_codes cc
    on c.alpha2_country_code = cc.country_code_alpha_2
