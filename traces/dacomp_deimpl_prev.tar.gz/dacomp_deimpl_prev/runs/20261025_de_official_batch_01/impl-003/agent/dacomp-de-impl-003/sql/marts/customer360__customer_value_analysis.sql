with base as (
 select *,case when estimated_customer_value>=5000 then 5 when estimated_customer_value>=3000 then 4 when estimated_customer_value>=1500 then 3 when estimated_customer_value>=800 then 2 else 1 end as monetary_score
 from intermediate.int_customer360__customer_lifecycle_metrics
), rfm as (
 select *,concat(recency_score::varchar,frequency_score::varchar,monetary_score::varchar) as rfm_score,
 round((recency_score+frequency_score+monetary_score)/3.0,2) as rfm_avg_score,
 estimated_customer_ltv*case lifecycle_stage when 'Acquisition' then .3 when 'Activation' then .6 when 'Growth' then 1.2 when 'Maturity' then 1.0 when 'Retention' then .8 else .5 end as adjusted_ltv,
 case when estimated_customer_ltv>=10000 then 'Tier 1 - Strategic' when estimated_customer_ltv>=5000 then 'Tier 2 - High Value' when estimated_customer_ltv>=2500 then 'Tier 3 - Core' when estimated_customer_ltv>=1000 then 'Tier 4 - Developing' else 'Tier 5 - Basic' end as revenue_tier,
 case when customer_health_score>=4 and churn_probability<=.2 then 'High Stability' when customer_health_score>=3 and churn_probability<=.4 then 'Medium Stability' when customer_health_score>=2 and churn_probability<=.6 then 'Low Stability' else 'Unstable' end as value_stability,
 case when recency_score>=4 and frequency_score>=4 then 'High Upsell' when rfm_avg_score>=3.5 and monetary_score>=3 then 'Medium Upsell' when recency_score>=4 and frequency_score<=2 then 'Cross-sell Focus' else 'Retention Focus' end as upsell_potential
 from base
), scored as (
 select *, round(adjusted_ltv*churn_probability,2) as potential_revenue_loss,
 round(adjusted_ltv*(1-churn_probability)/case when account_age_days>=365 then account_age_days/365.0 else 1 end,2) as expected_annual_revenue,
 case when adjusted_ltv>=50000 then 'High Concentration Risk' when adjusted_ltv>=20000 then 'Medium Concentration Risk' else 'Low Concentration Risk' end as concentration_risk,
 case when churn_probability>=.7 then 5 when churn_probability>=.5 then 4 when churn_probability>=.3 then 3 when churn_probability>=.1 then 2 else 1 end as churn_weight,
 case when rfm_avg_score>=4.5 then 'Champions' when rfm_avg_score>=4 and recency_score>=4 then 'Loyal Customers'
 when rfm_avg_score>=3.5 and monetary_score>=4 then 'Potential Loyalists' when recency_score>=4 and frequency_score<=2 then 'New Customers'
 when recency_score>=3 and frequency_score<=2 and monetary_score<=2 then 'Promising' when recency_score>=3 and monetary_score>=3 then 'Customers Needing Attention'
 when recency_score<=2 and frequency_score>=3 then 'At Risk' when recency_score<=2 and frequency_score<=2 and monetary_score>=4 then 'Cannot Lose Them'
 when recency_score<=1 and frequency_score>=2 then 'Hibernating' else 'Lost' end as rfm_segment
 from rfm
), investment as (
 select *, round((case rfm_segment when 'Champions' then 5 when 'Loyal Customers' then 4.5 when 'Potential Loyalists' then 4 when 'New Customers' then 3.5 when 'Promising' then 3 when 'Customers Needing Attention' then 4.5 when 'At Risk' then 5 when 'Cannot Lose Them' then 5 when 'Hibernating' then 2 else 1 end*.4 +
 case revenue_tier when 'Tier 1 - Strategic' then 5 when 'Tier 2 - High Value' then 4 when 'Tier 3 - Core' then 3 when 'Tier 4 - Developing' then 2 else 1 end*.3+churn_weight*.3),2) as investment_priority_score,
 case when (rfm_segment in ('Champions','Cannot Lose Them') and revenue_tier in ('Tier 1 - Strategic','Tier 2 - High Value')) then 'Strategic Account'
 when rfm_segment in ('Loyal Customers','Potential Loyalists') and revenue_tier in ('Tier 2 - High Value','Tier 3 - Core') then 'Key Account'
 when rfm_segment in ('New Customers','Promising') and revenue_tier in ('Tier 3 - Core','Tier 4 - Developing') then 'Growth Account'
 when rfm_segment in ('At Risk','Hibernating') and revenue_tier in ('Tier 1 - Strategic','Tier 2 - High Value') then 'Recovery Account' else 'Standard Account' end as strategic_classification
 from scored
), portfolio as (
 select *,sum(adjusted_ltv) over() as portfolio_ltv from investment
)
select marketo_lead_id,stripe_customer_id,zendesk_user_id,primary_email,primary_organization,customer_segment,customer_tier,
 rfm_segment,rfm_score,rfm_avg_score,recency_score,frequency_score,monetary_score,estimated_customer_ltv,adjusted_ltv,expected_annual_revenue,revenue_tier,strategic_classification,
 value_stability,upsell_potential,churn_probability,potential_revenue_loss,
 case when adjusted_ltv is null or adjusted_ltv=0 then null else round(churn_probability*100,2) end as revenue_risk_percentage,
 case when portfolio_ltv=0 then null else round(adjusted_ltv/portfolio_ltv*100,4) end as portfolio_contribution_pct,concentration_risk,
 investment_priority_score,
 case when expected_annual_revenue>=5000 then 'Excellent ROI' when expected_annual_revenue>=2000 then 'Good ROI' when expected_annual_revenue>=1000 then 'Acceptable ROI' when expected_annual_revenue>=500 then 'Marginal ROI' else 'Poor ROI' end as acquisition_roi_assessment,
 case strategic_classification when 'Strategic Account' then 'Executive Relationship Management' when 'Key Account' then 'Dedicated Account Management' when 'Growth Account' then 'Expansion Programs' when 'Recovery Account' then 'Retention & Recovery Initiatives' else 'Standard Engagement' end as recommended_engagement_model,
 case when investment_priority_score>=4.5 then 'High Investment' when investment_priority_score>=3.5 then 'Medium Investment' when investment_priority_score>=2.5 then 'Standard Investment' else 'Minimal Investment' end as investment_recommendation,
 case when rfm_segment in ('Champions','Loyal Customers') then 'Maintain Excellence' when rfm_segment in ('Potential Loyalists','Customers Needing Attention') then 'Drive Engagement' when rfm_segment in ('New Customers','Promising') then 'Accelerate Onboarding' when rfm_segment in ('At Risk','Cannot Lose Them') then 'Immediate Intervention' else 'Reactivation Required' end as success_target,
 case when upsell_potential='High Upsell' and value_stability='High Stability' then 'Premium Growth' when upsell_potential in ('High Upsell','Medium Upsell') then 'Expansion Ready' when upsell_potential='Cross-sell Focus' then 'Product Adoption' else 'Value Preservation' end as development_opportunity,
 customer_health_score,lifecycle_stage,
 case when churn_probability>=.7 then 'High Risk' when churn_probability>=.5 then 'Medium Risk' when churn_probability>=.3 then 'Low Risk' else 'Minimal Risk' end as risk_category,
 account_age_days,days_since_last_activity,current_timestamp as analysis_timestamp
from portfolio where primary_email is not null
