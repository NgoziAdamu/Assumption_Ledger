with mapping as (select * from marts.customer360__mapping), addresses as (
 select m.customer360_id,'marketo' as source_system,'primary' as address_type,s.address_line_1,s.address_line_2,s.city,s.state_code,s.country_code,s.postal_code,1 as priority
 from mapping m join intermediate.int_customer360__marketo s on m.marketo_lead_id=s.lead_id where s.address_line_1 is not null
 union all select m.customer360_id,'marketo','billing',s.billing_address_line_1,s.billing_address_line_2,s.billing_city,s.billing_state_code,s.billing_country_code,s.billing_postal_code,2
 from mapping m join intermediate.int_customer360__marketo s on m.marketo_lead_id=s.lead_id where s.billing_address_line_1 is not null
 union all select m.customer360_id,'stripe','customer',s.customer_address_line_1,s.customer_address_line_2,s.customer_city,s.customer_state_code,s.customer_country_code,s.customer_postal_code,1
 from mapping m join intermediate.int_customer360__stripe s on m.stripe_customer_id=s.customer_id where s.customer_address_line_1 is not null
 union all select m.customer360_id,'stripe','shipping',s.shipping_address_line_1,s.shipping_address_line_2,s.shipping_city,s.shipping_state_code,s.shipping_country_code,s.shipping_postal_code,2
 from mapping m join intermediate.int_customer360__stripe s on m.stripe_customer_id=s.customer_id where s.shipping_address_line_1 is not null
), enriched as (
 select a.*, st.state_territory as state,cc.country_name as country,cc.alternative_country_name as country_alt_name
 from addresses a left join staging.stg_customer360__state_territory_codes st on a.state_code=st.state_code and a.country_code=st.alpha2_country_code
 left join staging.stg_customer360__country_codes cc on a.country_code=cc.country_code_alpha_2
)
select customer360_id,source_system,address_type,address_line_1,address_line_2,city,state_code,state,country_code,country,country_alt_name,postal_code,priority,
 row_number() over(partition by customer360_id order by priority) as rank from enriched
