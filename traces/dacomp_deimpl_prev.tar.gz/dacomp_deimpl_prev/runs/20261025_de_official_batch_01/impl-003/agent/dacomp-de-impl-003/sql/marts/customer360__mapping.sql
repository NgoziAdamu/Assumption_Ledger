with source_rows as (
 select sm.marketo_lead_id, sm.stripe_customer_id, sm.zendesk_user_id,
        m.organization_name_no_suffix as m_org, m.inferred_organization_name_no_suffix as mi_org,
        s.customer_organization_name_no_suffix as s_org, s.shipping_organization_name_no_suffix as ss_org,
        z.organization_id, sm.marketo_updated_at, sm.marketo_created_at, sm.stripe_updated_at, sm.stripe_created_at,
        sm.zendesk_updated_at, sm.zendesk_organization_updated_at, sm.zendesk_created_at, sm.zendesk_organization_created_at
 from intermediate.int_customer360__source_matches sm
 left join intermediate.int_customer360__marketo m on sm.marketo_lead_id=m.lead_id
 left join intermediate.int_customer360__stripe s on sm.stripe_customer_id=s.customer_id
 left join intermediate.int_customer360__zendesk z on sm.zendesk_user_id=z.user_id
 union all
 select m.lead_id,null::varchar,null::bigint,m.organization_name_no_suffix,m.inferred_organization_name_no_suffix,null,null,null,m.updated_at,m.created_at,null,null,null,null,null,null
 from intermediate.int_customer360__marketo m where not exists (select 1 from intermediate.int_customer360__source_matches sm where sm.marketo_lead_id=m.lead_id)
 union all
 select null,s.customer_id,null,null,null,s.customer_organization_name_no_suffix,s.shipping_organization_name_no_suffix,null,s.updated_at,s.created_at,s.updated_at,s.created_at,null,null,null,null
 from intermediate.int_customer360__stripe s where not exists (select 1 from intermediate.int_customer360__source_matches sm where sm.stripe_customer_id=s.customer_id)
 union all
 select null,null,z.user_id,null,null,null,null,z.organization_id,z.updated_at,z.created_at,null,null,z.updated_at,z.organization_updated_at,z.created_at,z.organization_created_at
 from intermediate.int_customer360__zendesk z where not exists (select 1 from intermediate.int_customer360__source_matches sm where sm.zendesk_user_id=z.user_id)
), organization_keys as (
 select *, md5(coalesce(m_org,'')||'|'||coalesce(mi_org,'')||'|'||coalesce(s_org,'')||'|'||coalesce(ss_org,'')||'|'||coalesce(organization_id::varchar,'')) as customer360_organization_id
 from source_rows
), individuals as (
 select md5(coalesce(marketo_lead_id::varchar,'')||'|'||coalesce(stripe_customer_id,'')||'|'||coalesce(zendesk_user_id::varchar,'')||'|false|'||customer360_organization_id) as customer360_id,
 customer360_organization_id, marketo_lead_id, stripe_customer_id, zendesk_user_id, false as is_organization_header,
 '{"marketo":"'||coalesce(marketo_lead_id::varchar,'')||'","stripe":"'||coalesce(stripe_customer_id,'')||'","zendesk":"'||coalesce(zendesk_user_id::varchar,'')||'"}' as source_ids,
 greatest(marketo_updated_at, stripe_updated_at, zendesk_updated_at) as marketo_updated_at,
 least(marketo_created_at, stripe_created_at, zendesk_created_at) as marketo_created_at,
 stripe_updated_at, stripe_created_at, zendesk_updated_at, zendesk_organization_updated_at,zendesk_created_at,zendesk_organization_created_at
 from organization_keys
), headers as (
 select md5('|||'||'true|'||customer360_organization_id) as customer360_id, customer360_organization_id,
 null::bigint as marketo_lead_id,null::varchar as stripe_customer_id,null::bigint as zendesk_user_id,true as is_organization_header,
 '{"marketo":['||coalesce(string_agg(distinct '"'||coalesce(marketo_lead_id::varchar,'')||'"',','),'')||'],"stripe":['||coalesce(string_agg(distinct '"'||coalesce(stripe_customer_id,'')||'"',','),'')||'],"zendesk":['||coalesce(string_agg(distinct '"'||coalesce(zendesk_user_id::varchar,'')||'"',','),'')||']}' as source_ids,
 max(marketo_updated_at) as marketo_updated_at,min(marketo_created_at) as marketo_created_at,max(stripe_updated_at) as stripe_updated_at,min(stripe_created_at) as stripe_created_at,
 max(zendesk_updated_at) as zendesk_updated_at,max(zendesk_organization_updated_at) as zendesk_organization_updated_at,min(zendesk_created_at) as zendesk_created_at,min(zendesk_organization_created_at) as zendesk_organization_created_at
 from organization_keys group by customer360_organization_id
)
select * from individuals union all select * from headers
