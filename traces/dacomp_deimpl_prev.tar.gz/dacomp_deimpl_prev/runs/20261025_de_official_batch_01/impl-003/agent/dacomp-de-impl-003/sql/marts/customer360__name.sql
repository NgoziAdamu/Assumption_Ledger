with name_rows as (
 select m.customer360_id,s.full_name_clean as full_name from marts.customer360__mapping m join intermediate.int_customer360__marketo s on m.marketo_lead_id=s.lead_id where s.full_name_clean is not null
 union all select m.customer360_id,s.customer_name_clean from marts.customer360__mapping m join intermediate.int_customer360__stripe s on m.stripe_customer_id=s.customer_id where s.customer_name_clean is not null
 union all select m.customer360_id,s.shipping_name_clean from marts.customer360__mapping m join intermediate.int_customer360__stripe s on m.stripe_customer_id=s.customer_id where s.shipping_name_clean is not null
 union all select m.customer360_id,s.full_name_clean from marts.customer360__mapping m join intermediate.int_customer360__zendesk s on m.zendesk_user_id=s.user_id where s.full_name_clean is not null
), unique_names as (select distinct customer360_id,full_name from name_rows)
select customer360_id,full_name,row_number() over(partition by customer360_id order by full_name) as index from unique_names
