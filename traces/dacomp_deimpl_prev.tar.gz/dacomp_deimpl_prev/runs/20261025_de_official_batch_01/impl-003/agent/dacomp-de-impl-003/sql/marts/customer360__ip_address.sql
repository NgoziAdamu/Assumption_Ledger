with candidates as (
 select m.customer360_id,k.ip_address,k.updated_at from marts.customer360__mapping m join intermediate.int_customer360__marketo k on m.marketo_lead_id=k.lead_id where k.ip_address is not null
), ranked as (select *,row_number() over(partition by customer360_id order by updated_at desc) as _rank from candidates)
select customer360_id,ip_address,'marketo' as source_system,updated_at as last_seen from ranked where _rank=1
