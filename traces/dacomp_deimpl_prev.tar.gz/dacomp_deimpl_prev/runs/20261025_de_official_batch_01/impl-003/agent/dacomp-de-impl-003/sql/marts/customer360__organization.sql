with organization_rows as (
 select m.customer360_id,s.organization_name_no_suffix as organization_name from marts.customer360__mapping m join intermediate.int_customer360__marketo s on m.marketo_lead_id=s.lead_id where s.organization_name_no_suffix is not null
 union all select m.customer360_id,s.inferred_organization_name_no_suffix from marts.customer360__mapping m join intermediate.int_customer360__marketo s on m.marketo_lead_id=s.lead_id where s.inferred_organization_name_no_suffix is not null
 union all select m.customer360_id,s.customer_organization_name_no_suffix from marts.customer360__mapping m join intermediate.int_customer360__stripe s on m.stripe_customer_id=s.customer_id where s.customer_organization_name_no_suffix is not null
 union all select m.customer360_id,s.shipping_organization_name_no_suffix from marts.customer360__mapping m join intermediate.int_customer360__stripe s on m.stripe_customer_id=s.customer_id where s.shipping_organization_name_no_suffix is not null
 union all select m.customer360_id,s.organization_name from marts.customer360__mapping m join intermediate.int_customer360__zendesk s on m.zendesk_user_id=s.user_id where s.organization_name is not null
), unique_orgs as (select distinct customer360_id,organization_name from organization_rows)
select customer360_id,organization_name,row_number() over(partition by customer360_id order by organization_name) as index from unique_orgs
