with status_rows as (
 select m.customer360_id,k.is_unsubscribed,k.is_email_invalid,k.do_not_call,
 case when k.is_unsubscribed then 'unsubscribed' when k.is_email_invalid then 'email_invalid' when k.do_not_call then 'do_not_call' else 'active' end as status,'marketo' as source_system
 from marts.customer360__mapping m join intermediate.int_customer360__marketo k on m.marketo_lead_id=k.lead_id
 union all select m.customer360_id,false,false,false,case when s.is_delinquent then 'delinquent' when s.is_deleted then 'deleted' else 'active' end,'stripe'
 from marts.customer360__mapping m join intermediate.int_customer360__stripe s on m.stripe_customer_id=s.customer_id
 union all select m.customer360_id,false,false,false,case when z.is_suspended then 'suspended' when z.is_deleted then 'deleted' when z.is_active=false then 'inactive' else 'active' end,'zendesk'
 from marts.customer360__mapping m join intermediate.int_customer360__zendesk z on m.zendesk_user_id=z.user_id
), aggregated as (
 select customer360_id,bool_or(is_unsubscribed) as is_unsubscribed,bool_or(is_email_invalid) as is_email_invalid,bool_or(do_not_call) as do_not_call,
 bool_or(status='active') as any_active,bool_or(status='suspended') as any_suspended,bool_or(status='delinquent') as any_delinquent,
 string_agg(distinct source_system,', ') as source_systems from status_rows group by customer360_id
)
select customer360_id,is_unsubscribed,is_email_invalid,do_not_call,
 case when is_unsubscribed then 'unsubscribed' when is_email_invalid then 'email_invalid' when any_active then 'active' when any_suspended then 'suspended' when any_delinquent then 'delinquent' else 'inactive' end as overall_status,source_systems
from aggregated
