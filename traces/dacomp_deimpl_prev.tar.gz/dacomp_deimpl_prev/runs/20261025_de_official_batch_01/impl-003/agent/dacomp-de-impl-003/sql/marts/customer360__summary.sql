with email_first as(select * from marts.customer360__email where index=1), phone_first as(select * from marts.customer360__phone where index=1),
name_first as(select * from marts.customer360__name where index=1),org_first as(select * from marts.customer360__organization where index=1),address_first as(select * from marts.customer360__address where rank=1)
select m.customer360_id,m.source_ids,m.customer360_organization_id,m.is_organization_header,e.email,p.phone,n.full_name,o.organization_name,
 a.address_line_1,a.address_line_2,a.city,a.state,a.country,a.country_alt_name,a.postal_code,ip.ip_address
from marts.customer360__mapping m left join email_first e using(customer360_id) left join phone_first p using(customer360_id)
left join name_first n using(customer360_id) left join org_first o using(customer360_id) left join address_first a using(customer360_id)
left join marts.customer360__ip_address ip using(customer360_id)
