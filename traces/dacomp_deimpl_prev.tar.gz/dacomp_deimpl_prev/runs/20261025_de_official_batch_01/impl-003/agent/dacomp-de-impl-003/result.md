【回复用户】

已按 `config/layer_dependencies.yaml` 的执行顺序补齐 `sql/` 下的 28 个 DuckDB SQL 模型，覆盖 staging、intermediate 与 marts 层。所有模型直接引用 `schema.table`，不包含 dbt `ref()`，SQL 文件末尾没有分号。

### 完成内容
- **Staging（3 个模型）**：country codes、state/territory codes、nicknames；实施字段标准化、无效记录过滤、国家引用校验及 alpha-2 唯一性处理。
- **Intermediate（10 个模型）**：Marketo、Stripe、Zendesk 清洗与匹配投影、精确 email 匹配、客户行为与生命周期分析、风险评估。
- **Marts（15 个模型）**：mapping、email/name/organization/phone/address/IP、status、updates、summary、customer，以及客户价值、活动、组织网络和转化漏斗分析。

### 验证结果
- 已运行 `python run.py`，STAGING **3/3**、INTERMEDIATE **10/10**、MARTS **15/15** 成功，管道正常完成并生成 `customer360.duckdb`。
- 将生成模型的列名与文档契约逐表核对，未发现契约列缺失或额外列。
- SQL 自检：未发现文件末尾分号。
- 数据质量抽查：国家 alpha-2 码无重复且 alpha-2/alpha-3 长度符合规则；mapping MD5 标识格式有效；behavior/risk 的 primary_email 非空；status 客户键唯一且状态值符合枚举；email 序号为正数。
- 运行期间发现并修复了一处 behavior 模型 CTE 作用域别名错误；修正后全层运行成功。**最终执行无失败 SQL。**

### 异常处理及剩余影响
- staging 中无法满足必要名称、国家码格式/引用条件的记录被过滤；超出 1–999 的 numeric country code 置为 NULL。country alpha-2 冲突记录通过稳定字段排序保留一条，避免唯一键重复。被删除/去重的原始脏记录不进入下游。
- 中间层按契约保留源业务数据的重复记录，不对 source IDs 做全局去重。下游按这些 ID 关联时，若上游相同 ID 对应多行，可能发生行数扩增；此项属于合同指定的重复保留行为。
- 生命周期模拟交易数、活动量和依赖它们的派生指标按契约使用 `random()`，因此跨次执行不保证完全可复现；执行时间字段及基于当前日期的指标同样随运行时间变化。
- 契约对来源重复记录以及部分聚合排序并未规定唯一 tie-breaker；按 DuckDB 实际行为保留未指定并列顺序，不额外引入业务假设。
