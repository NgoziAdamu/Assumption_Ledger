with email_rows as (
 select m.customer360_id, s.email from marts.customer360__mapping m inner join intermediate.int_customer360__marketo s on m.marketo_lead_id=s.lead_id where s.email is not null
 union all select m.customer360_id,s.email from marts.customer360__mapping m inner join intermediate.int_customer360__stripe s on m.stripe_customer_id=s.customer_id where s.email is not null
 union all select m.customer360_id,s.email from marts.customer360__mapping m inner join intermediate.int_customer360__zendesk s on m.zendesk_user_id=s.user_id where s.email is not null
), unique_emails as (select distinct customer360_id,email from email_rows)
select customer360_id,email,row_number() over(partition by customer360_id order by email) as index from unique_emails
