with zendesk_cleaned as (select * from intermediate.int_customer360__zendesk)
select user_id, organization_id, email, email_address_stripped, email_domain, full_name_clean,
       organization_name_no_suffix, phone, updated_at, created_at, organization_updated_at,
       organization_created_at, 'null_zendesk' as match_placeholder
from zendesk_cleaned
