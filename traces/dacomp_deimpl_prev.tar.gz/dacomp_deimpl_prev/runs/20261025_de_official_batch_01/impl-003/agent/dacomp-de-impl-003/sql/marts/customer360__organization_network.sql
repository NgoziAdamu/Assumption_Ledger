with entities as (
 select ba.primary_email,ba.marketo_lead_id,ba.stripe_customer_id,ba.zendesk_user_id,ba.primary_organization,ba.customer_journey_pattern,ba.customer_segment,ba.composite_engagement_score,
 lm.customer_health_score,lm.estimated_customer_ltv,lm.customer_tier,lm.lifecycle_stage,
 va.adjusted_ltv,va.strategic_classification,va.revenue_tier,
 case when ba.primary_organization is null or trim(ba.primary_organization)='' then 'INDIVIDUAL_CUSTOMER' else upper(trim(ba.primary_organization)) end as standardized_org_name,
 coalesce(nullif(split_part(ba.primary_email,'@',2),''),'unknown.domain') as email_domain
 from intermediate.int_customer360__customer_behavior_analysis ba
 left join intermediate.int_customer360__customer_lifecycle_metrics lm using(primary_email)
 left join marts.customer360__customer_value_analysis va using(primary_email)
), classified as (
 select *,case when primary_organization is null or trim(primary_organization)='' then 'Individual'
 when regexp_matches(lower(primary_organization),'inc|corp|llc|ltd') then 'Corporation'
 when regexp_matches(lower(primary_organization),'university|college|school') then 'Education'
 when regexp_matches(lower(primary_organization),'government|dept|agency') then 'Government'
 when regexp_matches(lower(primary_organization),'nonprofit|foundation|charity') then 'Non-Profit' else 'Business' end as organization_type,
 case when lower(email_domain) in ('gmail.com','yahoo.com','hotmail.com','outlook.com') then 'Personal'
 when lower(email_domain) in ('microsoft.com','google.com','amazon.com','apple.com','facebook.com') then 'Enterprise'
 when length(primary_organization)>20 then 'Large Business' when length(primary_organization)>10 then 'Medium Business' when length(primary_organization)>0 then 'Small Business' else 'Individual' end as estimated_org_size
 from entities
), aggs as (
 select standardized_org_name,email_domain,organization_type,estimated_org_size,count(distinct primary_email)::bigint as total_contacts,
 count(distinct primary_email) filter(where marketo_lead_id is not null)::bigint as marketing_contacts,
 count(distinct primary_email) filter(where stripe_customer_id is not null)::bigint as sales_contacts,
 count(distinct primary_email) filter(where zendesk_user_id is not null)::bigint as support_contacts,
 count(distinct email_domain)::bigint as email_domains_count,count(distinct customer_tier)::bigint as customer_tiers_represented,
 sum(estimated_customer_ltv) as total_organization_ltv,sum(adjusted_ltv) as total_adjusted_ltv,avg(estimated_customer_ltv) as avg_customer_ltv,max(estimated_customer_ltv) as highest_customer_ltv,
 avg(composite_engagement_score) as avg_engagement_score,max(composite_engagement_score) as max_engagement_score,avg(customer_health_score) as avg_health_score,
 count(distinct primary_email) filter(where customer_journey_pattern='Full Journey')::bigint as full_journey_contacts,
 count(distinct primary_email) filter(where strategic_classification='Strategic Account')::bigint as strategic_accounts,
 count(distinct primary_email) filter(where strategic_classification='Key Account')::bigint as key_accounts,
 count(distinct primary_email) filter(where strategic_classification='Growth Account')::bigint as growth_accounts,
 count(distinct primary_email) filter(where strategic_classification='Recovery Account')::bigint as recovery_accounts,
 count(distinct primary_email) filter(where customer_segment='Champion')::bigint as champions,
 count(distinct primary_email) filter(where customer_segment='Loyal Customer')::bigint as loyal_customers,
 count(distinct primary_email) filter(where customer_segment='At Risk')::bigint as at_risk_customers,
 count(distinct primary_email) filter(where revenue_tier='Tier 1 - Strategic')::bigint as tier1_contacts,
 count(distinct primary_email) filter(where revenue_tier='Tier 2 - High Value')::bigint as tier2_contacts,
 count(distinct primary_email) filter(where revenue_tier='Tier 3 - Core')::bigint as tier3_contacts,
 count(distinct primary_email) filter(where lifecycle_stage='Growth')::bigint as growth_stage_contacts,
 count(distinct primary_email) filter(where lifecycle_stage='Maturity')::bigint as maturity_stage_contacts,
 count(distinct primary_email) filter(where lifecycle_stage='Dormant')::bigint as dormant_contacts
 from classified group by all
), scored as (
 select *,round((case when total_organization_ltv>=50000 then 5 when total_organization_ltv>=25000 then 4 when total_organization_ltv>=10000 then 3 when total_organization_ltv>=5000 then 2 else 1 end*.4+
 case when total_contacts>=10 then 5 when total_contacts>=5 then 4 when total_contacts>=3 then 3 when total_contacts>=2 then 2 else 1 end*.3+
 case when avg_engagement_score>=4 then 5 when avg_engagement_score>=3 then 4 when avg_engagement_score>=2.5 then 3 when avg_engagement_score>=2 then 2 else 1 end*.3),2)::decimal(14,1) as organization_value_score,
 round(.4*coalesce(avg_health_score,0)+.3*(champions+loyal_customers)::double/nullif(total_contacts,0)*5+.3*(growth_stage_contacts+maturity_stage_contacts)::double/nullif(total_contacts,0)*5,2) as organization_health_score,
 round(5.0*(marketing_contacts+sales_contacts+support_contacts)::double/(3*nullif(total_contacts,0)),2) as account_penetration_score,
 round(100*(.3*marketing_contacts+.4*sales_contacts+.3*support_contacts)::double/nullif(total_contacts,0),2) as engagement_breadth_percentage,
 case when total_contacts>=10 and full_journey_contacts>=3 then 'Mature Enterprise' when total_contacts>=5 and strategic_accounts+key_accounts>=2 then 'Developing Enterprise' when total_contacts>=3 and total_organization_ltv>=10000 then 'Mid-Market' when total_contacts>=2 then 'Small Business' else 'Individual/Micro' end as organization_maturity,
 case when growth_accounts>=2 and avg_engagement_score>=3 then 'High Growth Potential' when growth_accounts>=1 or avg_engagement_score>=3.5 then 'Medium Growth Potential' when total_contacts>=2 and avg_health_score>=3 then 'Stable Growth Potential' else 'Limited Growth Potential' end as growth_potential,
 case when at_risk_customers>=.5*total_contacts then 'High Risk' when dormant_contacts>=.3*total_contacts then 'Medium Risk' when recovery_accounts>=1 then 'Attention Needed' else 'Stable' end as organization_risk_level,
 case when strategic_accounts>=2 or total_organization_ltv>=100000 then 'Strategic Enterprise' when key_accounts>=2 or total_organization_ltv>=50000 then 'Key Enterprise' when total_contacts>=5 or total_organization_ltv>=25000 then 'Important Account' when total_contacts>=2 or total_organization_ltv>=10000 then 'Standard Account' else 'Small Account' end as strategic_value_tier,
 case when total_contacts=1 then 'High Concentration Risk' when total_contacts<=3 then 'Medium Concentration Risk' when email_domains_count=1 and total_contacts>=5 then 'Domain Concentration Risk' else 'Low Concentration Risk' end as concentration_risk
 from aggs
), network as (
 select *,round(100*total_organization_ltv/nullif(sum(total_organization_ltv) over(partition by organization_type),0),4) as market_share_within_type,
 row_number() over(partition by organization_type order by total_organization_ltv desc) as ltv_rank_within_type,
 row_number() over(partition by organization_type order by total_contacts desc) as contacts_rank_within_type,
 row_number() over(partition by organization_type order by organization_value_score desc) as value_score_rank_within_type,
 case when total_contacts>=5 and marketing_contacts=0 then 3 when total_contacts>=3 and sales_contacts=0 then 3 when total_contacts>=2 and support_contacts=0 then 2 else 0 end+
 case growth_potential when 'High Growth Potential' then 2 when 'Medium Growth Potential' then 1 else 0 end+
 case when avg_engagement_score>=3.5 then 2 when avg_engagement_score>=3 then 1 else 0 end as cross_sell_opportunity_score
 from scored
), final as (
 select *,case when strategic_value_tier in ('Strategic Enterprise','Key Enterprise') and growth_potential='High Growth Potential' then 'Immediate Expansion' when organization_value_score>=4 and organization_health_score>=4 then 'High Priority Expansion' when total_contacts>=3 and avg_engagement_score>=3 then 'Medium Priority Expansion' when total_contacts>=2 and organization_risk_level='Stable' then 'Low Priority Expansion' else 'Maintenance Mode' end as expansion_priority,
 case when organization_risk_level='High Risk' then 'Risk Mitigation & Recovery' when strategic_value_tier='Strategic Enterprise' then 'White Glove Account Management' when strategic_value_tier='Key Enterprise' then 'Dedicated Account Management' when growth_potential='High Growth Potential' then 'Growth & Expansion Focus' when total_contacts=1 then 'Relationship Expansion' else 'Standard Account Management' end as recommended_strategy,
 round(.3*organization_value_score+.3*(case when total_contacts>=10 then 5 when total_contacts>=5 then 4 when total_contacts>=3 then 3 when total_contacts>=2 then 2 else 1 end)+
 .2*(case when engagement_breadth_percentage>=80 then 5 when engagement_breadth_percentage>=60 then 4 when engagement_breadth_percentage>=40 then 3 when engagement_breadth_percentage>=20 then 2 else 1 end)+
 .2*(case when market_share_within_type>=10 then 5 when market_share_within_type>=5 then 4 when market_share_within_type>=2 then 3 when market_share_within_type>=1 then 2 else 1 end),2) as organization_influence_score
 from network
)
select standardized_org_name,email_domain,organization_type,estimated_org_size,organization_maturity,strategic_value_tier,total_contacts,marketing_contacts,sales_contacts,support_contacts,email_domains_count,customer_tiers_represented,total_organization_ltv,total_adjusted_ltv,avg_customer_ltv,highest_customer_ltv,
 round(total_adjusted_ltv*(case when expansion_priority='Immediate Expansion' then 1.5 when expansion_priority='High Priority Expansion' then 1.3 when expansion_priority='Medium Priority Expansion' then 1.1 else 1 end)*(case organization_risk_level when 'High Risk' then .6 when 'Medium Risk' then .8 when 'Attention Needed' then .9 else 1 end),2) as risk_adjusted_organization_value,
 organization_value_score,organization_influence_score,avg_engagement_score,max_engagement_score,avg_health_score,organization_health_score,account_penetration_score,engagement_breadth_percentage,full_journey_contacts,strategic_accounts,key_accounts,growth_accounts,recovery_accounts,champions,loyal_customers,at_risk_customers,tier1_contacts,tier2_contacts,tier3_contacts,organization_risk_level,concentration_risk,growth_potential,cross_sell_opportunity_score,expansion_priority,recommended_strategy,market_share_within_type,ltv_rank_within_type,contacts_rank_within_type,value_score_rank_within_type,current_timestamp as network_analysis_timestamp
from final where standardized_org_name<>'INDIVIDUAL_CUSTOMER' order by organization_influence_score desc,total_organization_ltv desc,total_contacts desc
