select
    s.customer_id, s.email, s.email_address_stripped, s.email_domain, s.customer_name, s.customer_name_clean, s.customer_name_title, s.customer_name_suffix, s.shipping_name, s.shipping_name_clean, s.shipping_name_title, s.shipping_name_suffix, s.customer_organization_name, s.customer_organization_name_no_suffix, s.customer_organization_name_suffix, s.shipping_organization_name, s.shipping_organization_name_no_suffix, s.shipping_organization_name_suffix, s.phone, s.phone_extension, s.shipping_phone, s.shipping_phone_extension, s.customer_address_line_1, s.customer_address_line_1_long, s.customer_address_line_2, s.customer_address_line_2_long, s.customer_city, s.customer_state_code, s.customer_state_long, s.customer_country_code, s.customer_country_long, s.customer_country_long_alt, s.customer_postal_code, s.shipping_address_line_1, s.shipping_address_line_1_long, s.shipping_address_line_2, s.shipping_address_line_2_long, s.shipping_city, s.shipping_state_code, s.shipping_state_long, s.shipping_country_code, s.shipping_country_long, s.shipping_country_long_alt, s.shipping_postal_code, s.is_delinquent, s.is_deleted,
    cast(s.updated_at as timestamp) as updated_at,
    cast(s.created_at as timestamp) as created_at,
    s.customer_possible_alt_first_names,
    s.shipping_possible_alt_first_names
from raw.stripe_customers s
where s.email is not null and s.email <> '' and s.is_deleted = false
