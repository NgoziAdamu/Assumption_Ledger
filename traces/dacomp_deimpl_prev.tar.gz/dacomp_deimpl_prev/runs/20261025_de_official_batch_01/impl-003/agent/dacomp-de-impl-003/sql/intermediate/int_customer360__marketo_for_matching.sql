with marketo_cleaned as (select * from intermediate.int_customer360__marketo)
select lead_id, email, email_address_stripped, email_domain, full_name_clean, first_name_clean, last_name_clean,
       organization_name_no_suffix, inferred_organization_name_no_suffix, phone, company_phone, mobile_phone,
       address_line_1_long, city, state_code, state_long, country_code, country_long, postal_code,
       billing_address_line_1_long, billing_city, billing_state_code, billing_state_long, billing_country_code,
       billing_country_long, billing_postal_code, updated_at, created_at, 'null_marketo' as match_placeholder
from marketo_cleaned
