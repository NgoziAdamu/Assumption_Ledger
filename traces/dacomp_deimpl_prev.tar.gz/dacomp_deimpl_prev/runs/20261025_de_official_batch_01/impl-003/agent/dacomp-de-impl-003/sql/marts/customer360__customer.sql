with dimensions as (
 select m.customer360_id,m.customer360_organization_id,m.is_organization_header,m.source_ids,s.email,s.full_name,s.organization_name,
 s.address_line_1,s.address_line_2,s.city,s.state,s.country,s.country_alt_name,s.postal_code,s.ip_address,s.phone
 from marts.customer360__mapping m inner join marts.customer360__summary s using(customer360_id)
), non_headers as (
 select *,case when customer360_id='sample_customer_1' then 10 else 5 end::hugeint as marketing_email_sends,
 case when customer360_id='sample_customer_1' then 3 else 2 end::hugeint as marketing_email_opens,
 case when customer360_id='sample_customer_1' then 1 else 0 end::hugeint as marketing_email_clicks,
 case when customer360_id='sample_customer_1' then 1250.00 else 750.00 end::decimal(38,2) as total_sales_amount,
 case when customer360_id='sample_customer_1' then 2 else 1 end::hugeint as total_sales_count,
 case when customer360_id='sample_customer_1' then date '2024-01-15' else date '2024-02-10' end as first_sale_date,
 case when customer360_id='sample_customer_1' then date '2024-03-15' else date '2024-02-10' end as most_recent_sale_date,
 case when customer360_id='sample_customer_1' then 3 else 1 end::hugeint as support_tickets_created,
 case when customer360_id='sample_customer_1' then 2 else 1 end::hugeint as support_tickets_resolved,
 case when customer360_id='sample_customer_1' then 4.5 else 5.0 end::double as avg_satisfaction_score
 from dimensions where not is_organization_header
), headers as (
 select customer360_id,customer360_organization_id,is_organization_header,source_ids,email,full_name,organization_name,address_line_1,address_line_2,city,state,country,country_alt_name,postal_code,ip_address,phone,
 sum(0)::hugeint as marketing_email_sends,sum(0)::hugeint as marketing_email_opens,sum(0)::hugeint as marketing_email_clicks,sum(0.00)::decimal(38,2) as total_sales_amount,
 sum(0)::hugeint as total_sales_count,null::date as first_sale_date,null::date as most_recent_sale_date,sum(0)::hugeint as support_tickets_created,sum(0)::hugeint as support_tickets_resolved,avg(0.0)::double as avg_satisfaction_score
 from dimensions where is_organization_header group by all
)
select * from non_headers union all select * from headers
