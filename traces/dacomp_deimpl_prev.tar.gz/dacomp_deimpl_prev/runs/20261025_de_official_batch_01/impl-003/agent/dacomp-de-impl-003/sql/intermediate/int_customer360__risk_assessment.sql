with behavior as (
 select ba.*, lm.customer_health_score, lm.lifecycle_stage, lm.active_30_days, lm.active_90_days,
        lm.platform_consistency_score, lm.estimated_customer_ltv, lm.churn_probability
 from intermediate.int_customer360__customer_behavior_analysis ba
 left join intermediate.int_customer360__customer_lifecycle_metrics lm using (primary_email)
), joined as (
 select b.*, s.is_delinquent, s.is_deleted as stripe_deleted, s.created_at as stripe_account_created,
        s.updated_at as stripe_last_update, z.is_active as zendesk_active, z.is_suspended as zendesk_suspended,
        z.is_deleted as zendesk_deleted, z.organization_id, z.created_at as zendesk_account_created,
        z.updated_at as zendesk_last_update
 from behavior b
 left join intermediate.int_customer360__stripe s on b.stripe_customer_id=s.customer_id
 left join intermediate.int_customer360__zendesk z on b.zendesk_user_id=z.user_id
), risk as (
 select *, case when date_diff('day',customer_last_activity,current_date)>90 then 3
 when date_diff('day',customer_last_activity,current_date)>60 then 2 when date_diff('day',customer_last_activity,current_date)>30 then 1 else 0 end as activity_decline_risk,
 case when in_marketo+in_stripe+in_zendesk=1 then 2 when in_marketo+in_stripe+in_zendesk=2 then 1 else 0 end as platform_abandonment_risk,
 case when lifecycle_stage='Dormant' then 3 when lifecycle_stage='Retention' and customer_health_score<3 then 2
 when lifecycle_stage in ('Acquisition','Activation') and date_diff('day',customer_last_activity,current_date)>30 then 2 else 0 end as lifecycle_transition_risk,
 case when marketo_lead_id is null then 0 when date_diff('day',customer_last_activity,current_date)>60 then 2 when composite_engagement_score<2 then 1 else 0 end as email_engagement_risk,
 case when is_delinquent then 3 when stripe_deleted then 4 when estimated_customer_ltv>5000 and churn_probability>0.5 then 2 else 0 end as payment_behavior_risk,
 case when stripe_customer_id is not null and date_diff('day',stripe_account_created,stripe_last_update)<30 then 1 when stripe_deleted then 3 else 0 end as account_stability_risk,
 case when estimated_customer_ltv>=10000 and churn_probability>=0.5 then 4 when estimated_customer_ltv>=5000 and churn_probability>=0.5 then 3 when estimated_customer_ltv>=2000 and churn_probability>=0.7 then 2 when churn_probability>=0.8 then 1 else 0 end as revenue_at_risk_score,
 case when zendesk_suspended then 3 when zendesk_deleted then 2 when zendesk_active=false then 2 when zendesk_user_id is not null and zendesk_last_update<current_timestamp-interval '90 days' then 1 else 0 end as support_engagement_risk,
 case when organization_id is null and primary_organization is not null then 1 when zendesk_suspended and organization_id is not null then 2 else 0 end as org_relationship_risk,
 case when customer_segment in ('At Risk','Hibernating','Lost') then 2 when churn_risk_level='High Risk' then 3 when lifecycle_stage='Dormant' and zendesk_active=false then 2 else 0 end as satisfaction_risk_score
 from joined where primary_email is not null
), sums as (
 select *, activity_decline_risk+platform_abandonment_risk+lifecycle_transition_risk+email_engagement_risk+payment_behavior_risk+account_stability_risk+revenue_at_risk_score as S,
 round(activity_decline_risk*.2+platform_abandonment_risk*.15+lifecycle_transition_risk*.15+email_engagement_risk*.1+payment_behavior_risk*.25+account_stability_risk*.1+revenue_at_risk_score*.05,2) as total_risk_score
 from risk
), labels as (
 select *, case when S>=8 then 'Critical' when S>=5 then 'High' when S>=3 then 'Medium' when S>=1 then 'Low' else 'Minimal' end as risk_category,
 case when payment_behavior_risk>0 then 'Payment Issues' when activity_decline_risk>0 then 'Engagement Decline' when lifecycle_transition_risk>0 then 'Lifecycle Transition' when revenue_at_risk_score>0 then 'High Value at Risk' when support_engagement_risk>0 then 'Support Issues' when email_engagement_risk>0 then 'Communication Breakdown' else 'Standard Monitoring' end as primary_risk_factor,
 case when date_diff('day',customer_last_activity,current_date)<=7 and customer_health_score>=4 then 'Improving' when date_diff('day',customer_last_activity,current_date)<=30 and churn_probability<.3 then 'Stable' when date_diff('day',customer_last_activity,current_date) between 31 and 60 then 'Declining' when date_diff('day',customer_last_activity,current_date)>60 then 'Deteriorating' else 'Unknown' end as risk_trend,
 round(estimated_customer_ltv*churn_probability,2) as potential_revenue_loss,
 case when payment_behavior_risk>=3 then 'Immediate (24h)' when activity_decline_risk+platform_abandonment_risk+lifecycle_transition_risk>=5 then 'Urgent (1 week)' when revenue_at_risk_score>=3 then 'High Priority (2 weeks)' when activity_decline_risk+email_engagement_risk>=3 then 'Medium Priority (1 month)' else 'Standard Priority' end as intervention_timeline,
 case when payment_behavior_risk>0 then 'Account Management Call' when activity_decline_risk>=2 and estimated_customer_ltv>=5000 then 'Executive Outreach' when support_engagement_risk>0 then 'Customer Success Check-in' when email_engagement_risk>0 then 'Personalized Email Campaign' when platform_abandonment_risk>0 then 'Product Adoption Workshop' when lifecycle_stage is not null then 'Lifecycle-specific Campaign' else 'Automated Monitoring' end as recommended_intervention,
 case when S>=8 then .30 when S>=5 then .60 when S>=3 then .80 when S>=1 then .90 else .95 end as intervention_success_probability
 from sums
), final as (
 select *, round((case risk_category when 'Critical' then 5 when 'High' then 4 when 'Medium' then 3 when 'Low' then 2 else 1 end*.6+
 case when estimated_customer_ltv>=10000 then 5 when estimated_customer_ltv>=5000 then 4 when estimated_customer_ltv>=2000 then 3 when estimated_customer_ltv>=1000 then 2 else 1 end*.4),2)::decimal(13,1) as customer_priority_score,
 round(estimated_customer_ltv*(1-churn_probability)*intervention_success_probability,2) as risk_adjusted_customer_value,
 (payment_behavior_risk>=3 or revenue_at_risk_score>=4) as critical_alert_flag,
 (activity_decline_risk>=2 and estimated_customer_ltv>=3000) as high_value_at_risk_flag,
 (platform_abandonment_risk>=2 and customer_health_score<3) as engagement_warning_flag,
 round(estimated_customer_ltv*intervention_success_probability*.7-case recommended_intervention when 'Account Management Call' then 500 when 'Executive Outreach' then 1000 when 'Customer Success Check-in' then 200 when 'Personalized Email Campaign' then 50 when 'Product Adoption Workshop' then 300 when 'Lifecycle-specific Campaign' then 100 else 25 end,2) as intervention_roi
 from labels
)
select marketo_lead_id, stripe_customer_id, zendesk_user_id, primary_email, primary_organization, composite_engagement_score, customer_segment, churn_risk_level,
 date_diff('day',customer_last_activity,current_date)::bigint as days_since_last_activity, customer_health_score,lifecycle_stage,active_30_days,active_90_days,platform_consistency_score,
 estimated_customer_ltv,churn_probability,activity_decline_risk,platform_abandonment_risk,lifecycle_transition_risk,email_engagement_risk,
 is_delinquent,stripe_deleted,stripe_account_created,stripe_last_update,payment_behavior_risk,account_stability_risk,revenue_at_risk_score,
 zendesk_active,zendesk_suspended,zendesk_deleted,organization_id,zendesk_account_created,zendesk_last_update,support_engagement_risk,org_relationship_risk,satisfaction_risk_score,
 total_risk_score,risk_category,primary_risk_factor,risk_trend,potential_revenue_loss,intervention_timeline,recommended_intervention,intervention_success_probability,
 customer_priority_score,risk_adjusted_customer_value,critical_alert_flag,high_value_at_risk_flag,engagement_warning_flag,intervention_roi,current_timestamp as risk_assessment_timestamp
from final
