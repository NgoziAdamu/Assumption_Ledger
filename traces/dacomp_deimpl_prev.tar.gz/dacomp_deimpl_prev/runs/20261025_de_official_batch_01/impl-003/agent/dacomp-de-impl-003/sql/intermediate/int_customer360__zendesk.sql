select
    z.user_id, z.organization_id, z.email, z.email_address_stripped, z.email_domain, z.full_name, z.full_name_clean, z.name_title, z.name_suffix, z.organization_name, z.organization_name_no_suffix, z.organization_name_suffix, z.phone, z.phone_extension, z.is_active, z.is_deleted, z.is_suspended,
    cast(z.updated_at as timestamp) as updated_at,
    cast(z.created_at as timestamp) as created_at,
    cast(z.organization_updated_at as timestamp) as organization_updated_at,
    cast(z.organization_created_at as timestamp) as organization_created_at,
    z.possible_alt_first_names
from raw.zendesk_users z
where z.email is not null and z.email <> '' and z.is_deleted = false
