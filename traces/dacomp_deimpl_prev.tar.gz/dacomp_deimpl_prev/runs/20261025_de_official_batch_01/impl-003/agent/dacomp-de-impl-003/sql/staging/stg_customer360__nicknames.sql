select trim(canonical_name) as canonical_name, trim(nickname) as nickname
from raw.nicknames
where canonical_name is not null and trim(canonical_name) <> ''
  and nickname is not null and trim(nickname) <> ''
