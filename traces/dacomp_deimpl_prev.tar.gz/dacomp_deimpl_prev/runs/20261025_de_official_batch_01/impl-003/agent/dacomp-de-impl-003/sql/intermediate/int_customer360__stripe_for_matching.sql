with stripe_cleaned as (select * from intermediate.int_customer360__stripe)
select customer_id, email, email_address_stripped, email_domain, customer_name_clean, shipping_name_clean,
       customer_organization_name_no_suffix, shipping_organization_name_no_suffix, phone, shipping_phone,
       customer_address_line_1_long, customer_address_line_2_long, customer_city, customer_state_code,
       customer_state_long, customer_country_code, customer_country_long, customer_country_long_alt,
       customer_postal_code, shipping_address_line_1_long, shipping_address_line_2_long, shipping_city,
       shipping_state_code, shipping_state_long, shipping_country_code, shipping_country_long,
       shipping_country_long_alt, shipping_postal_code, updated_at, created_at, 'null_stripe' as match_placeholder
from stripe_cleaned
