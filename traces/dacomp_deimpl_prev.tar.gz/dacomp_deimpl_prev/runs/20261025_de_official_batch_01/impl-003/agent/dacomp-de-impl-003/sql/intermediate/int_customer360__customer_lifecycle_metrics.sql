with base as (
    select *, date_diff('day', customer_last_activity, current_date)::bigint as days_since_last_activity,
           date_trunc('month', customer_first_touchpoint)::date as acquisition_cohort_month,
           case when customer_last_activity >= current_timestamp - interval '30 days' then 1 else 0 end as active_30_days,
           case when customer_last_activity >= current_timestamp - interval '60 days' then 1 else 0 end as active_60_days,
           case when customer_last_activity >= current_timestamp - interval '90 days' then 1 else 0 end as active_90_days,
           case when customer_last_activity >= current_timestamp - interval '180 days' then 1 else 0 end as active_180_days,
           case when customer_last_activity >= current_timestamp - interval '365 days' then 1 else 0 end as active_365_days,
           coalesce(in_marketo,0)+coalesce(in_stripe,0)+coalesce(in_zendesk,0) as platform_sum
    from intermediate.int_customer360__customer_behavior_analysis
), stages as (
    select *, case when account_age_days <= 30 then 'Acquisition'
        when account_age_days <= 90 and active_30_days=1 then 'Activation'
        when account_age_days <= 365 and active_60_days=1 then 'Growth'
        when account_age_days > 365 and active_90_days=1 then 'Maturity'
        when days_since_last_activity > 180 then 'Dormant' else 'Retention' end as lifecycle_stage,
        case when platform_sum>=3 then 3 when platform_sum=2 then 2 else 1 end as platform_consistency_score,
        case customer_segment when 'Champion' then 5000.00 when 'Loyal Customer' then 3500.00
          when 'Potential Loyalist' then 2000.00 when 'New Customer' then 800.00 when 'At Risk' then 1200.00
          when 'Hibernating' then 500.00 else 200.00 end::decimal(6,2) as estimated_customer_value,
        case when days_since_last_activity<=7 then 5 when days_since_last_activity<=30 then 4
          when days_since_last_activity<=60 then 3 when days_since_last_activity<=180 then 2 else 1 end as recency_score,
        case when platform_sum>=2 and active_90_days=1 then 3 when active_180_days=1 then 2 else 1 end as frequency_score
    from base
), health as (
    select *, round(recency_score*0.3 + platform_consistency_score*0.3 +
       (case customer_segment when 'Champion' then 5.0 when 'Loyal Customer' then 4.5 when 'Potential Loyalist' then 3.5
        when 'New Customer' then 3.0 when 'At Risk' then 2.0 when 'Hibernating' then 1.5 else 1.0 end)*0.4,2)::decimal(15,2) as customer_health_score,
       case when customer_segment in ('Champion','Loyal Customer') then 2+floor(random()*8)
            when customer_segment='Potential Loyalist' then 1+floor(random()*4) else floor(random()*2) end::double as estimated_transaction_count
    from stages
), measures as (
    select *, round(estimated_customer_value*(1+0.2*frequency_score)*(1+0.1*platform_consistency_score)*
       (case lifecycle_stage when 'Growth' then 1.5 when 'Maturity' then 2.0 when 'Retention' then 1.8 when 'Activation' then 1.2 else 1.0 end),2)::decimal(18,2) as estimated_customer_ltv,
       case when customer_health_score>=4.5 then 0.95 when customer_health_score>=4 then 0.85 when customer_health_score>=3.5 then 0.75 when customer_health_score>=3 then 0.65 when customer_health_score>=2.5 then 0.50 when customer_health_score>=2 then 0.35 else 0.20 end::decimal(3,2) as retention_probability,
       case when customer_health_score>=4.5 then 0.05 when customer_health_score>=4 then 0.15 when customer_health_score>=3.5 then 0.25 when customer_health_score>=3 then 0.35 when customer_health_score>=2.5 then 0.50 when customer_health_score>=2 then 0.65 else 0.80 end::decimal(3,2) as churn_probability
    from health
), outputs as (
    select *, round(estimated_customer_value*churn_probability,2)::decimal(9,2) as revenue_at_risk,
       case when lifecycle_stage in ('Acquisition','Activation') and customer_health_score>=3.5 then 'High Growth Potential'
            when lifecycle_stage='Growth' and platform_consistency_score>=2 then 'Expansion Ready'
            when lifecycle_stage='Maturity' and customer_health_score>=4 then 'Upsell Candidate'
            when lifecycle_stage='Retention' and customer_health_score>=3 then 'Stable Account'
            when lifecycle_stage='Dormant' then 'Reactivation Needed' else 'Monitor' end as growth_potential,
       case when churn_probability>=0.65 then 5 when lifecycle_stage='Acquisition' and customer_health_score>=3.5 then 4
            when lifecycle_stage='Growth' and platform_consistency_score>=2 then 4
            when customer_health_score>=4 and estimated_customer_value>=3000 then 3
            when churn_probability>=0.35 then 3 else 2 end as action_priority
    from measures
), completed as (
    select *, case when month(acquisition_cohort_month) in (11,12,1) then 'Holiday Season'
       when month(acquisition_cohort_month) in (6,7,8) then 'Summer Season'
       when month(acquisition_cohort_month) in (3,4,5) then 'Spring Season' else 'Fall Season' end as acquisition_season,
       case when estimated_customer_ltv>=8000 then 'Platinum' when estimated_customer_ltv>=5000 then 'Gold'
            when estimated_customer_ltv>=2500 then 'Silver' when estimated_customer_ltv>=1000 then 'Bronze' else 'Basic' end as customer_tier,
       case when estimated_customer_ltv>=10000 or (customer_segment in ('Champion','Loyal Customer') and platform_consistency_score=3) then true else false end as is_strategic_account,
       case when estimated_customer_ltv>=8000 then 0.90 when estimated_customer_ltv>=5000 then 0.85
            when estimated_customer_ltv>=2500 and lifecycle_stage<>'Dormant' then 0.75
            when estimated_customer_ltv>=1000 and lifecycle_stage in ('Growth','Maturity') then 0.60 else 0.45 end::decimal(3,2) as expected_retention_rate
    from outputs
)
select marketo_lead_id, stripe_customer_id, zendesk_user_id, primary_email, primary_organization,
 customer_first_touchpoint, customer_last_activity, account_age_days, customer_segment, customer_journey_pattern,
 days_since_last_activity, active_30_days, active_60_days, active_90_days, active_180_days, active_365_days,
 lifecycle_stage, acquisition_cohort_month, platform_consistency_score, estimated_customer_value,
 frequency_score, recency_score, estimated_transaction_count, customer_health_score, estimated_customer_ltv,
 retention_probability, churn_probability, revenue_at_risk,
 case when acquisition_cohort_month is not null then year(acquisition_cohort_month)::bigint end as acquisition_year,
 case when acquisition_cohort_month is not null then month(acquisition_cohort_month)::bigint end as acquisition_month,
 case when acquisition_cohort_month is not null then date_diff('month',acquisition_cohort_month::date,current_date)::bigint end as months_since_acquisition,
 acquisition_season, customer_tier, is_strategic_account,
 case action_priority when 5 then 'Immediate' when 4 then 'This Week' when 3 then 'This Month' else 'Routine' end as intervention_urgency,
 expected_retention_rate,
 case when retention_probability>expected_retention_rate then 'Above Expectation'
      when retention_probability>=expected_retention_rate*0.8 then 'Meeting Expectation' else 'Below Expectation' end as performance_vs_expectation,
 growth_potential, action_priority
from completed
