with marketo_stripe as (
    select
        m.lead_id as marketo_id,
        s.customer_id as stripe_id,
        m.updated_at as marketo_updated_at,
        s.updated_at as stripe_updated_at,
        m.created_at as marketo_created_at,
        s.created_at as stripe_created_at
    from intermediate.int_customer360__marketo_for_matching m
    inner join intermediate.int_customer360__stripe_for_matching s
        on m.email = s.email
), marketo_zendesk as (
    select
        m.lead_id as marketo_id,
        z.user_id as zendesk_id,
        m.updated_at as marketo_updated_at,
        z.updated_at as zendesk_updated_at,
        z.organization_updated_at as zendesk_organization_updated_at,
        m.created_at as marketo_created_at,
        z.created_at as zendesk_created_at,
        z.organization_created_at as zendesk_organization_created_at
    from intermediate.int_customer360__marketo_for_matching m
    inner join intermediate.int_customer360__zendesk_for_matching z
        on m.email = z.email
), stripe_zendesk as (
    select
        s.customer_id as stripe_id,
        z.user_id as zendesk_id,
        s.updated_at as stripe_updated_at,
        z.updated_at as zendesk_updated_at,
        z.organization_updated_at as zendesk_organization_updated_at,
        s.created_at as stripe_created_at,
        z.created_at as zendesk_created_at,
        z.organization_created_at as zendesk_organization_created_at
    from intermediate.int_customer360__stripe_for_matching s
    inner join intermediate.int_customer360__zendesk_for_matching z
        on s.email = z.email
), first_merge as (
    select
        coalesce(ms.marketo_id, mz.marketo_id) as marketo_id,
        ms.stripe_id as ms_stripe_id,
        mz.zendesk_id as mz_zendesk_id,
        ms.marketo_updated_at as ms_marketo_updated_at,
        ms.stripe_updated_at as ms_stripe_updated_at,
        mz.marketo_updated_at as mz_marketo_updated_at,
        mz.zendesk_updated_at as mz_zendesk_updated_at,
        mz.zendesk_organization_updated_at as mz_org_updated_at,
        ms.marketo_created_at as ms_marketo_created_at,
        ms.stripe_created_at as ms_stripe_created_at,
        mz.marketo_created_at as mz_marketo_created_at,
        mz.zendesk_created_at as mz_zendesk_created_at,
        mz.zendesk_organization_created_at as mz_org_created_at
    from marketo_stripe ms
    full outer join marketo_zendesk mz
        on ms.marketo_id = mz.marketo_id
), merged as (
    select
        coalesce(f.marketo_id, null) as marketo_id,
        coalesce(f.ms_stripe_id, sz.stripe_id) as stripe_id,
        coalesce(f.mz_zendesk_id, sz.zendesk_id) as zendesk_id,
        greatest(f.ms_marketo_updated_at, f.ms_stripe_updated_at, f.mz_marketo_updated_at,
                 f.mz_zendesk_updated_at, f.mz_org_updated_at, sz.stripe_updated_at,
                 sz.zendesk_updated_at, sz.zendesk_organization_updated_at) as marketo_updated_at,
        coalesce(f.ms_stripe_updated_at, sz.stripe_updated_at) as stripe_updated_at,
        coalesce(f.mz_zendesk_updated_at, sz.zendesk_updated_at) as zendesk_updated_at,
        coalesce(f.mz_org_updated_at, sz.zendesk_organization_updated_at) as zendesk_organization_updated_at,
        least(f.ms_marketo_created_at, f.ms_stripe_created_at, f.mz_marketo_created_at,
              f.mz_zendesk_created_at, f.mz_org_created_at, sz.stripe_created_at,
              sz.zendesk_created_at, sz.zendesk_organization_created_at) as marketo_created_at,
        coalesce(f.ms_stripe_created_at, sz.stripe_created_at) as stripe_created_at,
        coalesce(f.mz_zendesk_created_at, sz.zendesk_created_at) as zendesk_created_at,
        coalesce(f.mz_org_created_at, sz.zendesk_organization_created_at) as zendesk_organization_created_at
    from first_merge f
    full outer join stripe_zendesk sz
        on f.ms_stripe_id = sz.stripe_id
        or f.mz_zendesk_id = sz.zendesk_id
)
select
    marketo_id as marketo_lead_id,
    stripe_id as stripe_customer_id,
    zendesk_id as zendesk_user_id,
    marketo_updated_at,
    stripe_updated_at,
    zendesk_updated_at,
    zendesk_organization_updated_at,
    marketo_created_at,
    stripe_created_at,
    zendesk_created_at,
    zendesk_organization_created_at
from merged
