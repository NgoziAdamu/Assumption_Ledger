with base as (
 select ba.*,lm.lifecycle_stage,lm.customer_health_score,lm.active_30_days,lm.active_60_days,lm.active_90_days,lm.active_180_days,lm.active_365_days,lm.account_age_days,
 m.is_unsubscribed,m.is_email_invalid,m.do_not_call,m.updated_at as m_updated,s.is_delinquent,s.is_deleted as stripe_deleted,s.updated_at as s_updated,
 z.is_active as zendesk_active,z.is_suspended as zendesk_suspended,z.is_deleted as zendesk_deleted,z.updated_at as z_updated,
 m.created_at as marketo_registration_date,s.created_at as stripe_registration_date,z.created_at as zendesk_registration_date,
 m.email as m_email,s.email as s_email,z.email as z_email
 from intermediate.int_customer360__customer_behavior_analysis ba
 left join intermediate.int_customer360__customer_lifecycle_metrics lm using(primary_email)
 left join intermediate.int_customer360__marketo m on ba.marketo_lead_id=m.lead_id
 left join intermediate.int_customer360__stripe s on ba.stripe_customer_id=s.customer_id
 left join intermediate.int_customer360__zendesk z on ba.zendesk_user_id=z.user_id
 where ba.primary_email is not null
), recency as (
 select *,date_diff('day',customer_last_activity,current_date)::bigint as days_since_last_activity,
 (in_marketo+in_stripe+in_zendesk)::integer as active_channel_count,
 case when customer_last_activity is null then null else date_diff('week',customer_last_activity,current_date)::bigint end as weeks_since_last_activity,
 case when customer_last_activity is null then null else date_diff('month',customer_last_activity,current_date)::bigint end as months_since_last_activity
 from base
), channels as (
 select *,case when in_marketo=1 and is_unsubscribed=false and is_email_invalid=false then round(marketo_engagement*(1-date_diff('day',m_updated,current_timestamp)/90.0),2) else 0 end as marketing_engagement_score,
 case when in_stripe=1 and stripe_deleted=false and is_delinquent=false then round(stripe_engagement*(1-date_diff('day',s_updated,current_timestamp)/60.0),2) else 0 end as sales_engagement_score,
 case when in_zendesk=1 and zendesk_active=true and zendesk_suspended=false and zendesk_deleted=false then round(zendesk_engagement*(1-date_diff('day',z_updated,current_timestamp)/120.0),2) else 0 end as support_engagement_score,
 case when days_since_last_activity<=7 and composite_engagement_score>=3 then 'Accelerating' when days_since_last_activity<=14 and composite_engagement_score>=2.5 then 'Steady High'
 when days_since_last_activity<=30 and composite_engagement_score>=2 then 'Steady Medium' when days_since_last_activity<=60 then 'Declining' when days_since_last_activity<=90 then 'Slow' else 'Stagnant' end as engagement_velocity,
 case when days_since_last_activity<=7 and composite_engagement_score>=3.5 then 'High Momentum' when days_since_last_activity<=14 and composite_engagement_score>=3 then 'Medium Momentum'
 when days_since_last_activity<=30 and composite_engagement_score>=2 then 'Low Momentum' when days_since_last_activity<=60 then 'Losing Momentum' else 'No Momentum' end as activity_momentum
 from recency
), scores as (
 select *,round(coalesce(marketing_engagement_score,0)*.3+coalesce(sales_engagement_score,0)*.5+coalesce(support_engagement_score,0)*.2,2) as weighted_engagement_score,
 case when marketing_engagement_score>=sales_engagement_score and marketing_engagement_score>=support_engagement_score then 'Marketing Driven'
 when sales_engagement_score>=support_engagement_score then 'Sales Driven' when support_engagement_score is not null then 'Support Driven' else 'Balanced' end as primary_engagement_channel,
 case when in_marketo=1 then case when marketo_engagement>=4 then 'Deep' when marketo_engagement>=2 then 'Medium' else 'Shallow' end else 'None' end as marketing_depth,
 case when in_stripe=1 then case when stripe_engagement>=4 then 'Deep' when stripe_engagement>=2 then 'Medium' else 'Shallow' end else 'None' end as sales_depth,
 case when in_zendesk=1 then case when zendesk_engagement>=4 then 'Deep' when zendesk_engagement>=2 then 'Medium' else 'Shallow' end else 'None' end as support_depth,
 case when account_age_days>=365 and active_channel_count>=3 then 'Mature Multi-channel' when account_age_days>=180 and active_channel_count>=2 then 'Developing Multi-channel'
 when account_age_days>=90 and active_channel_count>=1 then 'Single Channel Engaged' when account_age_days<90 then 'Early Stage' else 'Minimal Engagement' end as engagement_maturity,
 case when composite_engagement_score>=4 then 15+floor(random()*10) when composite_engagement_score>=3 then 8+floor(random()*7) when composite_engagement_score>=2 then 3+floor(random()*5) when composite_engagement_score>=1 then 1+floor(random()*3) else floor(random()*2) end as estimated_monthly_activities
 from channels
), final_scores as (
 select *,round(composite_engagement_score/nullif(active_channel_count,0),2) as activity_efficiency,
 round(case when in_marketo=1 then marketo_engagement else 0 end + case when in_stripe=1 then stripe_engagement else 0 end + case when in_zendesk=1 then zendesk_engagement else 0 end,2) as cross_platform_consistency,
 case when weighted_engagement_score>=4 and active_channel_count>=3 then 'A+' when weighted_engagement_score>=3.5 and active_channel_count>=2 then 'A' when weighted_engagement_score>=3 then 'B+' when weighted_engagement_score>=2.5 then 'B' when weighted_engagement_score>=2 then 'C+' when weighted_engagement_score>=1.5 then 'C' when weighted_engagement_score>=1 then 'D' else 'F' end as activity_grade,
 round(.4*weighted_engagement_score+.3*active_channel_count+.3*case when days_since_last_activity<=7 and composite_engagement_score>=3.5 then 5 when days_since_last_activity<=14 and composite_engagement_score>=3 then 4 when days_since_last_activity<=30 and composite_engagement_score>=2 then 3 when days_since_last_activity<=60 then 2 else 1 end,2) as activity_priority_score
 from scores
)
select marketo_lead_id,stripe_customer_id,zendesk_user_id,primary_email,primary_organization,customer_segment,customer_journey_pattern,lifecycle_stage,composite_engagement_score,
 weighted_engagement_score,customer_health_score,activity_grade,activity_priority_score,days_since_last_activity,weeks_since_last_activity,months_since_last_activity,account_age_days,active_channel_count,
 primary_engagement_channel,marketing_engagement_score,sales_engagement_score,support_engagement_score,marketing_depth,sales_depth,support_depth,engagement_velocity,activity_momentum,engagement_maturity,
 estimated_monthly_activities,
 estimated_monthly_activities*case engagement_velocity when 'Accelerating' then 1.3 when 'Steady High' then 1.1 when 'Steady Medium' then 1.0 when 'Declining' then .7 when 'Slow' then .4 else .2 end as predicted_next_month_activity,
 estimated_monthly_activities*case when month(current_date) in (11,12,1) then 1.2 when month(current_date) in (6,7,8) then .8 else 1 end as seasonally_adjusted_activity,
 active_30_days,active_60_days,active_90_days,active_180_days,active_365_days,
 case when days_since_last_activity>90 and customer_health_score<3 then 'High Activity Risk' when days_since_last_activity>60 or active_channel_count=1 then 'Medium Activity Risk' when days_since_last_activity>30 then 'Low Activity Risk' else 'No Activity Risk' end as activity_risk_level,
 cross_platform_consistency,activity_efficiency,
 case when engagement_velocity in ('Declining','Slow','Stagnant') and customer_health_score>=3 then 'Re-engagement Campaign' when active_channel_count=1 and composite_engagement_score>=2.5 then 'Channel Expansion'
 when primary_engagement_channel='Marketing Driven' and in_stripe=0 then 'Sales Conversion Focus' when primary_engagement_channel='Sales Driven' and in_zendesk=0 then 'Success Onboarding'
 when days_since_last_activity<=7 and composite_engagement_score>=3.5 then 'Upsell Opportunity' else 'Standard Engagement' end as recommended_activity_intervention,
 in_marketo,in_stripe,in_zendesk,is_unsubscribed,is_email_invalid,do_not_call,is_delinquent,stripe_deleted,zendesk_active,zendesk_suspended,zendesk_deleted,
 customer_first_touchpoint,customer_last_activity,marketo_registration_date,stripe_registration_date,zendesk_registration_date,current_timestamp as activity_analysis_timestamp
from final_scores
