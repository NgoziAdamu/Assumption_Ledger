with phone_rows as (
 select m.customer360_id,s.phone,s.phone_extension::varchar as extension from marts.customer360__mapping m join intermediate.int_customer360__marketo s on m.marketo_lead_id=s.lead_id where s.phone is not null
 union all select m.customer360_id,s.company_phone,s.company_phone_extension::varchar from marts.customer360__mapping m join intermediate.int_customer360__marketo s on m.marketo_lead_id=s.lead_id where s.company_phone is not null
 union all select m.customer360_id,s.mobile_phone,s.mobile_phone_extension from marts.customer360__mapping m join intermediate.int_customer360__marketo s on m.marketo_lead_id=s.lead_id where s.mobile_phone is not null
 union all select m.customer360_id,s.phone,s.phone_extension::varchar from marts.customer360__mapping m join intermediate.int_customer360__stripe s on m.stripe_customer_id=s.customer_id where s.phone is not null
 union all select m.customer360_id,s.shipping_phone,s.shipping_phone_extension::varchar from marts.customer360__mapping m join intermediate.int_customer360__stripe s on m.stripe_customer_id=s.customer_id where s.shipping_phone is not null
 union all select m.customer360_id,s.phone,s.phone_extension::varchar from marts.customer360__mapping m join intermediate.int_customer360__zendesk s on m.zendesk_user_id=s.user_id where s.phone is not null
), unique_phones as (select distinct customer360_id,phone,extension from phone_rows)
select customer360_id,phone,extension,row_number() over(partition by customer360_id order by phone) as index from unique_phones
