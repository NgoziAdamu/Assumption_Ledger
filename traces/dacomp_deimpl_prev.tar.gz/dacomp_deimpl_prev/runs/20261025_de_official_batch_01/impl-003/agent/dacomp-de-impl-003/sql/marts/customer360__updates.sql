with update_rows as (
 select m.customer360_id,k.updated_at as last_updated,k.created_at as first_seen,'marketo' as source_system,'lead_update' as update_type from marts.customer360__mapping m join intermediate.int_customer360__marketo k on m.marketo_lead_id=k.lead_id
 union all select m.customer360_id,s.updated_at,s.created_at,'stripe','customer_update' from marts.customer360__mapping m join intermediate.int_customer360__stripe s on m.stripe_customer_id=s.customer_id
 union all select m.customer360_id,z.updated_at,z.created_at,'zendesk','user_update' from marts.customer360__mapping m join intermediate.int_customer360__zendesk z on m.zendesk_user_id=z.user_id
)
select customer360_id,max(last_updated) as last_updated,min(first_seen) as first_seen,count(*)::bigint as total_updates,
 string_agg(distinct source_system,', ') as updated_by_systems,string_agg(distinct update_type,', ') as update_types
from update_rows group by customer360_id
