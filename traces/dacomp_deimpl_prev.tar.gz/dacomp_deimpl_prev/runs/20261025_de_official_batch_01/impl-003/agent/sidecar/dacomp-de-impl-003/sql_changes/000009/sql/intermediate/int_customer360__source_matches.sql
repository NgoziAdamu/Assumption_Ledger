with marketo_stripe as (
    select m.lead_id as marketo_id, s.customer_id as stripe_id,
           m.updated_at as m_updated, s.updated_at as s_updated,
           m.created_at as m_created, s.created_at as s_created
    from intermediate.int_customer360__marketo_for_matching m
    inner join intermediate.int_customer360__stripe_for_matching s on m.email = s.email
), marketo_zendesk as (
    select m.lead_id as marketo_id, z.user_id as zendesk_id,
           m.updated_at as m_updated, z.updated_at as z_updated,
           z.organization_updated_at as zo_updated, m.created_at as m_created,
           z.created_at as z_created, z.organization_created_at as zo_created
    from intermediate.int_customer360__marketo_for_matching m
    inner join intermediate.int_customer360__zendesk_for_matching z on m.email = z.email
), stripe_zendesk as (
    select s.customer_id as stripe_id, z.user_id as zendesk_id,
           s.updated_at as s_updated, z.updated_at as z_updated,
           z.organization_updated_at as zo_updated, s.created_at as s_created,
           z.created_at as z_created, z.organization_created_at as zo_created
    from intermediate.int_customer360__stripe_for_matching s
    inner join intermediate.int_customer360__zendesk_for_matching z on s.email = z.email
), merged_market as (
    select coalesce(ms.marketo_id, mz.marketo_id) as marketo_id,
           ms.stripe_id as ms_stripe_id, sz.stripe_id as sz_stripe_id,
           mz.zendesk_id as mz_zendesk_id, sz.zendesk_id as sz_zendesk_id,
           ms.m_updated as ms_m_updated, ms.s_updated as ms_s_updated,
           mz.m_updated as mz_m_updated, mz.z_updated as mz_z_updated, mz.zo_updated as mz_zo_updated,
           sz.s_updated as sz_s_updated, sz.z_updated as sz_z_updated, sz.zo_updated as sz_zo_updated,
           ms.m_created as ms_m_created, ms.s_created as ms_s_created,
           mz.m_created as mz_m_created, mz.z_created as mz_z_created, mz.zo_created as mz_zo_created,
           sz.s_created as sz_s_created, sz.z_created as sz_z_created, sz.zo_created as sz_zo_created
    from marketo_stripe ms
    full outer join marketo_zendesk mz on ms.marketo_id = mz.marketo_id
    left join stripe_zendesk sz on (coalesce(ms.stripe_id, '') = sz.stripe_id or mz.zendesk_id = sz.zendesk_id)
), all_matches as (
    select * from merged_market
    union all
    select null::bigint as marketo_id, null::varchar as ms_stripe_id, sz.stripe_id,
           null::bigint as mz_zendesk_id, sz.zendesk_id,
           null::timestamp as ms_m_updated, null::timestamp as ms_s_updated,
           null::timestamp as mz_m_updated, null::timestamp as mz_z_updated, null::timestamp as mz_zo_updated,
           sz.s_updated as sz_s_updated, sz.z_updated as sz_z_updated, sz.zo_updated as sz_zo_updated,
           null::timestamp as ms_m_created, null::timestamp as ms_s_created,
           null::timestamp as mz_m_created, null::timestamp as mz_z_created, null::timestamp as mz_zo_created,
           sz.s_created as sz_s_created, sz.z_created as sz_z_created, sz.zo_created as sz_zo_created
    from stripe_zendesk sz
    where not exists (select 1 from merged_market mm where mm.sz_stripe_id = sz.stripe_id and mm.sz_zendesk_id = sz.zendesk_id)
)
select
    marketo_id as marketo_lead_id,
    coalesce(ms_stripe_id, sz_stripe_id) as stripe_customer_id,
    coalesce(mz_zendesk_id, sz_zendesk_id) as zendesk_user_id,
    greatest(ms_m_updated, ms_s_updated, mz_m_updated, mz_z_updated, mz_zo_updated, sz_s_updated, sz_z_updated, sz_zo_updated) as marketo_updated_at,
    coalesce(ms_s_updated, sz_s_updated) as stripe_updated_at,
    coalesce(mz_z_updated, sz_z_updated) as zendesk_updated_at,
    coalesce(mz_zo_updated, sz_zo_updated) as zendesk_organization_updated_at,
    least(ms_m_created, ms_s_created, mz_m_created, mz_z_created, mz_zo_created, sz_s_created, sz_z_created, sz_zo_created) as marketo_created_at,
    coalesce(ms_s_created, sz_s_created) as stripe_created_at,
    coalesce(mz_z_created, sz_z_created) as zendesk_created_at,
    coalesce(mz_zo_created, sz_zo_created) as zendesk_organization_created_at
from all_matches
