with matches as (
    select * from intermediate.int_customer360__source_matches
), joined as (
    select sm.marketo_lead_id, sm.stripe_customer_id, sm.zendesk_user_id,
           m.email as m_email, s.email as s_email, z.email as z_email,
           m.email_domain as m_domain, s.email_domain as s_domain, z.email_domain as z_domain,
           coalesce(m.organization_name_no_suffix, s.customer_organization_name_no_suffix, z.organization_name_no_suffix) as primary_organization,
           m.created_at as m_created, m.updated_at as m_updated, m.is_unsubscribed, m.is_email_invalid,
           m.organization_name_no_suffix as m_org, m.phone, m.mobile_phone, country_code, state_code, city,
           s.created_at as s_created, s.updated_at as s_updated, s.is_deleted as s_deleted, s.is_delinquent,
           s.customer_address_line_1, s.customer_country_code,
           z.created_at as z_created, z.updated_at as z_updated, z.is_deleted as z_deleted, z.is_suspended, z.is_active,
           z.organization_id, z.organization_name_no_suffix as z_org
    from matches sm
    left join intermediate.int_customer360__marketo m on sm.marketo_lead_id = m.lead_id
    left join intermediate.int_customer360__stripe s on sm.stripe_customer_id = s.customer_id
    left join intermediate.int_customer360__zendesk z on sm.zendesk_user_id = z.user_id
), scored as (
    select *,
        case when m_email is null then null when is_unsubscribed or is_email_invalid then 0
             when date_diff('day', m_created, m_updated) < 30 then 3
             when date_diff('day', m_created, m_updated) < 90 then 2 else 1 end as m_score,
        case when s_email is null then null when s_deleted then 0 when is_delinquent then 1
             when date_diff('day', s_created, s_updated) < 30 then 4
             when date_diff('day', s_created, s_updated) < 90 then 3 else 2 end as s_score,
        case when z_email is null then null when is_suspended or z_deleted then 0 when is_active = false then 1
             when date_diff('day', z_created, z_updated) < 30 then 4
             when date_diff('day', z_created, z_updated) < 90 then 3 else 2 end as z_score,
        case when m_org is not null and length(m_org)>3 then 1 else 0 end as org_score,
        case when phone is not null or mobile_phone is not null then 1 else 0 end as phone_score,
        case when country_code is not null and state_code is not null and city is not null then 3
             when country_code is not null and (state_code is not null or city is not null) then 2
             when country_code is not null then 1 else 0 end as address_score,
        case when s_email is not null and s_deleted = false and is_delinquent = false then 3
             when s_email is not null and is_delinquent = true and s_deleted = false then 1 else 0 end as reliability,
        case when s.customer_address_line_1 is not null and s.customer_country_code is not null then 2
             when s.customer_country_code is not null then 1 else 0 end as billing_score,
        case when z.organization_id is not null and z_org is not null then 2
             when z.organization_id is not null then 1 else 0 end as org_relationship
    from joined
), derived as (
    select *, coalesce(m_email,s_email,z_email) as primary_email,
        coalesce(m_domain,s_domain,z_domain) as email_domain,
        case when m_created is null or s_created is null or z_created is null then null else least(m_created,s_created,z_created) end as first_touch,
        case when m_updated is null or s_updated is null or z_updated is null then null else greatest(m_updated,s_updated,z_updated) end as last_activity,
        coalesce(m_score,0) as me, coalesce(s_score,0) as se, coalesce(z_score,0) as ze,
        (coalesce(m_score,0)*0.3 + coalesce(s_score,0)*0.5 + coalesce(z_score,0)*0.2)::decimal(14,1) as composite
    from scored
), segments as (
    select *, date_diff('day', first_touch, current_date)::bigint as age_days,
        case when m_email is not null then 1 else 0 end as im,
        case when s_email is not null then 1 else 0 end as is_,
        case when z_email is not null then 1 else 0 end as iz,
        case when m_email is not null and s_email is not null and z_email is not null then 'Full Journey'
             when m_email is not null and s_email is not null then 'Marketing to Sales'
             when s_email is not null and z_email is not null then 'Sales to Support'
             when m_email is not null and z_email is not null then 'Marketing to Support'
             when m_email is not null then 'Marketing Only' when s_email is not null then 'Sales Only'
             when z_email is not null then 'Support Only' else 'Unknown' end as journey,
        case when composite >= 3.5 and reliability >= 2 then 'Champion'
             when composite >= 3.0 and m_email is not null and s_email is not null and z_email is not null then 'Loyal Customer'
             when composite >= 2.5 and reliability >= 2 then 'Potential Loyalist'
             when composite >= 2.0 and date_diff('day', first_touch, current_date) < 90 then 'New Customer'
             when composite >= 1.5 then 'At Risk' when composite > 0 then 'Hibernating' else 'Lost' end as segment
    from derived
), labels as (
    select *, case when age_days < 90 then 'New Customer' when age_days < 365 then 'Growing Relationship'
                   when age_days < 1095 then 'Established Customer' else 'Long-term Customer' end as maturity,
        case when reliability=0 or composite<1 then 'High Risk'
             when composite<2 and age_days>365 then 'Medium Risk'
             when last_activity < current_timestamp - interval '90 days' then 'Medium Risk' else 'Low Risk' end as churn_risk
    from segments
)
select marketo_lead_id, stripe_customer_id, zendesk_user_id, primary_email, email_domain, primary_organization,
       first_touch as customer_first_touchpoint, last_activity as customer_last_activity,
       me as marketo_engagement, se as stripe_engagement, ze as zendesk_engagement,
       composite as composite_engagement_score, im as in_marketo, is_ as in_stripe, iz as in_zendesk,
       (coalesce(org_score,0)+coalesce(billing_score,0)+coalesce(org_relationship,0))::integer as organization_data_quality,
       coalesce(phone_score,0)::integer as has_contact_phone,
       (coalesce(address_score,0)+coalesce(billing_score,0))::integer as address_data_quality,
       case when m_created is not null and s_created is not null then date_diff('day',m_created,s_created) end::bigint as marketing_to_sales_days,
       case when s_created is not null and z_created is not null then date_diff('day',s_created,z_created) end::bigint as sales_to_support_days,
       age_days::bigint as account_age_days, maturity as customer_maturity, journey as customer_journey_pattern,
       reliability::integer as payment_reliability, segment as customer_segment,
       churn_risk as churn_risk_level,
       case segment when 'Champion' then 'Upsell/Cross-sell' when 'Loyal Customer' then 'Upsell/Cross-sell'
            when 'Potential Loyalist' then 'Engagement Campaign' when 'New Customer' then 'Onboarding Focus'
            when 'At Risk' then 'Win-back Campaign' when 'Hibernating' then 'Reactivation Campaign'
            else 'Recovery Campaign' end as recommended_action
from labels
where primary_email is not null
