WITH base AS (
    SELECT 'google_ads'::VARCHAR AS source_relation, *
    FROM raw.account_history_data
),
validated AS (
    SELECT source_relation, CAST(id AS VARCHAR(20)) account_id, try_cast(updated_at AS TIMESTAMPTZ)::TIMESTAMP updated_at, currency_code, auto_tagging_enabled, time_zone, descriptive_name account_name, row_number() over(partition by id order by try_cast(updated_at AS TIMESTAMPTZ) desc nulls last)=1 is_most_recent_record
    FROM base
)
SELECT *
FROM validated
WHERE account_id is not null and updated_at is not null and updated_at <= current_timestamp and currency_code is not null and account_name is not null