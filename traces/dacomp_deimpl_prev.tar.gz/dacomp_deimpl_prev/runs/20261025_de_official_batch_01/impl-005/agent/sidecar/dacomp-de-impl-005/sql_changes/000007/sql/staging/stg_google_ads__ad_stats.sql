WITH base AS (
    SELECT 'google_ads'::VARCHAR AS source_relation, *
    FROM raw.ad_stats_data
),
validated AS (
    SELECT source_relation, CAST(customer_id AS VARCHAR(20)) account_id, try_cast(date AS TIMESTAMPTZ)::DATE date_day, CAST(ad_group_id AS VARCHAR(20)) ad_group_id, CAST(ad_id AS VARCHAR(20)) ad_id, CAST(campaign_id AS VARCHAR(20)) campaign_id, case when ad_network_type in ('SEARCH','DISPLAY','MIXED','YOUTUBE') or ad_network_type is null then ad_network_type end ad_network_type, CAST(device AS VARCHAR(20)) device, coalesce(try_cast(clicks AS BIGINT),0) clicks, CAST(coalesce(try_cast(cost_micros AS DOUBLE),0)/1000000.0 AS DECIMAL(15,2)) spend, coalesce(try_cast(impressions AS BIGINT),0) impressions, CAST(0.0 AS DECIMAL(10,2)) conversions, CAST(0.0 AS DECIMAL(15,2)) conversions_value, CAST(0 AS BIGINT) view_through_conversions
    FROM base
)
SELECT *
FROM validated
WHERE account_id is not null and date_day between DATE '2020-01-01' and current_date and ad_group_id is not null and ad_id is not null and campaign_id is not null and ad_network_type in ('SEARCH','DISPLAY','MIXED','YOUTUBE') or ad_network_type is null