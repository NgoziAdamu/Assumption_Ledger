WITH base AS (
    SELECT 'google_ads'::VARCHAR AS source_relation, *
    FROM raw.ad_group_stats_data
),
validated AS (
    SELECT source_relation, CAST(customer_id AS VARCHAR(20)) account_id, try_cast(date AS TIMESTAMPTZ)::DATE date_day, CAST(base_ad_group AS VARCHAR(20)) ad_group_id, CAST(campaign_base_campaign AS VARCHAR(20)) campaign_id, case when ad_network_type in ('SEARCH','DISPLAY','MIXED','YOUTUBE') then ad_network_type end ad_network_type, device, clicks, CAST(cost_micros / 1000000.0 AS DECIMAL(15,2)) spend, impressions, CAST(conversions AS DECIMAL(10,2)) conversions, CAST(conversions_value AS DECIMAL(15,2)) conversions_value, view_through_conversions
    FROM base
)
SELECT *
FROM validated
WHERE account_id is not null and date_day is not null and ad_group_id is not null and campaign_id is not null