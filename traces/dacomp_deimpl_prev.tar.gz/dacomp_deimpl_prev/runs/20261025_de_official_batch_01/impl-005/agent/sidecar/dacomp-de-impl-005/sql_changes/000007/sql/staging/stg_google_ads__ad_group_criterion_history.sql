WITH base AS (
    SELECT 'google_ads'::VARCHAR AS source_relation, *
    FROM raw.ad_group_criterion_history_data
),
validated AS (
    SELECT source_relation, CAST(id AS VARCHAR(20)) criterion_id, try_cast(updated_at AS TIMESTAMPTZ)::TIMESTAMP updated_at, CAST(ad_group_id AS VARCHAR(20)) ad_group_id, type, status, keyword_match_type, keyword_text, row_number() over(partition by id order by try_cast(updated_at AS TIMESTAMPTZ) desc nulls last)=1 is_most_recent_record
    FROM base
)
SELECT *
FROM validated
WHERE criterion_id is not null and updated_at is not null and ad_group_id is not null and status is not null