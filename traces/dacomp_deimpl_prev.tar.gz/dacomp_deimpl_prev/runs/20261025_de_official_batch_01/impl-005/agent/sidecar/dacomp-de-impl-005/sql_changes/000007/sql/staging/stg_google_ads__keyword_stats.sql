WITH base AS (
    SELECT 'google_ads'::VARCHAR AS source_relation, *
    FROM raw.keyword_stats_data
),
validated AS (
    SELECT source_relation, CAST(customer_id AS VARCHAR(20)) account_id, try_cast(date AS TIMESTAMPTZ)::DATE date_day, CAST(ad_group_id AS VARCHAR(20)) ad_group_id, CAST(campaign_id AS VARCHAR(20)) campaign_id, CAST(ad_group_criterion_criterion_id AS VARCHAR(20)) criterion_id, ad_network_type, device, clicks, CAST(cost_micros / 1000000.0 AS DECIMAL(15,2)) spend, impressions, CAST(conversions AS DECIMAL(10,2)) conversions, CAST(conversions_value AS DECIMAL(15,2)) conversions_value, view_through_conversions
    FROM base
)
SELECT *
FROM validated
WHERE account_id is not null and date_day between DATE '2020-01-01' and current_date and ad_group_id is not null and campaign_id is not null and criterion_id is not null