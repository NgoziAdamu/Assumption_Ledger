WITH base AS (
    SELECT 'google_ads'::VARCHAR AS source_relation, *
    FROM raw.ad_history_data
),
validated AS (
    SELECT source_relation, CAST(id AS VARCHAR(20)) ad_id, try_cast(updated_at AS TIMESTAMPTZ)::TIMESTAMP updated_at, CAST(ad_group_id AS VARCHAR(20)) ad_group_id, name ad_name, case when status in ('ENABLED','PAUSED','REMOVED') then status end status, type ad_type, display_url, final_urls, row_number() over(partition by id order by try_cast(updated_at AS TIMESTAMPTZ) desc nulls last)=1 is_most_recent_record
    FROM base
)
SELECT *
FROM validated
WHERE ad_id is not null and updated_at is not null and updated_at <= current_timestamp and ad_group_id is not null and status is not null