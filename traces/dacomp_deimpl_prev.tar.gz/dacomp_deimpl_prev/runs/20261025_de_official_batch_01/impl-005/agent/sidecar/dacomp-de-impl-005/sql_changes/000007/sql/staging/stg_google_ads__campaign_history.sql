WITH base AS (
    SELECT 'google_ads'::VARCHAR AS source_relation, *
    FROM raw.campaign_history_data
),
validated AS (
    SELECT source_relation, CAST(id AS VARCHAR(20)) campaign_id, try_cast(updated_at AS TIMESTAMPTZ)::TIMESTAMP updated_at, name campaign_name, CAST(customer_id AS VARCHAR(20)) account_id, case when advertising_channel_type in ('SEARCH','DISPLAY','SHOPPING','VIDEO','MULTI_CHANNEL') then advertising_channel_type end advertising_channel_type, advertising_channel_subtype, try_cast(start_date AS TIMESTAMPTZ)::DATE start_date, try_cast(end_date AS TIMESTAMPTZ)::DATE end_date, serving_status, status, tracking_url_template, row_number() over(partition by id order by try_cast(updated_at AS TIMESTAMPTZ) desc nulls last)=1 is_most_recent_record
    FROM base
)
SELECT *
FROM validated
WHERE campaign_id is not null and updated_at is not null and campaign_name is not null and account_id is not null and advertising_channel_type is not null and status is not null and (start_date is null or start_date <= current_date) and (end_date is null or start_date is null or end_date >= start_date)