WITH daily_stats AS (
    SELECT * FROM staging.stg_google_ads__account_stats
),
rolling_metrics AS (
    SELECT
        *,
        avg(spend) OVER (PARTITION BY account_id, source_relation ORDER BY date_day ROWS BETWEEN 6 PRECEDING AND CURRENT ROW) AS spend_7d_avg,
        avg(clicks) OVER (PARTITION BY account_id, source_relation ORDER BY date_day ROWS BETWEEN 6 PRECEDING AND CURRENT ROW) AS clicks_7d_avg,
        avg(impressions) OVER (PARTITION BY account_id, source_relation ORDER BY date_day ROWS BETWEEN 6 PRECEDING AND CURRENT ROW) AS impressions_7d_avg,
        lag(spend, 30) OVER (PARTITION BY account_id, source_relation ORDER BY date_day) AS spend_lag_30d,
        lag(conversions, 30) OVER (PARTITION BY account_id, source_relation ORDER BY date_day) AS conversions_lag_30d,
        min(date_day) OVER (PARTITION BY account_id) AS first_activity_date
    FROM daily_stats
),
metrics AS (
    SELECT *,
        round(CASE WHEN impressions > 0 THEN clicks::DOUBLE / impressions * 100 ELSE 0 END, 4)::FLOAT AS ctr,
        round(CASE WHEN clicks > 0 THEN spend / clicks ELSE 0 END, 4) AS cpc,
        round(CASE WHEN impressions > 0 THEN spend / impressions * 1000 ELSE 0 END, 4) AS cpm,
        round(CASE WHEN conversions > 0 THEN spend / conversions END, 4) AS cost_per_conversion,
        round(CASE WHEN spend > 0 AND conversions_value > 0 THEN conversions_value / spend ELSE 0 END, 4) AS roas,
        greatest(date_diff('day', first_activity_date, date_day), 0) AS days_since_first_activity
    FROM rolling_metrics
),
scored AS (
    SELECT *,
        round(CASE WHEN spend_lag_30d > 0 THEN (spend - spend_lag_30d) / spend_lag_30d * 100 END, 2) AS spend_mom_change_pct,
        round(CASE WHEN conversions_lag_30d > 0 THEN (conversions - conversions_lag_30d) / conversions_lag_30d * 100 END, 2) AS conversions_mom_change_pct,
        CASE WHEN ctr IS NULL OR roas IS NULL OR clicks_7d_avg IS NULL THEN NULL ELSE least(100.0, greatest(0.0, ctr * 10 + least(roas * 10, 50) + CASE WHEN cost_per_conversion < 50 THEN 20 ELSE 0 END + CASE WHEN clicks_7d_avg > 100 THEN 10 ELSE clicks_7d_avg / 10 END)) END AS performance_score,
        CASE WHEN days_since_first_activity < 30 THEN 'New Account' WHEN days_since_first_activity < 90 THEN 'Growing Account' WHEN days_since_first_activity < 365 THEN 'Established Account' ELSE 'Mature Account' END AS account_maturity_stage,
        (spend > 0 AND clicks = 0) AS has_spend_no_clicks_flag,
        (clicks > impressions) AS invalid_metrics_flag,
        (spend > 10000) AS high_spend_alert_flag
    FROM metrics
),
with_tier AS (
    SELECT *, CASE WHEN performance_score >= 80 THEN 'Excellent' WHEN performance_score >= 60 THEN 'Good' WHEN performance_score >= 40 THEN 'Average' WHEN performance_score >= 20 THEN 'Below Average' ELSE 'Poor' END AS performance_tier
    FROM scored
)
SELECT
    s.source_relation, s.account_id, a.account_name, a.currency_code, a.time_zone, s.date_day,
    s.spend, s.clicks, s.impressions, s.conversions, s.conversions_value, s.ctr, s.cpc, s.cpm,
    s.cost_per_conversion, s.roas, s.spend_7d_avg, s.clicks_7d_avg, s.impressions_7d_avg,
    s.spend_mom_change_pct, s.conversions_mom_change_pct, s.days_since_first_activity,
    s.account_maturity_stage, s.performance_score, s.performance_tier,
    s.has_spend_no_clicks_flag, s.invalid_metrics_flag, s.high_spend_alert_flag
FROM with_tier s
LEFT JOIN staging.stg_google_ads__account_history a
  ON s.account_id = a.account_id AND s.source_relation = a.source_relation AND a.is_most_recent_record
WHERE s.spend >= 0 AND s.clicks >= 0 AND s.impressions >= 0 AND s.conversions >= 0
  AND s.date_day IS NOT NULL AND s.account_id IS NOT NULL
ORDER BY s.account_id, s.date_day
