WITH stats AS (SELECT * FROM staging.stg_google_ads__campaign_stats), c AS (SELECT * FROM staging.stg_google_ads__campaign_history WHERE is_most_recent_record), a AS (SELECT * FROM staging.stg_google_ads__account_history WHERE is_most_recent_record)
SELECT s.source_relation,s.date_day,a.account_name,c.account_id,a.currency_code,c.campaign_name,s.campaign_id,c.advertising_channel_type,c.advertising_channel_subtype,c.status,
 sum(s.spend) spend,sum(s.clicks) clicks,sum(s.impressions) impressions,sum(s.conversions) conversions,sum(s.conversions_value) conversions_value,sum(s.view_through_conversions) view_through_conversions
FROM stats s LEFT JOIN c USING(source_relation,campaign_id) LEFT JOIN a ON c.source_relation=a.source_relation AND c.account_id=a.account_id
GROUP BY ALL