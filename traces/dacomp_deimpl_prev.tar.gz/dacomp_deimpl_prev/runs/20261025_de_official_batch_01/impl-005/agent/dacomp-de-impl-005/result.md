【回复用户】
已根据 `docs/data_contract.yaml` 与 `config/layer_dependencies.yaml` 实现 SQL 数据管道，文件位于 `sql/staging/`、`sql/intermediate/`、`sql/marts/`，按配置层次直接引用 `schema.table`。SQL 文件未以分号结尾，也未使用 dbt `ref()`。

**验证结果**
- `python run.py` 执行成功：staging 11/11、intermediate 3/3、marts 10/10 模型全部创建。
- 三个 intermediate 模型均各产生 10,000 行；全部 marts 模型均成功。聚合报表输出行数因分组粒度和合同过滤逻辑不同。
- 自检确认 staging account stats 日期不为空，account performance 结果无负花费、点击、展现或转化。

**数据质量与异常处理**
- 缺失关键标识/必需字段、不合法日期及 staging 合同定义的无效日期/枚举记录按模型 SQL 过滤；历史记录按更新时间排序生成最近记录标志。
- 花费 micros 转换为标准货币单位；适用字段使用 TRY_CAST/COALESCE 处理不可解析数值和缺失值。可恢复的数值异常以零值保留，因此源数据缺失会显示为零而非 NULL；严重不合格记录则被排除。
- 按合同保留历史表最近记录的连接行为。若同一键仍有多个 recent 记录，JOIN 可能放大统计数据，此残余影响与合同定义一致。

**合同中未完全明确之处**
- 原始表无 `source_relation` 字段，因此按项目来源生成 `'google_ads'`。
- 源时间戳含时区偏移，使用 DuckDB `try_strptime` 解析更新时间；统计日期转换为 DATE。
- customer acquisition 的细分/建议规则未提供完整精确规则表，channel strategic recommendation 也未规定完整优先级；已采用保守、透明的 CASE 规则。
- campaign health score 中 cost-per-conversion 线性递减率未给出；实现为达到 100 时得 20 分，每高出 5 个单位扣 1 分，最低 0 分。

开发验证期间发现并修复时间格式解析及连接/CTE 作用域问题；最终完整执行无失败 SQL。
