WITH base AS (
    SELECT 'google_ads'::VARCHAR AS source_relation, *
    FROM raw.search_term_keyword_stats_data
),
validated AS (
    SELECT
        source_relation,
        CAST(customer_id AS VARCHAR(20)) AS account_id,
        try_cast(date AS DATE) AS date_day,
        CAST(ad_group_id AS VARCHAR(20)) AS ad_group_id,
        CAST(campaign_id AS VARCHAR(20)) AS campaign_id,
        CASE WHEN keyword_ad_group_criterion IS NOT NULL AND keyword_ad_group_criterion <> '' THEN CAST(keyword_ad_group_criterion AS VARCHAR(20)) END AS criterion_id,
        CASE WHEN search_term_match_type IN ('EXACT','PHRASE','BROAD','NEAR_EXACT','NEAR_PHRASE') THEN search_term_match_type END AS search_term_match_type,
        CASE WHEN search_term <> '' THEN search_term END AS search_term,
        'SEARCH' AS ad_network_type,
        'UNKNOWN'::VARCHAR(20) AS device,
        coalesce(try_cast(clicks AS BIGINT),0) AS clicks,
        CAST(coalesce(try_cast(cost_micros AS DOUBLE),0)/1000000.0 AS DECIMAL(15,2)) AS spend,
        coalesce(try_cast(impressions AS BIGINT),0) AS impressions,
        CAST(coalesce(try_cast(conversions AS DOUBLE),0.0) AS DECIMAL(10,2)) AS conversions,
        CAST(coalesce(try_cast(conversions_value AS DOUBLE),0.0) AS DECIMAL(15,2)) AS conversions_value,
        coalesce(try_cast(view_through_conversions AS BIGINT),0) AS view_through_conversions
    FROM base
)
SELECT * FROM validated
WHERE account_id IS NOT NULL AND date_day IS NOT NULL AND ad_group_id IS NOT NULL AND campaign_id IS NOT NULL