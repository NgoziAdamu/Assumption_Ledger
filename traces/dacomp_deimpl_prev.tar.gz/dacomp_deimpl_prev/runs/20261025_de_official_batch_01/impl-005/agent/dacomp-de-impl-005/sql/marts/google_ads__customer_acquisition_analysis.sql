WITH ap AS (SELECT * FROM intermediate.int_google_ads__account_performance_metrics), cc AS (SELECT * FROM intermediate.int_google_ads__campaign_cohort_analysis), base AS (
 SELECT ap.*,cc.campaign_id,cc.advertising_channel_type,cc.advertising_channel_subtype,cc.lifecycle_stage campaign_lifecycle_stage FROM ap LEFT JOIN cc ON ap.source_relation=cc.source_relation AND ap.account_id=cc.campaign_id AND ap.date_day=cc.date_day WHERE ap.conversions>0 OR ap.spend>0),
 activity AS (SELECT *,min(date_day) FILTER(WHERE conversions>0) OVER(PARTITION BY account_id) first_conversion_date,
 sum(spend) over(partition by account_id order by date_day rows unbounded preceding) cumulative_acquisition_cost,
 sum(conversions) over(partition by account_id order by date_day rows unbounded preceding) cumulative_conversions,
 sum(conversions_value) over(partition by account_id order by date_day rows unbounded preceding) cumulative_ltv,
 count(distinct campaign_id) over(partition by account_id,date_day) active_campaigns_count,
 count(distinct advertising_channel_type) over(partition by account_id,date_day) channel_diversity_count
 FROM base), economics AS (
 SELECT *,date_trunc('month',first_conversion_date)::DATE acquisition_cohort,date_diff('day',first_conversion_date,date_day) days_since_first_conversion,
 round(cumulative_acquisition_cost/nullif(cumulative_conversions,0),2) customer_acquisition_cost,
 CASE WHEN cumulative_conversions>0 THEN round(cumulative_ltv/cumulative_conversions,2) ELSE 0 END average_customer_ltv,
 CASE WHEN cumulative_acquisition_cost>0 AND cumulative_conversions>0 THEN round((cumulative_ltv/cumulative_conversions)/(cumulative_acquisition_cost/cumulative_conversions),2) ELSE 0 END ltv_cac_ratio,
 round(CASE WHEN cost_per_conversion>0 AND conversions_value>0 AND conversions>0 THEN cost_per_conversion/(conversions_value/conversions)*30 END,0) estimated_payback_days
 FROM activity), benchmarks AS (
 SELECT *,avg(customer_acquisition_cost) FILTER(WHERE cumulative_conversions>0) over(partition by acquisition_cohort,advertising_channel_type) cohort_avg_cac,
 avg(average_customer_ltv) FILTER(WHERE cumulative_conversions>0) over(partition by acquisition_cohort,advertising_channel_type) cohort_avg_ltv,
 percent_rank() over(partition by acquisition_cohort order by customer_acquisition_cost desc) cac_efficiency_percentile,
 percent_rank() over(partition by acquisition_cohort order by ltv_cac_ratio) ltv_cac_performance_percentile
 FROM economics), classifications AS (
 SELECT *,round(CASE WHEN cohort_avg_cac>0 THEN (customer_acquisition_cost-cohort_avg_cac)/cohort_avg_cac*100 END,2) cac_vs_cohort_pct,
 round(CASE WHEN cohort_avg_ltv>0 THEN (average_customer_ltv-cohort_avg_ltv)/cohort_avg_ltv*100 END,2) ltv_vs_cohort_pct,
 CASE WHEN ltv_cac_ratio>=3 THEN 'Excellent' WHEN ltv_cac_ratio>=2 THEN 'Good' WHEN ltv_cac_ratio>=1 THEN 'Break-even' WHEN ltv_cac_ratio>=.5 THEN 'Negative' ELSE 'Poor' END acquisition_efficiency_tier,
 CASE WHEN cac_efficiency_percentile>=.8 THEN 'Top CAC Efficiency' WHEN cac_efficiency_percentile>=.6 THEN 'Above Average CAC' WHEN cac_efficiency_percentile>=.4 THEN 'Average CAC' WHEN cac_efficiency_percentile>=.2 THEN 'Below Average CAC' ELSE 'High CAC' END cac_performance_tier,
 CASE WHEN days_since_first_conversion IS NULL THEN 'Not Acquired' WHEN days_since_first_conversion<=30 THEN 'New Customer' WHEN days_since_first_conversion<=90 THEN 'Early Stage' WHEN days_since_first_conversion<=365 THEN 'Developing Customer' WHEN days_since_first_conversion<=1095 THEN 'Mature Customer' ELSE 'Long-term Customer' END customer_maturity_stage,
 least(100.0,greatest(0.0,channel_diversity_count*15+active_campaigns_count*5+least(average_customer_ltv/100,30)+least(ltv_cac_ratio*5,25))) acquisition_sophistication_score
 FROM benchmarks)
SELECT source_relation,account_id,account_name,date_day,acquisition_cohort,days_since_first_conversion,advertising_channel_type,advertising_channel_subtype,account_maturity_stage,customer_maturity_stage,campaign_lifecycle_stage,spend,clicks,impressions,conversions,conversions_value,ctr,cpc,cost_per_conversion,roas,
 customer_acquisition_cost,average_customer_ltv,ltv_cac_ratio,estimated_payback_days,cumulative_acquisition_cost,cumulative_conversions,cumulative_ltv,cohort_avg_cac,cohort_avg_ltv,cac_vs_cohort_pct,ltv_vs_cohort_pct,cac_efficiency_percentile,ltv_cac_performance_percentile,acquisition_efficiency_tier,cac_performance_tier,
 CASE WHEN ltv_cac_ratio>=4 AND average_customer_ltv>1000 THEN 'High-value scale customer' WHEN ltv_cac_ratio<.5 THEN 'Unprofitable customer' WHEN days_since_first_conversion<=30 THEN 'New customer development' WHEN cac_vs_cohort_pct>50 THEN 'High CAC customer' ELSE 'Core customer' END strategic_customer_segment,
 round(acquisition_sophistication_score,1) acquisition_sophistication_score,active_campaigns_count,channel_diversity_count,
 CASE WHEN ltv_cac_ratio>=3 AND cac_efficiency_percentile>=.8 THEN 'Scale acquisition investment' WHEN ltv_cac_ratio<.5 THEN 'Reduce acquisition cost' WHEN channel_diversity_count<2 THEN 'Diversify acquisition channels' WHEN cac_vs_cohort_pct>30 THEN 'Optimize CAC versus cohort' ELSE 'Maintain acquisition strategy' END acquisition_recommendation,
 (ltv_cac_ratio<.5 AND cumulative_acquisition_cost>1000) negative_roi_alert,(customer_acquisition_cost>cohort_avg_cac*2) high_cac_alert,(ltv_cac_ratio>=4 AND cac_efficiency_percentile>=.9) scale_opportunity,(days_since_first_conversion>365 AND ltv_cac_ratio<1.5) retention_risk
FROM classifications WHERE (cumulative_conversions>0 OR spend>0) AND date_day IS NOT NULL AND account_id IS NOT NULL ORDER BY account_id,date_day DESC