WITH stats AS (SELECT * FROM staging.stg_google_ads__account_stats), accounts AS (SELECT * FROM staging.stg_google_ads__account_history WHERE is_most_recent_record)
SELECT s.source_relation,s.date_day,a.account_name,s.account_id,a.currency_code,a.auto_tagging_enabled,a.time_zone,
 sum(s.spend) spend,sum(s.clicks) clicks,sum(s.impressions) impressions,sum(s.conversions) conversions,sum(s.conversions_value) conversions_value,sum(s.view_through_conversions) view_through_conversions
FROM stats s LEFT JOIN accounts a USING(account_id,source_relation)
GROUP BY ALL