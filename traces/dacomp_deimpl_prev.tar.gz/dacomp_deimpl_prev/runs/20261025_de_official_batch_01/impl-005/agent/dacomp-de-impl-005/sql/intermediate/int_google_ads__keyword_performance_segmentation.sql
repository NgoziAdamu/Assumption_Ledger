WITH ks AS (
    SELECT * FROM staging.stg_google_ads__keyword_stats
),
joined AS (
    SELECT ks.source_relation, ks.criterion_id AS keyword_id, ks.ad_group_id, ks.campaign_id,
        ag.ad_group_name, ch.campaign_name, ch.advertising_channel_type, ks.date_day,
        ks.spend::DOUBLE AS spend, ks.clicks, ks.impressions, ks.conversions::DOUBLE AS conversions,
        ks.conversions_value::DOUBLE AS conversions_value
    FROM ks
    LEFT JOIN staging.stg_google_ads__ad_group_history ag ON ks.ad_group_id=ag.ad_group_id AND ks.source_relation=ag.source_relation AND ag.is_most_recent_record
    LEFT JOIN staging.stg_google_ads__campaign_history ch ON ks.campaign_id=ch.campaign_id AND ks.source_relation=ch.source_relation AND ch.is_most_recent_record
),
metrics AS (
    SELECT *,
        round(CASE WHEN impressions>0 THEN clicks::DOUBLE/impressions*100 ELSE 0 END,4)::FLOAT AS ctr,
        round(CASE WHEN clicks>0 THEN spend/clicks ELSE 0 END,4) AS cpc,
        round(CASE WHEN impressions>0 THEN spend/impressions*1000 ELSE 0 END,4) AS cpm,
        round(CASE WHEN conversions>0 THEN spend/conversions END,4) AS cost_per_conversion,
        round(CASE WHEN spend>0 AND conversions_value>0 THEN conversions_value/spend ELSE 0 END,4) AS roas,
        round(CASE WHEN clicks>0 THEN conversions/clicks*100 ELSE 0 END,4) AS conversion_rate,
        sum(spend) OVER (PARTITION BY keyword_id,ad_group_id ORDER BY date_day ROWS UNBOUNDED PRECEDING) AS lifetime_spend,
        sum(clicks) OVER (PARTITION BY keyword_id,ad_group_id ORDER BY date_day ROWS UNBOUNDED PRECEDING) AS lifetime_clicks,
        sum(conversions) OVER (PARTITION BY keyword_id,ad_group_id ORDER BY date_day ROWS UNBOUNDED PRECEDING) AS lifetime_conversions,
        sum(conversions_value) OVER (PARTITION BY keyword_id,ad_group_id ORDER BY date_day ROWS UNBOUNDED PRECEDING) AS lifetime_conversions_value,
        date_diff('day',min(date_day) OVER (PARTITION BY keyword_id,ad_group_id),date_day) AS days_since_first_activity
    FROM joined
),
benchmarks AS (
    SELECT *, avg(ctr) OVER (PARTITION BY campaign_id,date_day) campaign_avg_ctr,
        avg(cpc) OVER (PARTITION BY campaign_id,date_day) campaign_avg_cpc,
        avg(conversion_rate) OVER (PARTITION BY campaign_id,date_day) campaign_avg_conversion_rate,
        avg(roas) OVER (PARTITION BY campaign_id,date_day) campaign_avg_roas,
        percent_rank() OVER (PARTITION BY campaign_id,date_day ORDER BY ctr) ctr_percentile_in_campaign,
        percent_rank() OVER (PARTITION BY campaign_id,date_day ORDER BY conversion_rate) conv_rate_percentile_in_campaign,
        percent_rank() OVER (PARTITION BY campaign_id,date_day ORDER BY roas DESC) roas_percentile_in_campaign
    FROM metrics
),
classified AS (
 SELECT *, round(CASE WHEN campaign_avg_ctr>0 THEN (ctr-campaign_avg_ctr)/campaign_avg_ctr*100 END,2) ctr_vs_campaign_pct,
    round(CASE WHEN campaign_avg_roas>0 THEN (roas-campaign_avg_roas)/campaign_avg_roas*100 END,2) roas_vs_campaign_pct,
    CASE WHEN days_since_first_activity<7 THEN 'New Keyword' WHEN days_since_first_activity<30 THEN 'Testing Phase' WHEN days_since_first_activity<90 THEN 'Optimization Phase' WHEN days_since_first_activity<365 THEN 'Mature Keyword' ELSE 'Legacy Keyword' END keyword_maturity_stage,
    CASE WHEN ctr_percentile_in_campaign>=.8 AND conv_rate_percentile_in_campaign>=.8 THEN 'Star Performer' WHEN ctr_percentile_in_campaign>=.6 AND conv_rate_percentile_in_campaign>=.6 THEN 'Strong Performer' WHEN ctr_percentile_in_campaign>=.4 AND conv_rate_percentile_in_campaign>=.4 THEN 'Average Performer' WHEN ctr_percentile_in_campaign>=.2 OR conv_rate_percentile_in_campaign>=.2 THEN 'Weak Performer' ELSE 'Poor Performer' END performance_tier,
    CASE WHEN roas>campaign_avg_roas*1.5 AND ctr>campaign_avg_ctr*1.2 THEN 'Increase Bid (+20%)' WHEN roas>campaign_avg_roas*1.2 AND ctr>campaign_avg_ctr THEN 'Increase Bid (+10%)' WHEN roas<campaign_avg_roas*.7 AND ctr<campaign_avg_ctr*.8 THEN 'Decrease Bid (-20%)' WHEN roas<campaign_avg_roas*.8 AND ctr<campaign_avg_ctr THEN 'Decrease Bid (-10%)' WHEN conversions=0 AND days_since_first_activity>30 THEN 'Consider Pausing' ELSE 'Maintain Bid' END bid_recommendation,
    round(least(100.0,greatest(0.0,coalesce(ctr_percentile_in_campaign,0)*30+coalesce(conv_rate_percentile_in_campaign,0)*40+coalesce(roas_percentile_in_campaign,0)*30)),1) efficiency_score,
    CASE WHEN lifetime_spend<100 THEN 'Low Volume' WHEN lifetime_spend<1000 THEN 'Medium Volume' WHEN lifetime_spend<5000 THEN 'High Volume' ELSE 'Premium Volume' END volume_tier,
    CASE WHEN lifetime_conversions_value<500 THEN 'Low Value' WHEN lifetime_conversions_value<2500 THEN 'Medium Value' WHEN lifetime_conversions_value<10000 THEN 'High Value' ELSE 'Premium Value' END value_tier
 FROM benchmarks
)
SELECT *, clicks>impressions data_quality_flag, (spend>100 AND conversions=0 AND days_since_first_activity>14) optimization_needed_flag,
       (roas>5 AND ctr>campaign_avg_ctr*1.5) scale_opportunity_flag,
       (efficiency_score<20 AND days_since_first_activity>30) pause_candidate_flag
FROM classified
WHERE spend>=0 AND clicks>=0 AND impressions>=0 AND conversions>=0 AND date_day IS NOT NULL AND keyword_id IS NOT NULL AND ad_group_id IS NOT NULL AND campaign_id IS NOT NULL
ORDER BY keyword_id,ad_group_id,date_day
