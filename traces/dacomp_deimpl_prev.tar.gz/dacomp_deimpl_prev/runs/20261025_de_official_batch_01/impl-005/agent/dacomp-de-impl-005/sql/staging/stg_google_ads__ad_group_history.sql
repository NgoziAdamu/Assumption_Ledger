WITH base AS (
    SELECT 'google_ads'::VARCHAR AS source_relation, *
    FROM raw.ad_group_history_data
),
validated AS (
    SELECT source_relation, CAST(id AS VARCHAR(20)) ad_group_id, try_strptime(updated_at, '%Y-%m-%d %H:%M:%S.%f %z')::TIMESTAMP updated_at, name ad_group_name, CAST(campaign_id AS VARCHAR(20)) campaign_id, type ad_group_type, status, row_number() over(partition by id order by try_cast(updated_at AS TIMESTAMPTZ) desc nulls last)=1 is_most_recent_record
    FROM base
)
SELECT *
FROM validated
WHERE ad_group_id is not null and campaign_id is not null and status is not null