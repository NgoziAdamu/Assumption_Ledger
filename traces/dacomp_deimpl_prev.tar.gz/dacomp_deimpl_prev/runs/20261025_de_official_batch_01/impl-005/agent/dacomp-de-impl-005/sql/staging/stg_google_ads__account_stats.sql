WITH base AS (
    SELECT 'google_ads'::VARCHAR AS source_relation, *
    FROM raw.account_stats_data
),
validated AS (
    SELECT source_relation, CAST(customer_id AS VARCHAR(20)) account_id, try_cast(date AS DATE) date_day, ad_network_type, device, clicks, CAST(cost_micros / 1000000.0 AS DECIMAL(15,2)) spend, impressions, CAST(conversions AS DECIMAL(10,2)) conversions, CAST(conversions_value AS DECIMAL(15,2)) conversions_value, view_through_conversions
    FROM base
)
SELECT *
FROM validated
WHERE account_id is not null and date_day is not null