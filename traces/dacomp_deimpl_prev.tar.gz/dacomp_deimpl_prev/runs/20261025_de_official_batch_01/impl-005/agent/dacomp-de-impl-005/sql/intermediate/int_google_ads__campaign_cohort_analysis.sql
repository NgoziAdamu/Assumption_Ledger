WITH history AS (
    SELECT * FROM staging.stg_google_ads__campaign_history WHERE is_most_recent_record
),
stats AS (
    SELECT * FROM staging.stg_google_ads__campaign_stats
),
joined AS (
    SELECT s.source_relation, s.campaign_id, h.campaign_name, h.advertising_channel_type,
        h.advertising_channel_subtype, h.status AS campaign_status, s.date_day,
        date_trunc('month', h.start_date)::DATE AS campaign_launch_cohort,
        date_diff('day', h.start_date, s.date_day) AS days_since_launch,
        s.spend::DOUBLE AS spend, s.clicks, s.impressions, s.conversions::DOUBLE AS conversions,
        s.conversions_value::DOUBLE AS conversions_value
    FROM stats s INNER JOIN history h USING (campaign_id, source_relation)
),
base_metrics AS (
    SELECT *,
        CASE WHEN days_since_launch <= 7 THEN 'Launch Phase' WHEN days_since_launch <= 30 THEN 'Optimization Phase' WHEN days_since_launch <= 90 THEN 'Growth Phase' WHEN days_since_launch <= 365 THEN 'Maturity Phase' ELSE 'Legacy Phase' END AS lifecycle_stage,
        round(CASE WHEN impressions > 0 THEN clicks::DOUBLE / impressions * 100 ELSE 0 END,4)::FLOAT AS ctr,
        round(CASE WHEN clicks > 0 THEN spend / clicks ELSE 0 END,4) AS cpc,
        round(CASE WHEN conversions > 0 THEN spend / conversions END,4) AS cost_per_conversion,
        round(CASE WHEN spend > 0 AND conversions_value > 0 THEN conversions_value / spend ELSE 0 END,4) AS roas,
        sum(spend) OVER (PARTITION BY campaign_id, source_relation ORDER BY date_day ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS cumulative_spend,
        sum(clicks) OVER (PARTITION BY campaign_id, source_relation ORDER BY date_day ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS cumulative_clicks,
        sum(conversions) OVER (PARTITION BY campaign_id, source_relation ORDER BY date_day ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS cumulative_conversions,
        sum(conversions_value) OVER (PARTITION BY campaign_id, source_relation ORDER BY date_day ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS cumulative_conversions_value
    FROM joined
),
benchmarks AS (
    SELECT *,
        avg(spend) OVER (PARTITION BY campaign_launch_cohort, lifecycle_stage) AS cohort_avg_spend,
        avg(ctr) OVER (PARTITION BY campaign_launch_cohort, lifecycle_stage) AS cohort_avg_ctr,
        avg(roas) OVER (PARTITION BY campaign_launch_cohort, lifecycle_stage) AS cohort_avg_roas,
        rank() OVER (PARTITION BY campaign_launch_cohort, lifecycle_stage ORDER BY roas DESC NULLS LAST) AS roas_rank_in_cohort,
        count(*) OVER (PARTITION BY campaign_launch_cohort, lifecycle_stage) AS total_campaigns_in_cohort_stage
    FROM base_metrics
),
scored AS (
    SELECT *,
        round(CASE WHEN cohort_avg_spend > 0 THEN (spend - cohort_avg_spend)/cohort_avg_spend*100 END,2) AS spend_vs_cohort_pct,
        round(CASE WHEN cohort_avg_ctr > 0 THEN (ctr - cohort_avg_ctr)/cohort_avg_ctr*100 END,2) AS ctr_vs_cohort_pct,
        round(CASE WHEN cohort_avg_roas > 0 THEN (roas - cohort_avg_roas)/cohort_avg_roas*100 END,2) AS roas_vs_cohort_pct,
        CASE WHEN cost_per_conversion IS NULL THEN NULL ELSE least(100.0,greatest(0.0,ctr*5 + least(roas*20,60) + greatest(0,20 - greatest(cost_per_conversion-100,0)*0.2) + least(cumulative_conversions,10)*2)) END AS campaign_health_score,
        CASE WHEN roas_rank_in_cohort <= ceil(total_campaigns_in_cohort_stage*0.2) THEN 'Top 20%' WHEN roas_rank_in_cohort <= ceil(total_campaigns_in_cohort_stage*0.5) THEN 'Top 50%' WHEN roas_rank_in_cohort <= ceil(total_campaigns_in_cohort_stage*0.8) THEN 'Bottom 50%' ELSE 'Bottom 20%' END AS performance_tier_in_cohort,
        CASE WHEN cumulative_spend < 1000 THEN 'Low Investment' WHEN cumulative_spend < 5000 THEN 'Medium Investment' WHEN cumulative_spend < 20000 THEN 'High Investment' ELSE 'Premium Investment' END AS investment_tier,
        CASE WHEN (lifecycle_stage IN ('Launch Phase','Optimization Phase') AND roas > cohort_avg_roas) OR (lifecycle_stage IN ('Growth Phase','Maturity Phase') AND roas >= cohort_avg_roas*1.2) THEN 'High Momentum' WHEN roas <= cohort_avg_roas*0.8 THEN 'Low Momentum' ELSE 'Stable Momentum' END AS momentum_indicator,
        clicks > impressions AS data_quality_issue,
        (spend > 0 AND conversions = 0 AND days_since_launch > 30) AS underperforming_flag,
        (roas > 10) AS exceptional_performance_flag
    FROM benchmarks
)
SELECT * FROM scored
WHERE spend >= 0 AND clicks >= 0 AND impressions >= 0 AND conversions >= 0 AND date_day IS NOT NULL AND campaign_id IS NOT NULL
ORDER BY campaign_id, date_day
