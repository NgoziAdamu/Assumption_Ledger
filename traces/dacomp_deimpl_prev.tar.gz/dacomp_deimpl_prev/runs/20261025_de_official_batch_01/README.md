# 官方 DE-impl 串行批次

本批是探索性观察，不是预注册实验；任务、设置和顺序在运行前固定，所有结果保留，不挑选。

日期：2026-10-25T00:36:37.932631；模式：user_real；配置模型：gpt-6-luna；服务商：OpenAI。

命令：`bash scripts/run_de_official_batch_01.sh --task-budget-usd 1 --batch-budget-usd 5`。

任务顺序：impl-001 至 impl-030；假模型预检固定使用 impl-001、impl-002。

每题只启动一次，错误和 deferred 不重跑；单题预算拒绝后继续下一题，整批预算拒绝后其余任务记录为未启动。

启动时要求 46917201138 字节（43.70 GiB）空闲；实际空闲 931147325440 字节。

进度见 progress.json，逐题汇总见 summary.csv，逐请求总账见 batch_cost_ledger.jsonl。

报告：[30 号报告](../../notes/30_三十题批量准备.md)。
