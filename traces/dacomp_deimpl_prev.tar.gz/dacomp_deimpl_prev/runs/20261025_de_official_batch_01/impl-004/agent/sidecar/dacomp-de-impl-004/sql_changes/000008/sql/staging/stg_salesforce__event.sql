WITH source_rows AS (
    SELECT
        CAST("id" AS VARCHAR) AS event_id,
        CAST("activity_date" AS TIMESTAMP) AS activity_date,
        CAST("activity_date_time" AS TIMESTAMP) AS activity_date_time,
        CAST("is_deleted" AS BOOLEAN) AS is_deleted,
        CAST("event_description" AS VARCHAR) AS event_description,
        CAST("duration_in_minutes" AS INTEGER) AS duration_in_minutes,
        CAST("end_date_time" AS TIMESTAMP) AS end_date_time,
        CAST("location" AS VARCHAR) AS location,
        CAST("owner_id" AS VARCHAR) AS owner_id,
        CAST("start_date_time" AS TIMESTAMP) AS start_date_time,
        CAST("subject" AS VARCHAR) AS subject,
        CAST("type" AS VARCHAR) AS type,
        CAST("what_id" AS VARCHAR) AS what_id,
        CAST("who_id" AS VARCHAR) AS who_id
    FROM raw.event
),
valid_rows AS (
    SELECT *
    FROM source_rows
    WHERE "id" IS NOT NULL AND
        "is_deleted" IS NOT NULL AND
        "owner_id" IS NOT NULL
),
deduplicated_rows AS (
    SELECT *, ROW_NUMBER() OVER (PARTITION BY event_id ORDER BY event_id) AS _row_num
    FROM valid_rows
)
SELECT * EXCLUDE (_row_num)
FROM deduplicated_rows
WHERE _row_num = 1
