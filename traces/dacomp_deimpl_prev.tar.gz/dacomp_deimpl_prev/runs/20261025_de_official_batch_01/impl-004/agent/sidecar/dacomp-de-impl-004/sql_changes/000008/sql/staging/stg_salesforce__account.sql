WITH source_rows AS (
    SELECT
        CAST("id" AS VARCHAR) AS account_id,
        CAST("name" AS VARCHAR) AS account_name,
        CAST("account_number" AS VARCHAR) AS account_number,
        CAST("account_source" AS VARCHAR) AS account_source,
        CAST("annual_revenue" AS DECIMAL(18,3)) AS annual_revenue,
        CAST("billing_city" AS VARCHAR) AS billing_city,
        CAST("billing_country" AS VARCHAR) AS billing_country,
        CAST("billing_postal_code" AS VARCHAR) AS billing_postal_code,
        CAST("billing_state" AS VARCHAR) AS billing_state,
        CAST("billing_state_code" AS VARCHAR) AS billing_state_code,
        CAST("billing_street" AS VARCHAR) AS billing_street,
        CAST("description" AS VARCHAR) AS account_description,
        CAST("industry" AS VARCHAR) AS industry,
        COALESCE(CAST("is_deleted" AS BOOLEAN), FALSE) AS is_deleted,
        CASE WHEN CAST("last_activity_date" AS DATE) < DATE '2020-01-01' THEN NULL ELSE CAST("last_activity_date" AS DATE) END AS last_activity_date,
        CASE WHEN CAST("last_referenced_date" AS TIMESTAMP) < TIMESTAMP '2020-01-01' OR CAST("last_referenced_date" AS TIMESTAMP) > CURRENT_TIMESTAMP THEN NULL ELSE CAST("last_referenced_date" AS TIMESTAMP) END AS last_referenced_date,
        CASE WHEN CAST("last_viewed_date" AS TIMESTAMP) < TIMESTAMP '2020-01-01' OR CAST("last_viewed_date" AS TIMESTAMP) > CURRENT_TIMESTAMP THEN NULL ELSE CAST("last_viewed_date" AS TIMESTAMP) END AS last_viewed_date,
        CAST("master_record_id" AS VARCHAR) AS master_record_id,
        CAST("number_of_employees" AS INTEGER) AS number_of_employees,
        CAST("owner_id" AS VARCHAR) AS owner_id,
        CAST("ownership" AS VARCHAR) AS ownership,
        CAST("parent_id" AS VARCHAR) AS parent_id,
        CAST("rating" AS VARCHAR) AS rating,
        CAST("record_type_id" AS VARCHAR) AS record_type_id,
        CAST("shipping_city" AS VARCHAR) AS shipping_city,
        CAST("shipping_country" AS VARCHAR) AS shipping_country,
        CAST("shipping_country_code" AS VARCHAR) AS shipping_country_code,
        CASE WHEN CAST("shipping_postal_code" AS VARCHAR) = '' THEN NULL WHEN LENGTH(TRIM(CAST("shipping_postal_code" AS VARCHAR))) > 12 THEN NULL ELSE UPPER(TRIM(CAST("shipping_postal_code" AS VARCHAR))) END AS shipping_postal_code,
        CAST("shipping_state" AS VARCHAR) AS shipping_state,
        CAST("shipping_state_code" AS VARCHAR) AS shipping_state_code,
        CAST("shipping_street" AS VARCHAR) AS shipping_street,
        CAST("type" AS VARCHAR) AS type,
        CAST("website" AS VARCHAR) AS website
    FROM raw.account
),
valid_rows AS (
    SELECT *
    FROM source_rows
    WHERE "id" IS NOT NULL AND
        "name" IS NOT NULL AND
        "is_deleted" IS NOT NULL AND
        (CAST("last_activity_date" AS DATE) IS NULL OR CAST("last_activity_date" AS DATE) <= CURRENT_DATE) AND
        "owner_id" IS NOT NULL AND
        ("shipping_postal_code" IS NULL OR "shipping_postal_code" = '' OR LENGTH(TRIM(CAST("shipping_postal_code" AS VARCHAR))) >= 3)
),
deduplicated_rows AS (
    SELECT *, ROW_NUMBER() OVER (PARTITION BY account_id ORDER BY account_id) AS _row_num
    FROM valid_rows
)
SELECT * EXCLUDE (_row_num)
FROM deduplicated_rows
WHERE _row_num = 1
