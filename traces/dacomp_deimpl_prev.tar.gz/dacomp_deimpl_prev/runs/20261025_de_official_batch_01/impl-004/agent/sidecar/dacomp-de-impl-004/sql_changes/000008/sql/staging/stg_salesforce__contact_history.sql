WITH source_rows AS (
    SELECT
        CAST("id" AS VARCHAR) AS contact_id,
        CAST("id" AS VARCHAR) AS account_id,
        CAST("_fivetran_start" AS TIMESTAMP) AS created_date,
        CAST("description" AS VARCHAR) AS contact_description,
        CAST("email" AS VARCHAR) AS email,
        CAST("first_name" AS VARCHAR) AS first_name,
        CAST("is_deleted" AS BOOLEAN) AS is_deleted,
        CAST("last_activity_date" AS DATE) AS last_activity_date,
        CAST("last_modified_date" AS TIMESTAMP) AS last_modified_date,
        CAST("last_name" AS VARCHAR) AS last_name,
        CAST("lead_source" AS VARCHAR) AS lead_source,
        CAST("mailing_city" AS VARCHAR) AS mailing_city,
        CAST("mailing_country" AS VARCHAR) AS mailing_country,
        CASE WHEN CAST("mailing_postal_code" AS VARCHAR) = '' THEN NULL WHEN LENGTH(TRIM(CAST("mailing_postal_code" AS VARCHAR))) > 12 THEN NULL ELSE UPPER(TRIM(CAST("mailing_postal_code" AS VARCHAR))) END AS mailing_postal_code,
        CAST("mailing_state" AS VARCHAR) AS mailing_state,
        CAST("mailing_street" AS VARCHAR) AS mailing_street,
        CASE WHEN CAST("mobile_phone" AS VARCHAR) = '' THEN NULL WHEN LENGTH(REGEXP_REPLACE(CAST("mobile_phone" AS VARCHAR), '[^0-9]', '')) < 10 THEN NULL ELSE REGEXP_REPLACE(CAST("mobile_phone" AS VARCHAR), '[^0-9+()-]', '') END AS mobile_phone,
        CAST("name" AS VARCHAR) AS contact_name,
        CAST("owner_id" AS VARCHAR) AS owner_id,
        CAST("phone" AS VARCHAR) AS phone,
        CAST("title" AS VARCHAR) AS title,
        CAST("id" AS VARCHAR) AS history_unique_key
    FROM raw.contact_history
)
SELECT *
FROM source_rows
WHERE "id" IS NOT NULL AND
        ("mailing_postal_code" IS NULL OR "mailing_postal_code" = '' OR LENGTH(TRIM(CAST("mailing_postal_code" AS VARCHAR))) >= 3)
