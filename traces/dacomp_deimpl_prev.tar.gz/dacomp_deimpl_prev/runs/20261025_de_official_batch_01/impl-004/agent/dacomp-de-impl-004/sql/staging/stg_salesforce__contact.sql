WITH source_rows AS (
    SELECT
        CAST("id" AS VARCHAR) AS contact_id,
        CAST("account_id" AS VARCHAR) AS account_id,
        CAST("assistant_name" AS VARCHAR) AS assistant_name,
        CAST("assistant_phone" AS VARCHAR) AS assistant_phone,
        CASE WHEN CAST("birthdate" AS DATE) < DATE '1900-01-01' THEN NULL ELSE CAST("birthdate" AS DATE) END AS birthdate,
        CAST(NULL AS TIMESTAMP) AS created_date,
        CAST("department" AS VARCHAR) AS department,
        CAST("description" AS VARCHAR) AS contact_description,
        CAST("email" AS VARCHAR) AS email,
        CAST("email_bounced_date" AS TIMESTAMP) AS email_bounced_date,
        CAST("email_bounced_reason" AS VARCHAR) AS email_bounced_reason,
        CAST("fax" AS VARCHAR) AS fax,
        CAST("first_name" AS VARCHAR) AS first_name,
        CAST("home_phone" AS VARCHAR) AS home_phone,
        COALESCE(CAST("is_deleted" AS BOOLEAN), FALSE) AS is_deleted,
        CAST("is_email_bounced" AS BOOLEAN) AS is_email_bounced,
        CASE WHEN CAST("last_activity_date" AS DATE) < DATE '2020-01-01' THEN NULL ELSE CAST("last_activity_date" AS DATE) END AS last_activity_date,
        CAST("last_curequest_date" AS TIMESTAMP) AS last_curequest_date,
        CAST("last_cuupdate_date" AS TIMESTAMP) AS last_cuupdate_date,
        CAST("last_modified_date" AS TIMESTAMP) AS last_modified_date,
        CAST("last_name" AS VARCHAR) AS last_name,
        CAST("last_referenced_date" AS TIMESTAMP) AS last_referenced_date,
        CAST("last_viewed_date" AS TIMESTAMP) AS last_viewed_date,
        CAST("lead_source" AS VARCHAR) AS lead_source,
        CAST("mailing_city" AS VARCHAR) AS mailing_city,
        CAST("mailing_country" AS VARCHAR) AS mailing_country,
        CAST("mailing_country_code" AS VARCHAR) AS mailing_country_code,
        CASE WHEN CAST("mailing_postal_code" AS VARCHAR) = '' THEN NULL WHEN LENGTH(TRIM(CAST("mailing_postal_code" AS VARCHAR))) > 12 THEN NULL ELSE UPPER(TRIM(CAST("mailing_postal_code" AS VARCHAR))) END AS mailing_postal_code,
        CAST("mailing_state" AS VARCHAR) AS mailing_state,
        CAST("mailing_state_code" AS VARCHAR) AS mailing_state_code,
        CAST("mailing_street" AS VARCHAR) AS mailing_street,
        CAST("master_record_id" AS VARCHAR) AS master_record_id,
        CASE WHEN CAST("mobile_phone" AS VARCHAR) = '' THEN NULL WHEN LENGTH(REGEXP_REPLACE(CAST("mobile_phone" AS VARCHAR), '[^0-9]', '')) < 10 THEN NULL ELSE REGEXP_REPLACE(CAST("mobile_phone" AS VARCHAR), '[^0-9+()-]', '') END AS mobile_phone,
        CAST("name" AS VARCHAR) AS contact_name,
        CAST("other_city" AS VARCHAR) AS other_city,
        CAST("other_country" AS VARCHAR) AS other_country,
        CASE WHEN CAST("other_phone" AS VARCHAR) = '' THEN NULL WHEN LENGTH(REGEXP_REPLACE(CAST("other_phone" AS VARCHAR), '[^0-9]', '')) < 10 THEN NULL ELSE REGEXP_REPLACE(CAST("other_phone" AS VARCHAR), '[^0-9+()-]', '') END AS other_phone,
        CAST("other_postal_code" AS VARCHAR) AS other_postal_code,
        CAST("other_state" AS VARCHAR) AS other_state,
        CAST("other_street" AS VARCHAR) AS other_street,
        CAST("owner_id" AS VARCHAR) AS owner_id,
        CASE WHEN CAST("phone" AS VARCHAR) = '' THEN NULL WHEN LENGTH(REGEXP_REPLACE(CAST("phone" AS VARCHAR), '[^0-9]', '')) < 10 THEN NULL ELSE REGEXP_REPLACE(CAST("phone" AS VARCHAR), '[^0-9+()-]', '') END AS phone,
        CAST("photo_url" AS VARCHAR) AS photo_url,
        CAST("reports_to_id" AS VARCHAR) AS reports_to_id,
        CAST("salutation" AS VARCHAR) AS salutation,
        CAST("title" AS VARCHAR) AS title
    FROM raw.contact
),
valid_rows AS (
    SELECT *
    FROM source_rows
    WHERE contact_id IS NOT NULL AND
        (birthdate IS NULL OR birthdate <= CURRENT_DATE) AND
        is_deleted IS NOT NULL AND
        (last_activity_date IS NULL OR last_activity_date <= CURRENT_DATE) AND
        last_name IS NOT NULL AND
        owner_id IS NOT NULL AND
        ("mailing_postal_code" IS NULL OR "mailing_postal_code" = '' OR LENGTH(TRIM(CAST("mailing_postal_code" AS VARCHAR))) >= 3)
),
deduplicated_rows AS (
    SELECT *, ROW_NUMBER() OVER (PARTITION BY contact_id ORDER BY contact_id) AS _row_num
    FROM valid_rows
)
SELECT * EXCLUDE (_row_num)
FROM deduplicated_rows
WHERE _row_num = 1
