WITH lead_base AS (
    SELECT *
    FROM staging.stg_salesforce__lead
    WHERE is_deleted = FALSE
),
lead_scored AS (
    SELECT
        lead_id,
        first_name,
        last_name,
        CASE
            WHEN first_name IS NOT NULL AND last_name IS NOT NULL
                THEN first_name || ' ' || last_name
            WHEN last_name IS NOT NULL THEN last_name
            ELSE NULL
        END AS lead_name,
        company,
        email,
        phone,
        mobile_phone,
        lead_source,
        status,
        industry,
        annual_revenue,
        number_of_employees,
        is_converted,
        converted_date,
        converted_account_id,
        converted_contact_id,
        converted_opportunity_id,
        owner_id,
        created_date,
        CASE
            WHEN created_date IS NULL THEN NULL
            WHEN is_converted AND converted_date IS NULL THEN NULL
            WHEN is_converted THEN DATE_DIFF('day', CAST(created_date AS DATE), CAST(converted_date AS DATE))
            ELSE DATE_DIFF('day', CAST(created_date AS DATE), CURRENT_DATE)
        END AS lead_age_days,
        CASE
            WHEN is_converted AND created_date IS NOT NULL AND converted_date IS NOT NULL
                THEN DATE_DIFF('day', CAST(created_date AS DATE), CAST(converted_date AS DATE))
            ELSE NULL
        END AS conversion_time_days,
        CASE
            WHEN lead_source IS NULL THEN 'Other'
            WHEN CONTAINS(LOWER(lead_source), 'web')
                OR CONTAINS(LOWER(lead_source), 'online')
                OR CONTAINS(LOWER(lead_source), 'social')
                OR CONTAINS(LOWER(lead_source), 'search') THEN 'Digital'
            WHEN CONTAINS(LOWER(lead_source), 'referral')
                OR CONTAINS(LOWER(lead_source), 'partner')
                OR CONTAINS(LOWER(lead_source), 'word') THEN 'Referral'
            WHEN CONTAINS(LOWER(lead_source), 'trade')
                OR CONTAINS(LOWER(lead_source), 'event')
                OR CONTAINS(LOWER(lead_source), 'conference')
                OR CONTAINS(LOWER(lead_source), 'campaign') THEN 'Marketing'
            WHEN CONTAINS(LOWER(lead_source), 'phone')
                OR CONTAINS(LOWER(lead_source), 'call')
                OR CONTAINS(LOWER(lead_source), 'direct') THEN 'Direct'
            ELSE 'Other'
        END AS lead_source_category,
        CAST(
            (CASE WHEN email IS NOT NULL AND POSITION('@' IN email) > 0
                    AND POSITION('.' IN SUBSTRING(email, POSITION('@' IN email) + 1)) > 0 THEN 20 ELSE 0 END) +
            (CASE WHEN (phone IS NOT NULL AND TRIM(phone) <> '')
                    OR (mobile_phone IS NOT NULL AND TRIM(mobile_phone) <> '') THEN 15 ELSE 0 END) +
            (CASE WHEN industry IS NOT NULL AND TRIM(industry) <> '' THEN 10 ELSE 0 END) +
            (CASE WHEN annual_revenue > 0 THEN 15 ELSE 0 END) +
            (CASE WHEN number_of_employees > 0 THEN 10 ELSE 0 END) +
            (CASE WHEN LOWER(TRIM(lead_source)) IN ('referral', 'website', 'partner referral') THEN 20 ELSE 0 END) +
            (CASE WHEN company IS NOT NULL AND TRIM(company) <> ''
                    AND NOT REGEXP_MATCHES(LOWER(company), 'test|example|demo') THEN 10 ELSE 0 END)
            AS INTEGER
        ) AS lead_quality_score,
        CASE
            WHEN is_converted = TRUE
                AND NULLIF(TRIM(converted_account_id), '') IS NOT NULL
                AND NULLIF(TRIM(converted_contact_id), '') IS NOT NULL
                AND NULLIF(TRIM(converted_opportunity_id), '') IS NOT NULL
            THEN TRUE ELSE FALSE
        END AS has_complete_conversion
    FROM lead_base
),
lead_categorized AS (
    SELECT
        *,
        CASE
            WHEN conversion_time_days IS NULL THEN NULL
            WHEN conversion_time_days <= 7 THEN 'Fast Track'
            WHEN conversion_time_days <= 30 THEN 'Standard'
            WHEN conversion_time_days <= 90 THEN 'Slow'
            ELSE 'Extended'
        END AS conversion_speed_category,
        CASE
            WHEN lead_quality_score >= 80 THEN 'Hot'
            WHEN lead_quality_score >= 60 THEN 'Warm'
            WHEN lead_quality_score >= 40 THEN 'Cool'
            ELSE 'Cold'
        END AS lead_temperature
    FROM lead_scored
)
SELECT
    lead_id,
    first_name,
    last_name,
    lead_name,
    company,
    email,
    phone,
    mobile_phone,
    lead_source,
    status,
    industry,
    annual_revenue,
    number_of_employees,
    is_converted,
    converted_date,
    converted_account_id,
    converted_contact_id,
    converted_opportunity_id,
    owner_id,
    created_date,
    lead_age_days,
    conversion_time_days,
    lead_source_category,
    lead_quality_score,
    has_complete_conversion,
    conversion_speed_category,
    lead_temperature
FROM lead_categorized
