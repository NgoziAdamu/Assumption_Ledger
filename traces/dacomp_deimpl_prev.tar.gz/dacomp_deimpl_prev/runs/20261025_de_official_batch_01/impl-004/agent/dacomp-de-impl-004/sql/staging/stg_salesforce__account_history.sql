WITH source_rows AS (
    SELECT
        CAST("id" AS VARCHAR) AS account_id,
        CAST("account_number" AS VARCHAR) AS account_number,
        CAST("account_source" AS VARCHAR) AS account_source,
        CAST("annual_revenue" AS DECIMAL(18,3)) AS annual_revenue,
        CAST("billing_city" AS VARCHAR) AS billing_city,
        CAST("billing_country" AS VARCHAR) AS billing_country,
        CAST("billing_postal_code" AS VARCHAR) AS billing_postal_code,
        CAST("billing_state" AS VARCHAR) AS billing_state,
        CAST("billing_street" AS VARCHAR) AS billing_street,
        CAST("_fivetran_start" AS TIMESTAMP) AS created_date,
        CAST("description" AS VARCHAR) AS account_description,
        CAST("industry" AS VARCHAR) AS industry,
        COALESCE(CAST("is_deleted" AS BOOLEAN), FALSE) AS is_deleted,
        CAST("last_activity_date" AS DATE) AS last_activity_date,
        CAST("name" AS VARCHAR) AS account_name,
        CAST("number_of_employees" AS INTEGER) AS number_of_employees,
        CAST("owner_id" AS VARCHAR) AS owner_id,
        CAST("ownership" AS VARCHAR) AS ownership,
        CAST("parent_id" AS VARCHAR) AS parent_id,
        CAST("rating" AS VARCHAR) AS rating,
        CAST("shipping_city" AS VARCHAR) AS shipping_city,
        CAST("shipping_country" AS VARCHAR) AS shipping_country,
        CAST("shipping_postal_code" AS VARCHAR) AS shipping_postal_code,
        CAST("shipping_state" AS VARCHAR) AS shipping_state,
        CAST("shipping_street" AS VARCHAR) AS shipping_street,
        CAST("type" AS VARCHAR) AS type,
        CAST("website" AS VARCHAR) AS website,
        CAST(hash("_fivetran_start", "_fivetran_end") AS VARCHAR) AS history_unique_key
    FROM raw.account_history
)
SELECT *
FROM source_rows
WHERE account_id IS NOT NULL
