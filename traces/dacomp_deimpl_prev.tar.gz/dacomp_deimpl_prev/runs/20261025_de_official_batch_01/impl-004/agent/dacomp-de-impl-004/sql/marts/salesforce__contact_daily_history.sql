WITH history_rows AS (
    SELECT
        contact_id,
        CAST(created_date AS DATE) AS snapshot_date,
        account_id,
        contact_name,
        first_name,
        last_name,
        email,
        phone,
        mobile_phone,
        title,
        lead_source,
        owner_id,
        mailing_city,
        mailing_state,
        mailing_country,
        mailing_postal_code,
        last_activity_date,
        created_date
    FROM staging.stg_salesforce__contact_history
    WHERE COALESCE(is_deleted, FALSE) = FALSE
),
ranked_history AS (
    SELECT
        *,
        ROW_NUMBER() OVER (
            PARTITION BY contact_id, snapshot_date
            ORDER BY created_date DESC
        ) AS row_num
    FROM history_rows
)
SELECT
    contact_id,
    snapshot_date,
    account_id,
    contact_name,
    first_name,
    last_name,
    email,
    phone,
    mobile_phone,
    title,
    lead_source,
    owner_id,
    mailing_city,
    mailing_state,
    mailing_country,
    mailing_postal_code,
    last_activity_date
FROM ranked_history
WHERE row_num = 1
ORDER BY contact_id, snapshot_date
