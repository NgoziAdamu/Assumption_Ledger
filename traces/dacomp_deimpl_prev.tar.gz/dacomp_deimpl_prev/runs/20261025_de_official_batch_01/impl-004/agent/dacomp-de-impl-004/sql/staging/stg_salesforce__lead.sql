WITH source_rows AS (
    SELECT
        CAST("id" AS VARCHAR) AS lead_id,
        CAST("annual_revenue" AS DECIMAL(18,3)) AS annual_revenue,
        CAST("city" AS VARCHAR) AS city,
        CAST("company" AS VARCHAR) AS company,
        CAST("converted_account_id" AS VARCHAR) AS converted_account_id,
        CAST("converted_contact_id" AS VARCHAR) AS converted_contact_id,
        CASE WHEN CAST("converted_date" AS TIMESTAMP) < TIMESTAMP '2000-01-01' OR CAST("converted_date" AS TIMESTAMP) > CURRENT_TIMESTAMP THEN NULL ELSE CAST("converted_date" AS TIMESTAMP) END AS converted_date,
        CAST("converted_opportunity_id" AS VARCHAR) AS converted_opportunity_id,
        CAST("country" AS VARCHAR) AS country,
        CAST("country_code" AS VARCHAR) AS country_code,
        CAST("created_by_id" AS VARCHAR) AS created_by_id,
        CAST("created_date" AS TIMESTAMP) AS created_date,
        CAST("description" AS VARCHAR) AS lead_description,
        CASE WHEN CAST("email" AS VARCHAR) = '' THEN NULL ELSE LOWER(TRIM(CAST("email" AS VARCHAR))) END AS email,
        CAST("email_bounced_date" AS TIMESTAMP) AS email_bounced_date,
        CAST("email_bounced_reason" AS VARCHAR) AS email_bounced_reason,
        CAST("fax" AS VARCHAR) AS fax,
        CAST("first_name" AS VARCHAR) AS first_name,
        CAST("geocode_accuracy" AS VARCHAR) AS geocode_accuracy,
        CAST("has_opted_out_of_email" AS BOOLEAN) AS has_opted_out_of_email,
        CAST("industry" AS VARCHAR) AS industry,
        CAST("is_converted" AS BOOLEAN) AS is_converted,
        COALESCE(CAST("is_deleted" AS BOOLEAN), FALSE) AS is_deleted,
        CAST("is_unread_by_owner" AS BOOLEAN) AS is_unread_by_owner,
        CASE WHEN CAST("last_activity_date" AS DATE) < DATE '2020-01-01' THEN NULL ELSE CAST("last_activity_date" AS DATE) END AS last_activity_date,
        CAST("last_modified_date" AS TIMESTAMP) AS last_modified_date,
        CAST("last_name" AS VARCHAR) AS last_name,
        CAST("last_referenced_date" AS TIMESTAMP) AS last_referenced_date,
        CAST("last_viewed_date" AS TIMESTAMP) AS last_viewed_date,
        CAST("latitude" AS DECIMAL(18,3)) AS latitude,
        CAST("lead_source" AS VARCHAR) AS lead_source,
        CAST("longitude" AS DECIMAL(18,3)) AS longitude,
        CAST("master_record_id" AS VARCHAR) AS master_record_id,
        CASE WHEN CAST("mobile_phone" AS VARCHAR) = '' THEN NULL WHEN LENGTH(REGEXP_REPLACE(CAST("mobile_phone" AS VARCHAR), '[^0-9]', '')) < 10 THEN NULL ELSE REGEXP_REPLACE(CAST("mobile_phone" AS VARCHAR), '[^0-9+()-]', '') END AS mobile_phone,
        CAST("name" AS VARCHAR) AS lead_name,
        CAST("number_of_employees" AS INTEGER) AS number_of_employees,
        CAST("owner_id" AS VARCHAR) AS owner_id,
        CASE WHEN CAST("phone" AS VARCHAR) = '' THEN NULL WHEN LENGTH(REGEXP_REPLACE(CAST("phone" AS VARCHAR), '[^0-9]', '')) < 10 THEN NULL ELSE REGEXP_REPLACE(CAST("phone" AS VARCHAR), '[^0-9+()-]', '') END AS phone,
        CAST("photo_url" AS VARCHAR) AS photo_url,
        CAST("postal_code" AS VARCHAR) AS postal_code,
        CAST("salutation" AS VARCHAR) AS salutation,
        CAST("state" AS VARCHAR) AS state,
        CAST("state_code" AS VARCHAR) AS state_code,
        CAST("status" AS VARCHAR) AS status,
        CAST("street" AS VARCHAR) AS street,
        CAST("system_modstamp" AS TIMESTAMP) AS system_modstamp,
        CAST("title" AS VARCHAR) AS title,
        CAST("website" AS VARCHAR) AS website
    FROM raw.lead
),
valid_rows AS (
    SELECT *
    FROM source_rows
    WHERE lead_id IS NOT NULL AND
        company IS NOT NULL AND
        is_converted IS NOT NULL AND
        is_deleted IS NOT NULL AND
        (last_activity_date IS NULL OR last_activity_date <= CURRENT_DATE) AND
        last_name IS NOT NULL AND
        owner_id IS NOT NULL AND
        status IS NOT NULL
),
deduplicated_rows AS (
    SELECT *, ROW_NUMBER() OVER (PARTITION BY lead_id ORDER BY lead_id) AS _row_num
    FROM valid_rows
)
SELECT * EXCLUDE (_row_num)
FROM deduplicated_rows
WHERE _row_num = 1
