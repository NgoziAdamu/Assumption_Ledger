WITH account_base AS (
    SELECT
        account_id,
        account_name,
        type AS account_type,
        industry,
        annual_revenue,
        number_of_employees,
        billing_street,
        billing_city,
        billing_state,
        billing_postal_code,
        billing_country,
        website,
        owner_id
    FROM staging.stg_salesforce__account
    WHERE is_deleted = FALSE
),
account_derived AS (
    SELECT
        account_id,
        account_name,
        account_type,
        industry,
        annual_revenue,
        number_of_employees,
        billing_street,
        billing_city,
        billing_state,
        billing_postal_code,
        billing_country,
        CAST(NULL AS INTEGER) AS phone,
        website,
        owner_id,
        CAST(NULL AS INTEGER) AS created_date,
        CAST(NULL AS INTEGER) AS last_modified_date,
        CASE
            WHEN annual_revenue >= 10000000 THEN 'Enterprise'
            WHEN annual_revenue >= 1000000 THEN 'Mid-Market'
            WHEN annual_revenue >= 100000 THEN 'SMB'
            WHEN annual_revenue > 0 THEN 'Small'
            ELSE 'Unknown'
        END AS account_size_segment,
        CASE
            WHEN UPPER(TRIM(billing_country)) IN ('US', 'USA', 'UNITED STATES', 'CANADA', 'CA') THEN 'North America'
            WHEN UPPER(TRIM(billing_country)) IN (
                'UK', 'UNITED KINGDOM', 'FRANCE', 'GERMANY', 'SPAIN', 'ITALY',
                'NETHERLANDS', 'BELGIUM', 'SWEDEN', 'NORWAY', 'DENMARK',
                'FINLAND', 'IRELAND', 'PORTUGAL', 'AUSTRIA', 'SWITZERLAND'
            ) THEN 'Europe'
            WHEN UPPER(TRIM(billing_country)) IN (
                'CHINA', 'JAPAN', 'INDIA', 'AUSTRALIA', 'SINGAPORE', 'SOUTH KOREA',
                'THAILAND', 'MALAYSIA', 'INDONESIA', 'PHILIPPINES', 'VIETNAM', 'NEW ZEALAND'
            ) THEN 'Asia-Pacific'
            WHEN UPPER(TRIM(billing_country)) IN (
                'BRAZIL', 'MEXICO', 'ARGENTINA', 'CHILE', 'COLOMBIA', 'PERU',
                'VENEZUELA', 'ECUADOR', 'BOLIVIA', 'URUGUAY', 'PARAGUAY'
            ) THEN 'Latin America'
            ELSE 'Other'
        END AS geographic_region,
        CAST(NULL AS INTEGER) AS account_age_days,
        'Unknown' AS account_maturity_stage,
        CASE WHEN industry IS NOT NULL THEN TRIM(industry) ELSE NULL END AS industry_normalized,
        CAST(
            (CASE WHEN website IS NOT NULL AND TRIM(website) <> '' THEN 25 ELSE 0 END) +
            (CASE WHEN industry IS NOT NULL AND TRIM(industry) <> '' THEN 25 ELSE 0 END) +
            (CASE WHEN annual_revenue > 0 THEN 25 ELSE 0 END) +
            (CASE WHEN number_of_employees > 0 THEN 25 ELSE 0 END)
            AS INTEGER
        ) AS data_completeness_score,
        CASE
            WHEN annual_revenue >= 5000000
                OR (account_type = 'Customer' AND annual_revenue >= 1000000)
            THEN TRUE
            ELSE FALSE
        END AS is_high_value_account
    FROM account_base
)
SELECT
    account_id,
    account_name,
    account_type,
    industry,
    annual_revenue,
    number_of_employees,
    billing_street,
    billing_city,
    billing_state,
    billing_postal_code,
    billing_country,
    phone,
    website,
    owner_id,
    created_date,
    last_modified_date,
    account_size_segment,
    geographic_region,
    account_age_days,
    account_maturity_stage,
    industry_normalized,
    data_completeness_score,
    is_high_value_account
FROM account_derived
