WITH history_rows AS (
    SELECT
        account_id,
        CAST(created_date AS DATE) AS snapshot_date,
        account_name,
        account_source,
        industry,
        annual_revenue,
        number_of_employees,
        owner_id,
        type,
        billing_city,
        billing_state,
        billing_country,
        website,
        rating,
        ownership,
        parent_id,
        last_activity_date,
        created_date
    FROM staging.stg_salesforce__account_history
    WHERE COALESCE(is_deleted, FALSE) = FALSE
),
ranked_history AS (
    SELECT
        *,
        ROW_NUMBER() OVER (
            PARTITION BY account_id, snapshot_date
            ORDER BY created_date DESC
        ) AS row_num
    FROM history_rows
)
SELECT
    account_id,
    snapshot_date,
    account_name,
    account_source,
    industry,
    annual_revenue,
    number_of_employees,
    owner_id,
    type,
    billing_city,
    billing_state,
    billing_country,
    website,
    rating,
    ownership,
    parent_id,
    last_activity_date
FROM ranked_history
WHERE row_num = 1
ORDER BY account_id, snapshot_date
