WITH typed AS (
    SELECT
        trim(cast(r."id" AS VARCHAR)) AS interview_id,
        trim(cast(r."opportunity_id" AS VARCHAR)) AS opportunity_id,
        try_cast(r."candidate_id" AS BIGINT) AS candidate_id,
        trim(cast(r."stage_id" AS VARCHAR)) AS stage_id,
        try_cast(r."panel_id" AS BIGINT) AS panel_id,
        try_cast(r."creator_id" AS VARCHAR(50)) AS creator_user_id,
        try_cast(r."date" AS TIMESTAMP) AS interview_date,
        try_cast(r."duration" AS DOUBLE) AS duration,
        try_cast(r."subject" AS VARCHAR(500)) AS subject,
        try_cast(r."location" AS VARCHAR(500)) AS location,
        try_cast(r."timezone" AS VARCHAR(10)) AS timezone,
        CASE WHEN r."gcal_event_url" IS NULL OR regexp_matches(trim(cast(r.\"gcal_event_url\" AS VARCHAR)), '^https?://', 'i') THEN cast(r."gcal_event_url" AS VARCHAR) ELSE NULL END AS gcal_event_url,
        try_cast(r."feedback_reminder" AS VARCHAR(500)) AS feedback_reminder,
        try_cast(r."note" AS VARCHAR(1000)) AS note,
        try_cast(r."created_at" AS TIMESTAMP) AS created_at,
        try_cast(r."canceled_at" AS TIMESTAMP) AS canceled_at
    FROM raw.interview AS r
),
valid AS (
    SELECT * FROM typed
    WHERE         interview_id IS NOT NULL AND
              length(interview_id) > 0 AND
              opportunity_id IS NOT NULL AND
              candidate_id IS NOT NULL AND
              stage_id IS NOT NULL AND
              creator_user_id IS NOT NULL
),
ranked AS (
    SELECT *, row_number() OVER (PARTITION BY interview_id ORDER BY interview_id) AS _row_num
    FROM valid
)
SELECT interview_id, opportunity_id, candidate_id, stage_id, panel_id, creator_user_id, interview_date, duration, subject, location, timezone, gcal_event_url, feedback_reminder, note, created_at, canceled_at
FROM ranked
WHERE _row_num = 1