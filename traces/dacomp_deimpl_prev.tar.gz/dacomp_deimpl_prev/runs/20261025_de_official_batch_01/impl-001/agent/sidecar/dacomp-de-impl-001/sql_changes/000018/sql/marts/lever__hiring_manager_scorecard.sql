WITH manager_base AS (
    SELECT u.user_id AS hiring_manager_id, u.user_name AS hiring_manager_name,
           u.email AS hiring_manager_email, u.access_role, u.created_at AS joined_date
    FROM staging.stg_lever__user u
    WHERE u.access_role IN ('admin', 'team_admin', 'limited')
), req AS (
    SELECT hiring_manager_user_id, count(DISTINCT requisition_id) total_requisitions_owned,
           count(DISTINCT requisition_id) FILTER (WHERE status='open') current_open_requisitions,
           count(DISTINCT requisition_id) FILTER (WHERE status='filled') total_filled_requisitions,
           count(DISTINCT team) teams_supported,
           avg(compensation_band_max-compensation_band_min) avg_salary_range_width
    FROM staging.stg_lever__requisition GROUP BY hiring_manager_user_id
), post AS (
    SELECT owner_user_id, count(DISTINCT posting_id) total_postings_owned,
           count(DISTINCT a.application_id) total_applications_received,
           count(DISTINCT a.opportunity_id) total_candidates_managed,
           count(DISTINCT p.categories_department) departments_managed,
           avg(pp.total_applications) avg_applications_per_posting,
           avg(pp.application_to_hire_rate) avg_posting_conversion_rate,
           avg(pp.posting_performance_score) avg_posting_performance_score
    FROM staging.stg_lever__posting p LEFT JOIN staging.stg_lever__application a USING(posting_id)
    LEFT JOIN intermediate.int_lever__posting_performance pp USING(posting_id)
    GROUP BY owner_user_id
)
SELECT m.hiring_manager_id,m.hiring_manager_name,m.hiring_manager_email,m.access_role,m.joined_date,
       coalesce(r.total_requisitions_owned,0) total_requisitions_owned,
       coalesce(p.total_postings_owned,0) total_postings_owned,
       coalesce(p.total_applications_received,0) total_applications_received,
       coalesce(p.total_candidates_managed,0) total_candidates_managed,
       0.0 requisition_fill_rate,coalesce(r.current_open_requisitions,0) current_open_requisitions,
       coalesce(r.total_filled_requisitions,0) total_filled_requisitions,
       coalesce(r.teams_supported,0) teams_supported,coalesce(r.avg_salary_range_width,0) avg_salary_range_width,
       coalesce(p.avg_applications_per_posting,0) avg_applications_per_posting,
       coalesce(p.avg_posting_conversion_rate,0) avg_posting_conversion_rate,
       0.0 high_performing_posting_rate,coalesce(p.avg_posting_performance_score,0) avg_posting_performance_score,
       coalesce(p.departments_managed,0) departments_managed,0.0 candidate_hire_rate,0::BIGINT total_candidates_hired,
       0.0 avg_candidate_lifecycle_days,0.0 avg_candidate_experience_score,0::BIGINT positive_experience_candidates,
       0.0 interview_success_rate,0.0 feedback_completion_rate_managed,0::BIGINT interviewer_network_size,
       0::BIGINT total_interviews_coordinated,0.0 avg_total_days_to_hire,'Unknown' decision_speed_category,
       0::BIGINT high_efficiency_postings,NULL::DOUBLE overall_performance_score,'New/Limited Experience' performance_tier,
       'Generalist' hiring_specialization,'' development_recommendations,current_timestamp calculated_at
FROM manager_base m LEFT JOIN req r ON m.hiring_manager_id=r.hiring_manager_user_id
LEFT JOIN post p ON m.hiring_manager_id=p.owner_user_id
WHERE coalesce(r.total_requisitions_owned,0)>0 OR coalesce(p.total_postings_owned,0)>0
