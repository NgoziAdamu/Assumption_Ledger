SELECT
        try_cast(r."contact_id" AS VARCHAR(50)) AS contact_id,
        CASE WHEN r."link" IS NULL OR regexp_matches(trim(cast(r.\"link\" AS VARCHAR)), '^https?://', 'i') THEN cast(r."link" AS VARCHAR) ELSE NULL END AS link
FROM raw.contact_link AS r
WHERE         contact_id IS NOT NULL