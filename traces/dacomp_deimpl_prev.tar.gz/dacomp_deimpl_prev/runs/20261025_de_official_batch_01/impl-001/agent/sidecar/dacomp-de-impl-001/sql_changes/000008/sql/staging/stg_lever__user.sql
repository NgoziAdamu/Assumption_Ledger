WITH typed AS (
    SELECT
        trim(cast(r."id" AS VARCHAR)) AS user_id,
        try_cast(r."access_role" AS VARCHAR(20)) AS access_role,
        CASE WHEN trim(cast(r."email" AS VARCHAR)) ~* '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$' THEN lower(trim(cast(r."email" AS VARCHAR))) ELSE NULL END AS email,
        trim(cast(r."name" AS VARCHAR)) AS user_name,
        lower(trim(cast(r."username" AS VARCHAR))) AS username,
        try_cast(r."created_at" AS TIMESTAMP) AS created_at,
        try_cast(r."deactivated_at" AS TIMESTAMP) AS deactivated_at,
        try_cast(r."external_directory_id" AS VARCHAR(128)) AS external_directory_user_id,
        CASE WHEN r."photo" IS NULL OR trim(cast(r."photo" AS VARCHAR)) ~* '^https?://' THEN cast(r."photo" AS VARCHAR) ELSE NULL END AS photo
    FROM raw.user AS r
),
valid AS (
    SELECT * FROM typed
    WHERE         access_role IN ('admin','team_admin','limited','super_admin','interviewer') AND
              user_id IS NOT NULL AND
              length(user_id) > 0 AND
              access_role IS NOT NULL AND
              email IS NOT NULL AND
              user_name IS NOT NULL AND
              length(user_name) > 0 AND
              username IS NOT NULL
),
ranked AS (
    SELECT *, row_number() OVER (PARTITION BY user_id ORDER BY user_id) AS _row_num
    FROM valid
)
SELECT user_id, access_role, email, user_name, username, created_at, deactivated_at, external_directory_user_id, photo
FROM ranked
WHERE _row_num = 1