WITH base AS (
    SELECT
        coalesce(categories_department, 'Unknown Department') AS department,
        coalesce(categories_team, 'Unknown Team') AS team,
        coalesce(categories_location, 'Unknown Location') AS location,
        coalesce(categories_level, 'Unknown Level') AS level,
        coalesce(categories_commitment, 'Unknown Commitment') AS commitment_type,
        posting_id
    FROM staging.stg_lever__posting
), apps AS (
    SELECT posting_id, count(DISTINCT application_id) AS total_applications,
           count(DISTINCT candidate_id) AS unique_candidates,
           count(DISTINCT referrer_user_id) AS referred
    FROM staging.stg_lever__application
    GROUP BY posting_id
), metrics AS (
    SELECT b.department, b.team, count(DISTINCT b.posting_id) AS active_postings,
           coalesce(sum(a.total_applications), 0) AS total_applications,
           coalesce(sum(a.unique_candidates), 0) AS unique_candidates,
           round(100.0 * sum(a.referred) / nullif(sum(a.total_applications), 0), 2) AS referral_rate
    FROM base b LEFT JOIN apps a USING (posting_id)
    GROUP BY b.department, b.team
), scored AS (
    SELECT b.*, coalesce(m.total_applications, 0) AS total_applications,
           coalesce(m.unique_candidates, 0) AS unique_candidates,
           coalesce(m.active_postings, 0) AS active_postings,
           coalesce(round(m.total_applications * 1.0 / nullif(m.active_postings, 0), 1), 0) AS avg_applications_per_posting,
           coalesce(m.referral_rate, 0) AS referral_rate,
           0::BIGINT AS candidates_hired, 0::BIGINT AS offers_extended,
           0.0 AS hire_conversion_rate, 0.0 AS offer_acceptance_rate,
           0.0 AS avg_time_to_hire_days, 0.0 AS avg_interviews_per_hire,
           0::BIGINT AS total_interviews_conducted, 0.0 AS interview_completion_rate,
           0.0 AS feedback_completion_rate, 0::BIGINT AS unique_interviewers,
           0.0 AS avg_interview_duration_minutes, 0.0 AS avg_candidate_experience_score,
           0.0 AS positive_experience_rate, 0.0 AS avg_screening_pass_rate,
           0::BIGINT AS high_efficiency_postings, 0.0 AS interview_hours_per_hire,
           0.0 AS applications_per_hire, 0.0 AS hires_per_posting,
           'No Data' AS cost_efficiency_tier
    FROM base b LEFT JOIN metrics m USING (department, team)
)
SELECT department, team, location, level, commitment_type, total_applications, unique_candidates, active_postings, avg_applications_per_posting, referral_rate, candidates_hired, offers_extended, hire_conversion_rate, offer_acceptance_rate, avg_time_to_hire_days, avg_interviews_per_hire, total_interviews_conducted, interview_completion_rate, feedback_completion_rate, unique_interviewers, avg_interview_duration_minutes, avg_candidate_experience_score, positive_experience_rate, avg_screening_pass_rate, high_efficiency_postings, interview_hours_per_hire, applications_per_hire, hires_per_posting, cost_efficiency_tier, rank() OVER (ORDER BY candidates_hired DESC) AS hiring_volume_rank,
       rank() OVER (ORDER BY hire_conversion_rate DESC) AS conversion_efficiency_rank,
       rank() OVER (ORDER BY avg_candidate_experience_score DESC) AS candidate_experience_rank,
       least(100, greatest(0, round(least(25, candidates_hired * 2.5) + hire_conversion_rate * .2 + interview_completion_rate * .2 + positive_experience_rate * .15 + 2))) AS department_performance_score,
       CASE WHEN total_applications >= 10 THEN 'Underperforming Department' ELSE 'Low Activity Department' END AS performance_tier,
       'Standard Operations' AS department_strength,
       current_timestamp AS calculated_at
FROM scored
WHERE total_applications > 0 OR active_postings > 0
