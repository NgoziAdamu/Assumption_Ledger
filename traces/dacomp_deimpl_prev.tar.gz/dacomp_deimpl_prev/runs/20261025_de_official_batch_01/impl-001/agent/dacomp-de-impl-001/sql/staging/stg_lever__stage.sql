WITH typed AS (
    SELECT
        trim(cast(r."id" AS VARCHAR)) AS stage_id,
        try_cast(r."text" AS VARCHAR(255)) AS stage_name
    FROM raw.stage AS r
),
valid AS (
    SELECT * FROM typed
    WHERE         stage_id IS NOT NULL AND
              length(stage_id) > 0 AND
              stage_name IS NOT NULL
),
ranked AS (
    SELECT *, row_number() OVER (PARTITION BY stage_id ORDER BY stage_id) AS _row_num
    FROM valid
)
SELECT stage_id, stage_name
FROM ranked
WHERE _row_num = 1