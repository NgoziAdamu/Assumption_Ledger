WITH typed AS (
    SELECT
        try_cast(r."id" AS VARCHAR(50)) AS offer_id,
        trim(cast(r."opportunity_id" AS VARCHAR)) AS opportunity_id,
        try_cast(r."candidate_id" AS BIGINT) AS candidate_id,
        try_cast(r."creator_id" AS VARCHAR(50)) AS creator_user_id,
        try_cast(r."status" AS VARCHAR(50)) AS status,
        try_cast(r."created_at" AS TIMESTAMP) AS created_at
    FROM raw.offer AS r
),
valid AS (
    SELECT * FROM typed
    WHERE         status IN ('open','closed','cancelled','draft','pending') AND
              offer_id IS NOT NULL AND
              opportunity_id IS NOT NULL AND
              creator_user_id IS NOT NULL
),
ranked AS (
    SELECT *, row_number() OVER (PARTITION BY offer_id ORDER BY offer_id) AS _row_num
    FROM valid
)
SELECT offer_id, opportunity_id, candidate_id, creator_user_id, status, created_at
FROM ranked
WHERE _row_num = 1