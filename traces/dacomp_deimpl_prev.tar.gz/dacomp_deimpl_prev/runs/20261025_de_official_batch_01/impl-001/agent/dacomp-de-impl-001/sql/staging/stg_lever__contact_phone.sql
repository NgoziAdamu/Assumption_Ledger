SELECT
        try_cast(r."contact_id" AS VARCHAR(50)) AS contact_id,
        try_cast(r."value" AS VARCHAR) AS phone_number,
        try_cast(r."type" AS VARCHAR(20)) AS phone_type
FROM raw.contact_phone AS r
WHERE         contact_id IS NOT NULL