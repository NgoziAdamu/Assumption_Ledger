WITH typed AS (
    SELECT
        trim(cast(r."id" AS VARCHAR)) AS opportunity_id,
        try_cast(r."name" AS VARCHAR(255)) AS contact_name,
        try_cast(r."headline" AS VARCHAR(500)) AS contact_headline,
        trim(cast(r."stage_id" AS VARCHAR)) AS stage_id,
        try_cast(r."owner_id" AS VARCHAR(50)) AS owner_user_id,
        try_cast(r."contact" AS VARCHAR(50)) AS contact_id,
        try_cast(r."location" AS VARCHAR(255)) AS contact_location,
        try_cast(r."origin" AS VARCHAR(100)) AS origin,
        try_cast(r."archived_at" AS TIMESTAMP) AS archived_at,
        try_cast(r."archived_reason_id" AS VARCHAR(50)) AS archived_reason_id,
        try_cast(r."created_at" AS TIMESTAMP) AS created_at,
        try_cast(r."updated_at" AS TIMESTAMP) AS updated_at,
        try_cast(r."last_interaction_at" AS TIMESTAMP) AS last_interaction_at,
        try_cast(r."last_advanced_at" AS TIMESTAMP) AS last_advanced_at,
        try_cast(r."snoozed_until" AS TIMESTAMP) AS snoozed_until,
        try_cast(r."data_protection_contact_allowed" AS BOOLEAN) AS is_data_protection_contact_allowed,
        try_cast(r."data_protection_contact_expires_at" AS TIMESTAMP) AS data_protection_contact_expires_at,
        try_cast(r."data_protection_store_allowed" AS BOOLEAN) AS is_data_protection_store_allowed,
        try_cast(r."data_protection_store_expires_at" AS TIMESTAMP) AS data_protection_store_expires_at,
        try_cast(r."is_anonymized" AS BOOLEAN) AS is_anonymized
    FROM raw.opportunity AS r
),
valid AS (
    SELECT * FROM typed
    WHERE         opportunity_id IS NOT NULL AND
              length(opportunity_id) > 0 AND
              contact_name IS NOT NULL AND
              stage_id IS NOT NULL
),
ranked AS (
    SELECT *, row_number() OVER (PARTITION BY opportunity_id ORDER BY opportunity_id) AS _row_num
    FROM valid
)
SELECT opportunity_id, contact_name, contact_headline, stage_id, owner_user_id, contact_id, contact_location, origin, archived_at, archived_reason_id, created_at, updated_at, last_interaction_at, last_advanced_at, snoozed_until, is_data_protection_contact_allowed, data_protection_contact_expires_at, is_data_protection_store_allowed, data_protection_store_expires_at, is_anonymized
FROM ranked
WHERE _row_num = 1