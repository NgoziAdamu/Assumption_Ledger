WITH typed AS (
    SELECT
        trim(cast(r."opportunity_id" AS VARCHAR)) AS opportunity_id,
        try_cast(r."source" AS VARCHAR(100)) AS source_name
    FROM raw.opportunity_source AS r
),
valid AS (
    SELECT * FROM typed
    WHERE         opportunity_id IS NOT NULL AND
              source_name IS NOT NULL
),
ranked AS (
    SELECT *, row_number() OVER (PARTITION BY opportunity_id ORDER BY opportunity_id) AS _row_num
    FROM valid
)
SELECT opportunity_id, source_name
FROM ranked
WHERE _row_num = 1