WITH typed AS (
    SELECT
        try_cast(r."id" AS VARCHAR(50)) AS application_id,
        trim(cast(r."opportunity_id" AS VARCHAR)) AS opportunity_id,
        trim(cast(r."posting_id" AS VARCHAR)) AS posting_id,
        try_cast(r."type" AS VARCHAR(50)) AS type,
        try_cast(r."candidate_id" AS BIGINT) AS candidate_id,
        try_cast(r."posting_hiring_manager_id" AS VARCHAR(50)) AS posting_hiring_manager_user_id,
        try_cast(r."posting_owner_id" AS VARCHAR(50)) AS posting_owner_user_id,
        try_cast(r."company" AS VARCHAR(255)) AS company,
        try_cast(r."referrer_id" AS VARCHAR(50)) AS referrer_user_id,
        trim(cast(r."requisition_for_hire_id" AS VARCHAR)) AS requisition_id,
        try_cast(r."archived_at" AS TIMESTAMP) AS archived_at,
        try_cast(r."archived_reason_id" AS VARCHAR(50)) AS archived_reason_id,
        try_cast(r."comments" AS VARCHAR(1000)) AS comments,
        try_cast(r."created_at" AS TIMESTAMP) AS created_at
    FROM raw.application AS r
),
valid AS (
    SELECT * FROM typed
    WHERE         application_id IS NOT NULL AND
              opportunity_id IS NOT NULL AND
              created_at IS NOT NULL
),
ranked AS (
    SELECT *, row_number() OVER (PARTITION BY application_id ORDER BY application_id) AS _row_num
    FROM valid
)
SELECT application_id, opportunity_id, posting_id, type, candidate_id, posting_hiring_manager_user_id, posting_owner_user_id, company, referrer_user_id, requisition_id, archived_at, archived_reason_id, comments, created_at
FROM ranked
WHERE _row_num = 1