WITH typed AS (
    SELECT
        trim(cast(r."id" AS VARCHAR)) AS requisition_id,
        try_cast(r."requisition_code" AS VARCHAR(20)) AS requisition_code,
        try_cast(r."name" AS VARCHAR(500)) AS requisition_name,
        try_cast(r."status" AS VARCHAR(20)) AS status,
        try_cast(r."employment_status" AS VARCHAR(20)) AS employment_status,
        try_cast(r."compensation_band_currency" AS VARCHAR(3)) AS compensation_band_currency,
        try_cast(r."compensation_band_interval" AS VARCHAR(10)) AS compensation_band_interval,
        try_cast(r."compensation_band_min" AS DOUBLE) AS compensation_band_min,
        try_cast(r."compensation_band_max" AS DOUBLE) AS compensation_band_max,
        try_cast(r."location" AS VARCHAR(255)) AS location,
        try_cast(r."team" AS VARCHAR(255)) AS team,
        try_cast(r."creator_id" AS VARCHAR(50)) AS creator_user_id,
        try_cast(r."owner_id" AS VARCHAR(50)) AS owner_user_id,
        try_cast(r."hiring_manager_id" AS VARCHAR(50)) AS hiring_manager_user_id,
        try_cast(r."created_at" AS TIMESTAMP) AS created_at,
        try_cast(r."backfill" AS BOOLEAN) AS backfill,
        try_cast(r."headcount_hired" AS INT) AS headcount_hired,
        try_cast(r."headcount_infinite" AS BOOLEAN) AS headcount_infinite,
        try_cast(r."headcount_total" AS INT) AS headcount_total,
        try_cast(r."internal_notes" AS VARCHAR(1000)) AS internal_notes
    FROM raw.requisition AS r
),
valid AS (
    SELECT * FROM typed
    WHERE         status IN ('open','closed','cancelled','draft','pending') AND
              employment_status IN ('full-time','part-time','contract','internship','temporary') AND
              requisition_id IS NOT NULL AND
              length(requisition_id) > 0 AND
              requisition_code IS NOT NULL AND
              requisition_code LIKE 'REQ-%' AND
              requisition_name IS NOT NULL AND
              status IS NOT NULL AND
              employment_status IS NOT NULL AND
              creator_user_id IS NOT NULL AND
              owner_user_id IS NOT NULL AND
              backfill IS NOT NULL
),
ranked AS (
    SELECT *, row_number() OVER (PARTITION BY requisition_id, requisition_code ORDER BY requisition_id, requisition_code) AS _row_num
    FROM valid
)
SELECT requisition_id, requisition_code, requisition_name, status, employment_status, compensation_band_currency, compensation_band_interval, compensation_band_min, compensation_band_max, location, team, creator_user_id, owner_user_id, hiring_manager_user_id, created_at, backfill, headcount_hired, headcount_infinite, headcount_total, internal_notes
FROM ranked
WHERE _row_num = 1