SELECT
        trim(cast(r."posting_id" AS VARCHAR)) AS posting_id,
        try_cast(r."tag" AS VARCHAR(100)) AS tag
FROM raw.posting_tag AS r
WHERE         posting_id IS NOT NULL