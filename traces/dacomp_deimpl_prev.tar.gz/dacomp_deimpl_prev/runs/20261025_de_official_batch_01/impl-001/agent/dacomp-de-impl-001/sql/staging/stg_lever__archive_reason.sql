WITH typed AS (
    SELECT
        try_cast(r."id" AS VARCHAR(50)) AS archive_reason_id,
        try_cast(r."text" AS VARCHAR(255)) AS archive_reason_title
    FROM raw.archive_reason AS r
),
valid AS (
    SELECT * FROM typed
    WHERE         archive_reason_id IS NOT NULL
),
ranked AS (
    SELECT *, row_number() OVER (PARTITION BY archive_reason_id ORDER BY archive_reason_id) AS _row_num
    FROM valid
)
SELECT archive_reason_id, archive_reason_title
FROM ranked
WHERE _row_num = 1