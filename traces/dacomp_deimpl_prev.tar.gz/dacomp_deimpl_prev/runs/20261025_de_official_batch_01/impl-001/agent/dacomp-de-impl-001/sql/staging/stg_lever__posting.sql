WITH typed AS (
    SELECT
        trim(cast(r."id" AS VARCHAR)) AS posting_id,
        trim(cast(r."text" AS VARCHAR)) AS posting_title,
        try_cast(r."state" AS VARCHAR(20)) AS state,
        try_cast(r."requisition_code" AS VARCHAR(20)) AS requisition_code,
        try_cast(r."categories_commitment" AS VARCHAR(50)) AS categories_commitment,
        try_cast(r."categories_department" AS VARCHAR(100)) AS categories_department,
        try_cast(r."categories_level" AS VARCHAR(50)) AS categories_level,
        try_cast(r."categories_location" AS VARCHAR(255)) AS categories_location,
        try_cast(r."categories_team" AS VARCHAR(255)) AS categories_team,
        try_cast(r."content_description" AS VARCHAR(5000)) AS content_description,
        try_cast(r."content_description_html" AS VARCHAR(5000)) AS content_description_html,
        try_cast(r."content_closing" AS VARCHAR(5000)) AS content_closing,
        try_cast(r."content_closing_html" AS VARCHAR(5000)) AS content_closing_html,
        try_cast(r."creator_id" AS VARCHAR(50)) AS creator_user_id,
        try_cast(r."owner_id" AS VARCHAR(50)) AS owner_user_id,
        try_cast(r."created_at" AS TIMESTAMP) AS created_at,
        try_cast(r."updated_at" AS TIMESTAMP) AS updated_at
    FROM raw.posting AS r
),
valid AS (
    SELECT * FROM typed
    WHERE         state IN ('published','draft','closed','internal') AND
              posting_id IS NOT NULL AND
              length(posting_id) > 0 AND
              posting_title IS NOT NULL AND
              state IS NOT NULL AND
              requisition_code LIKE 'REQ-%' AND
              creator_user_id IS NOT NULL AND
              owner_user_id IS NOT NULL
),
ranked AS (
    SELECT *, row_number() OVER (PARTITION BY posting_id ORDER BY posting_id) AS _row_num
    FROM valid
)
SELECT posting_id, posting_title, state, requisition_code, categories_commitment, categories_department, categories_level, categories_location, categories_team, content_description, content_description_html, content_closing, content_closing_html, creator_user_id, owner_user_id, created_at, updated_at
FROM ranked
WHERE _row_num = 1