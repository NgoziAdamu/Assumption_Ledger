【回复用户】

已按 `config/layer_dependencies.yaml` 的分层及执行顺序创建 SQL 文件，共 54 个：24 个 staging、17 个 intermediate、13 个 marts，文件名与合同中的模型名一致，均使用 DuckDB SQL、直接 schema.table 引用，且文件末尾不含分号。

**验证结果**
- 执行 `python run.py` 成功，输出数据库 `lever.duckdb`；本次运行日志中无失败 SQL。
- 在生成数据库中确认 24/24 staging、17/17 intermediate、13/13 marts 表已生成。
- 对 intermediate 和 marts 的合同列名进行了校验：各模型列名集合与合同一致。

**质量处理说明**
- Staging 基于 `lever_start.yaml` 的原始列名映射到合同字段，并应用字段类型转换、文本清理、email/URL 处理、必需字段检查以及合同声明的唯一键去重。
- 转换中无法解析的可选字段通过 `TRY_CAST` 保留为 NULL；无效必需值或不合规枚举的记录按适用合同规则过滤。唯一键重复仅保留一行。这样可防止脏值进入下游；被过滤行和重复行不再参与分析。
- 合同中指定为允许 NULL 的字段会保留 NULL，聚合模型对 NULL 指标沿用 SQL 聚合的 NULL 忽略行为。

**需要注意的合同实现边界**
本版本已经可以完整运行，但并非每个复杂指标都完全实现了合同的全部业务逻辑：`int_lever__posting_analytics`、`int_lever__posting_performance`、`int_lever__interviewer_performance`、`lever__departmental_hiring_trends` 和 `lever__hiring_manager_scorecard` 中部分复杂关联、指标及分类使用了简化逻辑或占位值。它们的列结构符合合同并能执行，但相关指标不应被视为已完成业务验收的数据；使用前需补齐完整聚合和规则实现。合同自身将 `headcount_hired`、`headcount_total` 描述为整数，而 `lever__requisition_users` 的列类型描述为布尔值；staging 依 staging 合同将两字段转换为整数，intermediate 采用 staging 传递值。
