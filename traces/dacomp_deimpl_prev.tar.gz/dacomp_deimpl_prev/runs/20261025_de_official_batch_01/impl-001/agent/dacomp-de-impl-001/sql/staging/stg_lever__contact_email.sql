SELECT
        try_cast(r."contact_id" AS VARCHAR(50)) AS contact_id,
        CASE WHEN regexp_matches(trim(cast(r."email" AS VARCHAR)), '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$', 'i') THEN lower(trim(cast(r."email" AS VARCHAR))) ELSE NULL END AS email
FROM raw.contact_email AS r
WHERE         contact_id IS NOT NULL