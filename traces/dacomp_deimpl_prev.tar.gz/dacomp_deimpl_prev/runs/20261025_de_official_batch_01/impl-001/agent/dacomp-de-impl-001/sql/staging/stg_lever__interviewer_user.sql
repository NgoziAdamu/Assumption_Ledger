SELECT
        trim(cast(r."interview_id" AS VARCHAR)) AS interview_id,
        trim(cast(r."user_id" AS VARCHAR)) AS user_id
FROM raw.interviewer_user AS r
WHERE         interview_id IS NOT NULL AND
          user_id IS NOT NULL