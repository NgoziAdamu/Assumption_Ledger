SELECT
        try_cast(r."feedback_form_id" AS VARCHAR(50)) AS feedback_form_id,
        try_cast(r."field_index" AS BIGINT) AS field_index,
        try_cast(r."value_text" AS VARCHAR(500)) AS field_text,
        try_cast(r."value_index" AS VARCHAR(50)) AS field_type
FROM raw.feedback_form_field AS r
WHERE         feedback_form_id IS NOT NULL