SELECT
        trim(cast(r."requisition_id" AS VARCHAR)) AS requisition_id,
        try_cast(r."offer_id" AS VARCHAR(50)) AS offer_id
FROM raw.requisition_offer AS r
WHERE         requisition_id IS NOT NULL AND
          offer_id IS NOT NULL