SELECT
        trim(cast(r."opportunity_id" AS VARCHAR)) AS opportunity_id,
        trim(cast(r."stage_id" AS VARCHAR)) AS stage_id,
        try_cast(r."updated_at" AS TIMESTAMP) AS updated_at,
        try_cast(r."updater_id" AS VARCHAR(50)) AS updater_user_id,
        try_cast(r."to_stage_index" AS BIGINT) AS to_stage_index
FROM raw.opportunity_stage_history AS r
WHERE         opportunity_id IS NOT NULL AND
          stage_id IS NOT NULL