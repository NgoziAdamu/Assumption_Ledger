SELECT
        trim(cast(r."requisition_id" AS VARCHAR)) AS requisition_id,
        trim(cast(r."posting_id" AS VARCHAR)) AS posting_id
FROM raw.requisition_posting AS r
WHERE         requisition_id IS NOT NULL AND
          posting_id IS NOT NULL