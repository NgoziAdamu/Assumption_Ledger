WITH typed AS (
    SELECT
        try_cast(r."id" AS VARCHAR(50)) AS feedback_form_id,
        try_cast(r."created_at" AS TIMESTAMP) AS created_at,
        try_cast(r."creator_id" AS VARCHAR(50)) AS creator_user_id,
        try_cast(r."instructions" AS VARCHAR(1000)) AS instructions,
        try_cast(r."text" AS VARCHAR(255)) AS feedback_form_name,
        try_cast(r."type" AS VARCHAR(50)) AS type
    FROM raw.feedback_form AS r
),
valid AS (
    SELECT * FROM typed
    WHERE         feedback_form_id IS NOT NULL
),
ranked AS (
    SELECT *, row_number() OVER (PARTITION BY feedback_form_id ORDER BY feedback_form_id) AS _row_num
    FROM valid
)
SELECT feedback_form_id, created_at, creator_user_id, instructions, feedback_form_name, type
FROM ranked
WHERE _row_num = 1