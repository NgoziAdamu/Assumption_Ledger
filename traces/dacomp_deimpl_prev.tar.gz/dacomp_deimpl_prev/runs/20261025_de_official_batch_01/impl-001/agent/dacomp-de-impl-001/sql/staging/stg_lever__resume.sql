WITH typed AS (
    SELECT
        try_cast(r."id" AS VARCHAR(50)) AS resume_id,
        trim(cast(r."opportunity_id" AS VARCHAR)) AS opportunity_id,
        try_cast(r."created_at" AS TIMESTAMP) AS created_at,
        try_cast(r."file_name" AS VARCHAR(255)) AS file_name,
        try_cast(r."file_uploaded_at" AS TIMESTAMP) AS file_uploaded_at,
        try_cast(r."file_ext" AS VARCHAR(10)) AS file_ext,
        CASE WHEN r."file_download_url" IS NULL OR regexp_matches(trim(cast(r."file_download_url" AS VARCHAR)), '^https?://', 'i') THEN cast(r."file_download_url" AS VARCHAR) ELSE NULL END AS file_download_url
    FROM raw.resume AS r
),
valid AS (
    SELECT * FROM typed
    WHERE         resume_id IS NOT NULL AND
              opportunity_id IS NOT NULL
),
ranked AS (
    SELECT *, row_number() OVER (PARTITION BY resume_id ORDER BY resume_id) AS _row_num
    FROM valid
)
SELECT resume_id, opportunity_id, created_at, file_name, file_uploaded_at, file_ext, file_download_url
FROM ranked
WHERE _row_num = 1