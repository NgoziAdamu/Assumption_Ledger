SELECT
        trim(cast(r."opportunity_id" AS VARCHAR)) AS opportunity_id,
        try_cast(r."tag" AS VARCHAR(100)) AS tag
FROM raw.opportunity_tag AS r
WHERE         opportunity_id IS NOT NULL