SELECT
        trim(cast(r."interview_id" AS VARCHAR)) AS interview_id,
        try_cast(r."feedback_form_id" AS VARCHAR(50)) AS feedback_form_id
FROM raw.interview_feedback AS r
WHERE         interview_id IS NOT NULL