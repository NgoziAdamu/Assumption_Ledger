SELECT
        trim(cast(r."posting_id" AS VARCHAR)) AS posting_id,
        trim(cast(r."interview_id" AS VARCHAR)) AS interview_id
FROM raw.posting_interview AS r
WHERE         posting_id IS NOT NULL AND
          interview_id IS NOT NULL