SELECT
    CAST(application_id AS VARCHAR) AS application_id,
    CAST(agent_policy_prod AS VARCHAR) AS agent_policy_prod,
    CAST(agent_policy_staging AS VARCHAR) AS agent_policy_staging,
    CAST(agent_version_prod AS VARCHAR) AS agent_version_prod,
    CAST(agent_version_staging AS VARCHAR) AS agent_version_staging,
    TRY_CAST(SUBSTRING(CAST(created_at AS VARCHAR), 1, 23) AS TIMESTAMP) AS created_at,
    CAST(created_by_user_id AS VARCHAR) AS created_by_user_id,
    CAST(description AS VARCHAR) AS description,
    CAST(display_name AS VARCHAR) AS display_name,
    TRY_CAST(event_count AS BIGINT) AS event_count,
    TRY_CAST(SUBSTRING(CAST(first_event_time AS VARCHAR), 1, 23) AS TIMESTAMP) AS first_event_at,
    TRY_CAST(is_integrated AS BOOLEAN) AS is_integrated,
    TRY_CAST(is_deleted AS BOOLEAN) AS is_deleted,
    TRY_CAST(SUBSTRING(CAST(last_updated_at AS VARCHAR), 1, 23) AS TIMESTAMP) AS last_updated_at,
    CAST(last_updated_by_user_id AS VARCHAR) AS last_updated_by_user_id,
    CAST(application_name AS VARCHAR) AS application_name,
    CAST(platform AS VARCHAR) AS platform,
    TRY_CAST(subscription_id AS BIGINT) AS subscription_id
FROM raw.application_history
WHERE NOT COALESCE(is_deleted, false)
  AND id IS NOT NULL
  AND id != ''