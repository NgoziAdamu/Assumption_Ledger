SELECT
    CAST(visitor_id AS VARCHAR) AS visitor_id,
    CAST(account_id AS VARCHAR) AS account_id,
    CAST(app_id AS VARCHAR) AS app_id,
    CAST(page_id AS VARCHAR) AS page_id,
    CASE WHEN remote_ip IS NULL OR regexp_matches(CAST(remote_ip AS VARCHAR), '^([0-9]{1,3}\.){3}[0-9]{1,3}$') OR regexp_matches(CAST(remote_ip AS VARCHAR), '^([0-9a-fA-F]{0,4}:){2,7}[0-9a-fA-F]{0,4}$') THEN CAST(remote_ip AS VARCHAR) ELSE NULL END AS remote_ip,
    NULLIF(TRIM(CAST(server_name AS VARCHAR)), '') AS server_name,
    TRY_CAST(SUBSTRING(CAST(timestamp AS VARCHAR), 1, 23) AS TIMESTAMP) AS occurred_at,
    NULLIF(TRIM(CAST(user_agent AS VARCHAR)), '') AS user_agent,
    CASE WHEN TRY_CAST(num_events AS BIGINT) BETWEEN 0 AND 10000 THEN TRY_CAST(num_events AS BIGINT) ELSE NULL END AS num_events,
    CASE WHEN TRY_CAST(num_minutes AS BIGINT) BETWEEN 0 AND 1440 THEN TRY_CAST(num_minutes AS BIGINT) ELSE NULL END AS num_minutes,
    md5(concat_ws('|', coalesce(CAST(visitor_id AS VARCHAR), ''), coalesce(CAST(timestamp AS VARCHAR), ''), coalesce(CAST(account_id AS VARCHAR), ''), coalesce(server_name, ''), coalesce(user_agent, ''), coalesce(remote_ip, ''))) AS event_key
FROM raw.event
WHERE visitor_id IS NOT NULL
  AND visitor_id != ''
  AND account_id IS NOT NULL
  AND account_id != ''
  AND app_id IS NOT NULL
  AND app_id != ''
  AND timestamp IS NOT NULL
  AND visitor_id IS NOT NULL AND visitor_id != ''
  AND account_id IS NOT NULL AND account_id != ''
  AND app_id IS NOT NULL AND app_id != ''
  AND timestamp IS NOT NULL