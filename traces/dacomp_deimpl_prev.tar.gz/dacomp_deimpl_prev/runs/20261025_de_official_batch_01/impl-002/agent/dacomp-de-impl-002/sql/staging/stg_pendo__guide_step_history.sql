SELECT
    CAST(guide_id AS VARCHAR) AS guide_id,
    TRY_CAST(SUBSTRING(CAST(guide_last_updated_at AS VARCHAR), 1, 23) AS TIMESTAMP) AS guide_last_updated_at,
    CAST(step_id AS VARCHAR) AS step_id
FROM raw.guide_step_history