SELECT
    CAST(id AS VARCHAR) AS poll_id,
    TRY_CAST(attribute_display AS DOUBLE) AS attribute_display,
    CAST(attribute_follow_up AS VARCHAR) AS follow_up_poll_id,
    TRY_CAST(attribute_max_length AS DOUBLE) AS attribute_max_length,
    CAST(attribute_type AS VARCHAR) AS attribute_type,
    CAST(question AS VARCHAR) AS question,
    TRY_CAST(SUBSTRING(CAST(reset_at AS VARCHAR), 1, 23) AS TIMESTAMP) AS reset_at
FROM raw.poll