WITH ranked AS (
    SELECT *, row_number() OVER (PARTITION BY page_id, rule ORDER BY page_last_updated_at DESC) AS latest_page_rule_index
    FROM staging.stg_pendo__page_rule_history
)
SELECT * FROM ranked WHERE latest_page_rule_index = 1