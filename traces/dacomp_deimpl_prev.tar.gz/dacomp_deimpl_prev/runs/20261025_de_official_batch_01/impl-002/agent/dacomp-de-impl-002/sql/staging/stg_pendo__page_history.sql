SELECT
    CAST(id AS VARCHAR) AS page_id,
    CAST(name AS VARCHAR) AS page_name,
    CAST(app_id AS VARCHAR) AS app_id,
    TRY_CAST(SUBSTRING(CAST(created_at AS VARCHAR), 1, 23) AS TIMESTAMP) AS created_at,
    CAST(created_by_user_id AS VARCHAR) AS created_by_user_id,
    TRY_CAST(dirty AS BOOLEAN) AS is_dirty,
    TRY_CAST(group_id AS BIGINT) AS group_id,
    TRY_CAST(SUBSTRING(CAST(last_updated_at AS VARCHAR), 1, 23) AS TIMESTAMP) AS last_updated_at,
    CAST(last_updated_by_user_id AS VARCHAR) AS last_updated_by_user_id,
    TRY_CAST(root_version_id AS BIGINT) AS root_version_id,
    TRY_CAST(stable_version_id AS BIGINT) AS stable_version_id,
    TRY_CAST(SUBSTRING(CAST(valid_through AS VARCHAR), 1, 23) AS TIMESTAMP) AS valid_through
FROM raw.page_history