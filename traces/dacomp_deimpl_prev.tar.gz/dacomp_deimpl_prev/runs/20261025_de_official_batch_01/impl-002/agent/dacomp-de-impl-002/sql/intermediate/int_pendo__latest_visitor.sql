WITH ranked AS (
    SELECT *, row_number() OVER (PARTITION BY visitor_id ORDER BY last_updated_at DESC) AS latest_visitor_index
    FROM staging.stg_pendo__visitor_history
)
SELECT * FROM ranked WHERE latest_visitor_index = 1