SELECT
    CAST(account_id AS VARCHAR) AS account_id,
    CAST(visitor_id AS VARCHAR) AS visitor_id,
    TRY_CAST(SUBSTRING(CAST(visitor_last_updated_at AS VARCHAR), 1, 23) AS TIMESTAMP) AS visitor_last_updated_at
FROM raw.visitor_account_history