WITH ranked AS (
    SELECT *, row_number() OVER (PARTITION BY guide_id, step_id ORDER BY guide_last_updated_at DESC) AS latest_guide_step_index
    FROM staging.stg_pendo__guide_step_history
)
SELECT * FROM ranked WHERE latest_guide_step_index = 1