SELECT
    CAST(account_id AS VARCHAR) AS account_id,
    CAST(guide_id AS VARCHAR) AS guide_id,
    CASE WHEN remote_ip IS NULL OR regexp_matches(CAST(remote_ip AS VARCHAR), '^([0-9]{1,3}\.){3}[0-9]{1,3}$') OR regexp_matches(CAST(remote_ip AS VARCHAR), '^([0-9a-fA-F]{0,4}:){2,7}[0-9a-fA-F]{0,4}$') THEN CAST(remote_ip AS VARCHAR) ELSE NULL END AS remote_ip,
    NULLIF(TRIM(CAST(server_name AS VARCHAR)), '') AS server_name,
    TRY_CAST(SUBSTRING(CAST(timestamp AS VARCHAR), 1, 23) AS TIMESTAMP) AS occurred_at,
    NULLIF(TRIM(CAST(user_agent AS VARCHAR)), '') AS user_agent,
    CAST(visitor_id AS VARCHAR) AS visitor_id,
    CAST(app_id AS VARCHAR) AS app_id,
    CAST(country AS VARCHAR) AS country,
    TRY_CAST(guide_step_id AS BIGINT) AS guide_step_id,
    TRY_CAST(latitude AS DOUBLE) AS latitude,
    CASE WHEN TRY_CAST(longitude AS DOUBLE) BETWEEN -180 AND 180 THEN TRY_CAST(longitude AS DOUBLE) ELSE NULL END AS longitude,
    CAST(region AS VARCHAR) AS region,
    CAST(type AS VARCHAR) AS type,
    CASE WHEN url IS NULL THEN NULL ELSE NULLIF(TRIM(CAST(url AS VARCHAR)), '') END AS url,
    md5(concat_ws('|', coalesce(CAST(visitor_id AS VARCHAR), ''), coalesce(CAST(timestamp AS VARCHAR), ''), coalesce(CAST(guide_id AS VARCHAR), ''), coalesce(CAST(account_id AS VARCHAR), ''))) AS guide_event_key
FROM raw.guide_event