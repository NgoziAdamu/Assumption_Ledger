SELECT
    CAST(id AS VARCHAR) AS account_id,
    TRY_CAST(SUBSTRING(CAST(last_updated_at AS VARCHAR), 1, 23) AS TIMESTAMP) AS last_updated_at,
    TRY_CAST(id_hash AS DOUBLE) AS account_id_hash,
    TRY_CAST(SUBSTRING(CAST(first_visit AS VARCHAR), 1, 23) AS TIMESTAMP) AS first_visit_at,
    TRY_CAST(SUBSTRING(CAST(last_visit AS VARCHAR), 1, 23) AS TIMESTAMP) AS last_visit_at
FROM raw.account_history