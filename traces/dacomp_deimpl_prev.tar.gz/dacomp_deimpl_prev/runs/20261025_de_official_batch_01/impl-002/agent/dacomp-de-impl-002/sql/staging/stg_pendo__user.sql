SELECT
    CAST(id AS VARCHAR) AS user_id,
    TRY_CAST(NULLIF(deleted_at, '') AS TIMESTAMP) AS deleted_at,
    CAST(first_name AS VARCHAR) AS first_name,
    CAST(last_name AS VARCHAR) AS last_name,
    LOWER(TRIM(user_type)) AS user_type,
    LOWER(TRIM(username)) AS username
FROM raw.user
WHERE user_type IN ('system','internal','api','external')
  AND username IS NOT NULL AND LENGTH(TRIM(username)) > 0