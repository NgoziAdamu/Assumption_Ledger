WITH ranked AS (
    SELECT *, row_number() OVER (PARTITION BY visitor_id, account_id ORDER BY visitor_last_updated_at DESC) AS latest_visitor_account_index
    FROM staging.stg_pendo__visitor_account_history
)
SELECT * FROM ranked WHERE latest_visitor_account_index = 1