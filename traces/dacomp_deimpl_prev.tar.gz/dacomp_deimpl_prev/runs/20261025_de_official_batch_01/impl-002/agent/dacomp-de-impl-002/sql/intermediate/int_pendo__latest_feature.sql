WITH ranked AS (
    SELECT *, row_number() OVER (PARTITION BY feature_id ORDER BY last_updated_at DESC) AS latest_feature_index
    FROM staging.stg_pendo__feature_history
)
SELECT * FROM ranked WHERE latest_feature_index = 1