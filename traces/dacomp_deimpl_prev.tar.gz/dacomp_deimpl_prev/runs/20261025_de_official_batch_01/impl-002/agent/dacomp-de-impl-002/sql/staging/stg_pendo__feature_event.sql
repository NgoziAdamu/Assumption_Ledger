SELECT
    CAST(account_id AS VARCHAR) AS account_id,
    CAST(feature_id AS VARCHAR) AS feature_id,
    CASE WHEN remote_ip IS NULL OR regexp_matches(CAST(remote_ip AS VARCHAR), '^([0-9]{1,3}\.){3}[0-9]{1,3}$') OR regexp_matches(CAST(remote_ip AS VARCHAR), '^([0-9a-fA-F]{0,4}:){2,7}[0-9a-fA-F]{0,4}$') THEN CAST(remote_ip AS VARCHAR) ELSE NULL END AS remote_ip,
    NULLIF(TRIM(CAST(server_name AS VARCHAR)), '') AS server_name,
    TRY_CAST(SUBSTRING(CAST(timestamp AS VARCHAR), 1, 23) AS TIMESTAMP) AS occurred_at,
    NULLIF(TRIM(CAST(user_agent AS VARCHAR)), '') AS user_agent,
    CAST(visitor_id AS VARCHAR) AS visitor_id,
    CAST(app_id AS VARCHAR) AS app_id,
    TRY_CAST(num_events AS DOUBLE) AS num_events,
    TRY_CAST(num_minutes AS DOUBLE) AS num_minutes,
    md5(concat_ws('|', coalesce(CAST(visitor_id AS VARCHAR), ''), coalesce(CAST(timestamp AS VARCHAR), ''), coalesce(CAST(feature_id AS VARCHAR), ''), coalesce(CAST(account_id AS VARCHAR), ''))) AS feature_event_key
FROM raw.feature_event