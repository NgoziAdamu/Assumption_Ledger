SELECT
    CAST(page_id AS VARCHAR) AS page_id,
    TRY_CAST(SUBSTRING(CAST(page_last_updated_at AS VARCHAR), 1, 23) AS TIMESTAMP) AS page_last_updated_at,
    CAST(rule AS VARCHAR) AS rule,
    TRY_CAST(designer_hint AS DOUBLE) AS designer_hint,
    CAST(parsed_rule AS VARCHAR) AS parsed_rule
FROM raw.page_rule_history