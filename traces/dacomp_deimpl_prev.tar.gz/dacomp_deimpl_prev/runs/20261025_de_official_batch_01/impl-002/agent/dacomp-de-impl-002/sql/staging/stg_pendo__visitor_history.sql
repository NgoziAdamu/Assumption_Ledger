SELECT
    CAST(id AS VARCHAR) AS visitor_id,
    CAST(account_id AS VARCHAR) AS account_id,
    TRY_CAST(SUBSTRING(CAST(first_visit AS VARCHAR), 1, 23) AS TIMESTAMP) AS first_visit_at,
    TRY_CAST(id_hash AS DOUBLE) AS visitor_id_hash,
    CAST(last_browser_name AS VARCHAR) AS last_browser_name,
    CAST(last_browser_version AS VARCHAR) AS last_browser_version,
    CAST(last_operating_system AS VARCHAR) AS last_operating_system,
    CAST(last_server_name AS VARCHAR) AS last_server_name,
    TRY_CAST(SUBSTRING(CAST(last_updated_at AS VARCHAR), 1, 23) AS TIMESTAMP) AS last_updated_at,
    CAST(last_user_agent AS VARCHAR) AS last_user_agent,
    TRY_CAST(last_visit AS TIMESTAMP) AS last_visit,
    TRY_CAST(n_id AS BIGINT) AS n_id
FROM raw.visitor_history