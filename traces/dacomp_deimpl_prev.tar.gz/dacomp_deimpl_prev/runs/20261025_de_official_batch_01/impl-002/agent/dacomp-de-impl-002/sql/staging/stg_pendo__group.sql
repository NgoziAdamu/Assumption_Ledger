SELECT
    CAST(id AS VARCHAR) AS group_id,
    CAST(name AS VARCHAR) AS group_name,
    TRY_CAST(app_id AS BIGINT) AS app_id
FROM raw.group_data