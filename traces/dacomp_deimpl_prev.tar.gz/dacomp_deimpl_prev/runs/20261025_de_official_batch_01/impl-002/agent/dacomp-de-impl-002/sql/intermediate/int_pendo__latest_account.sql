WITH ranked AS (
    SELECT *, row_number() OVER (PARTITION BY account_id ORDER BY last_updated_at DESC) AS latest_account_index
    FROM staging.stg_pendo__account_history
)
SELECT * FROM ranked WHERE latest_account_index = 1