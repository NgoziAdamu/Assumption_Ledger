WITH ranked AS (
    SELECT *, row_number() OVER (PARTITION BY page_id ORDER BY last_updated_at DESC) AS latest_page_index
    FROM staging.stg_pendo__page_history
)
SELECT * FROM ranked WHERE latest_page_index = 1