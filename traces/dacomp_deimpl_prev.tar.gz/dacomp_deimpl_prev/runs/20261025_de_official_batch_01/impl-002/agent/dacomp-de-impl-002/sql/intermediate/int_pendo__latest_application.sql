WITH ranked AS (
    SELECT *, row_number() OVER (PARTITION BY application_id ORDER BY last_updated_at DESC) AS latest_application_index
    FROM staging.stg_pendo__application_history
)
SELECT * FROM ranked WHERE latest_application_index = 1