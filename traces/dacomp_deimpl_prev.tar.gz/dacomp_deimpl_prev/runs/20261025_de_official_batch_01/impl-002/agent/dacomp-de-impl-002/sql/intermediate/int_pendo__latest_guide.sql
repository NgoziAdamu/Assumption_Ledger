WITH ranked AS (
    SELECT *, row_number() OVER (PARTITION BY guide_id ORDER BY last_updated_at DESC) AS latest_guide_index
    FROM staging.stg_pendo__guide_history
)
SELECT * FROM ranked WHERE latest_guide_index = 1