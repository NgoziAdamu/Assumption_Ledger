# 三十题保存输出复核

日期：2026-10-25。原模型 gpt-6-luna；本次不调用模型、不重跑 Agent 或 run.py。

使用官方表比较、依赖替换和权重代码；只读验证保存的预测库，私有 gold 副本允许 CS 临时库写入。原始运行和旧评分保留。

命令：`.venv-openhands/bin/python src/de_batch_review.py --output runs/20261025_de_batch_review_02`。

报告：[31 号报告](../../notes/31_三十题评分与行为复核.md)。
